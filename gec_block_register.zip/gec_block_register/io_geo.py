"""Geocoded IO: put GEC and the reference on ONE common grid.

GEC is already geocoded (EPSG:4326) but with rotated/odd transforms (this bit the
viewer) -> always read through a WarpedVRT onto a regular grid. The reference
(hand-aligned gold SAR, or WV EO) is warped onto the SAME grid (identical bounds
+ resolution), so all matching/transform/warp math happens in a shared pixel
space and the residual we estimate is directly the geolocation error. The corrected
GEC can be written back with the grid transform => a georeferenced GeoTIFF.

rasterio/GDAL are imported lazily so the geometry modules (and the synthetic test)
work without them. Pin numpy<2 in the GDAL container for the bindings' ABI.
"""
import numpy as np


def _common_grid_bounds(paths):
    import rasterio
    from rasterio.warp import transform_bounds
    boxes = []
    for p in paths:
        with rasterio.open(p) as ds:
            b = transform_bounds(ds.crs, "EPSG:4326", *ds.bounds)
            boxes.append(b)
    # intersection of footprints (we can only register where both exist)
    left = max(b[0] for b in boxes)
    bottom = max(b[1] for b in boxes)
    right = min(b[2] for b in boxes)
    top = min(b[3] for b in boxes)
    if right <= left or top <= bottom:
        raise ValueError("GEC and reference footprints do not overlap in EPSG:4326")
    return left, bottom, right, top


def read_on_common_grid(gec_path, ref_path, common_gsd_m=0.5):
    """Return (gec_arr, ref_arr, transform, crs) co-located on one 4326 grid.

    common_gsd_m is the target ground sample distance; it is converted to degrees
    at the scene latitude (good enough for a baseline; a metric CRS is the v2
    refinement).
    """
    import rasterio
    from rasterio.vrt import WarpedVRT
    from rasterio.transform import from_origin
    from rasterio.enums import Resampling

    left, bottom, right, top = _common_grid_bounds([gec_path, ref_path])
    lat = 0.5 * (top + bottom)
    deg_per_m_lat = 1.0 / 111320.0
    deg_per_m_lon = 1.0 / (111320.0 * max(np.cos(np.radians(lat)), 1e-3))
    res_x = common_gsd_m * deg_per_m_lon
    res_y = common_gsd_m * deg_per_m_lat
    width = max(1, int(round((right - left) / res_x)))
    height = max(1, int(round((top - bottom) / res_y)))
    transform = from_origin(left, top, res_x, res_y)

    def _warp(path, bands=None):
        with rasterio.open(path) as ds:
            vrt_kw = dict(crs="EPSG:4326", transform=transform, width=width,
                          height=height, resampling=Resampling.cubic)
            with WarpedVRT(ds, **vrt_kw) as vrt:
                arr = vrt.read(indexes=bands)
        return arr

    gec = _warp(gec_path, bands=1).astype(np.float32)              # (H,W)
    ref_raw = _warp(ref_path)                                      # (bands,H,W)
    if ref_raw.shape[0] == 1:
        ref = ref_raw[0].astype(np.float32)                       # SAR gold
    else:
        ref = np.transpose(ref_raw[:3], (1, 2, 0)).astype(np.float32)  # EO RGB
    return gec, ref, transform, "EPSG:4326"


def write_geotiff(path, arr, transform, crs):
    """Write a corrected GEC raster back as a georeferenced GeoTIFF."""
    import rasterio
    arr = arr if arr.ndim == 3 else arr[None]
    count, H, W = arr.shape
    with rasterio.open(path, "w", driver="GTiff", height=H, width=W, count=count,
                       dtype=arr.dtype, crs=crs, transform=transform,
                       compress="deflate") as dst:
        dst.write(arr)


# --- N-way co-location for the metrics harness ---------------------------------
# For scoring multiple products against a reference we warp every product onto the
# REFERENCE's own native grid (the reference is not resampled). This guarantees all
# products + reference are pixel-aligned so the same crop window is comparable.

def open_grid(path):
    """Read a raster in its native grid. Returns (arr2d_or_hw3, transform, crs, (H,W))."""
    import rasterio
    with rasterio.open(path) as ds:
        raw = ds.read()  # (bands,H,W)
        transform, crs = ds.transform, ds.crs
        shape = (ds.height, ds.width)
    if raw.shape[0] == 1:
        return raw[0].astype(np.float32), transform, crs, shape
    return np.transpose(raw[:3], (1, 2, 0)).astype(np.float32), transform, crs, shape


def warp_to_grid(path, transform, crs, width, height, resampling="cubic"):
    """Warp a raster onto a target grid (band 1 -> 2D float32)."""
    import rasterio
    from rasterio.vrt import WarpedVRT
    from rasterio.enums import Resampling
    with rasterio.open(path) as ds:
        with WarpedVRT(ds, crs=crs, transform=transform, width=width, height=height,
                       resampling=getattr(Resampling, resampling)) as vrt:
            arr = vrt.read(indexes=1)
    return arr.astype(np.float32)
