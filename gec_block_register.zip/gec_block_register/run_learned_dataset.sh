#!/bin/bash
# Build SAR_learned: DEM-FREE. Stage 1: RoMa + XoFTR matching (--select all) for
# every scene in SAR_RPC_ellip with a WV mosaic, sharded across all GPUs.
# Stage 2: agreement fusion (medfilter 10 m, agree tol 50 m) -> per scene either
#   SAR_learned/<scene>/<scene>_reg_fused.tif  (+fused.json)
# or a fallback.json marker pointing at the RPC-ellipsoid product.
set -u
cd /home/tabtahi/SATLOCK/gec_block_register
LEARNED=/home/tabtahi/SATLOCK/dataset/SAR_learned
WV_ROOT=/data3/sandbox/kashley/satlock/data_collection/outputs/wv_dailytake_output
CPUS=${CPUS:-8}          # CPU cap per worker (env override: CPUS=12)
SCRATCH=/home/tabtahi/SATLOCK/scratch    # container /tmp -> here (NOT /data3)
mkdir -p "$LEARNED" logs "$SCRATCH"

# GPUS: explicit device list (e.g. GPUS="0 1 2"); default = all visible.
# Positional arg still works as "first N" for backwards compatibility.
if [ -n "${GPUS:-}" ]; then GPU_LIST=($GPUS)
elif [ -n "${1:-}" ]; then GPU_LIST=($(seq 0 $(($1-1))))
else GPU_LIST=($(seq 0 $(( $(nvidia-smi -L 2>/dev/null | wc -l) - 1 )))); fi
NGPU=${#GPU_LIST[@]}
[ "$NGPU" -lt 1 ] && { echo "no GPUs"; exit 1; }
echo "using GPUs: ${GPU_LIST[*]}"

# inventory: ellipsoid product + WV only (NO DEM requirement)
> scenes_learned.txt
for sd in /home/tabtahi/SATLOCK/dataset/SAR_RPC_ellip/*/; do
  s=$(basename "$sd")
  sar="${sd}${s}_rpc_ellip.tif"
  wv=$(ls ${WV_ROOT}/${s}/mosaic/*.tif 2>/dev/null | head -1)
  if [ -f "$sar" ] && [ -n "$wv" ]; then echo "$s" >> scenes_learned.txt
  else echo "[skip] $s sar=$([ -f "$sar" ] && echo ok || echo MISS) wv=$([ -n "$wv" ] && echo ok || echo MISS)" >> logs/learned_skipped.txt; fi
done
total=$(wc -l < scenes_learned.txt)
echo "$(date)  stage 1: ${total} scenes x 2 matchers (${NGPU} GPUs, no DEM)"

worker() {
  lane=$1; gpu=$2; i=0; consec_fail=0
  while read s; do
    i=$((i+1)); [ $(( (i-1) % NGPU )) -ne "$lane" ] && continue
    sar="/home/tabtahi/SATLOCK/dataset/SAR_RPC_ellip/${s}/${s}_rpc_ellip.tif"
    wv=$(ls ${WV_ROOT}/${s}/mosaic/*.tif | head -1)
    for m in roma xoftr; do
      out="${LEARNED}/${s}/${m}"
      [ -f "${out}/report.json" ] && { echo "[gpu${gpu} skip ${i}/${total}] ${m} ${s}"; continue; }
      for attempt in 1 2 3; do
        echo "[gpu${gpu} run ${i}/${total}] $(date +%H:%M) ${m} ${s} (try ${attempt})"
        docker run --rm --cpus ${CPUS} --gpus "\"device=${gpu}\"" \
          -v /home/tabtahi/SATLOCK/gec_block_register:/work \
          -v /home/tabtahi/SATLOCK/dataset:/home/tabtahi/SATLOCK/dataset \
          -v /data3/sandbox/kashley/satlock:/data3/sandbox/kashley/satlock:ro \
          -v ${SCRATCH}:/tmp \
          -e TMPDIR=/tmp -e MPLCONFIGDIR=/tmp/mpl -e CPL_TMPDIR=/tmp \
          -e OMP_NUM_THREADS=${CPUS} -e MKL_NUM_THREADS=${CPUS} \
          height-register \
          --sar "$sar" --wv "$wv" \
          --matcher "$m" --select all --device cuda --no-viz --no-tif \
          --out "$out" \
          >> "logs/learned_${m}_${s}.log" 2>&1
        rc=$?
        if [ -f "${out}/report.json" ]; then consec_fail=0; break; fi
        # rc 125 = docker daemon refused to START the container (disk full,
        # bad flag, missing image). Not a GPU flap — retrying cannot help.
        if [ "$rc" -eq 125 ]; then
          echo "[gpu${gpu} FATAL] docker daemon error (rc=125) — see logs/learned_${m}_${s}.log; lane stopping"
          return 1
        fi
        echo "[gpu${gpu} retry] ${m} ${s} rc=${rc}; 60s"; sleep 60
      done
      if [ ! -f "${out}/report.json" ]; then
        consec_fail=$((consec_fail+1))
        # 5 jobs in a row failing on this device = dead lane, not bad scenes
        if [ "$consec_fail" -ge 5 ]; then
          echo "[gpu${gpu} FATAL] ${consec_fail} consecutive job failures — lane stopping (dead GPU?)"
          return 1
        fi
      fi
    done
  done < scenes_learned.txt
  echo "[gpu${gpu}] $(date) stage 1 done"
}

pids=""
for lane in $(seq 0 $((NGPU-1))); do
  g=${GPU_LIST[$lane]}
  worker "$lane" "$g" > "logs/learned_worker_gpu${g}.log" 2>&1 &
  pids="$pids $!"; echo "lane ${lane} -> gpu${g} pid $!"
done
wait $pids
echo "$(date)  stage 1 complete"

echo "$(date)  stage 2: agreement fusion (medfilter 10 m, agree 50 m)"
docker run --rm \
  -v /home/tabtahi/SATLOCK/gec_block_register:/work \
  -v /home/tabtahi/SATLOCK/dataset:/home/tabtahi/SATLOCK/dataset \
  -v ${SCRATCH}:/tmp -e TMPDIR=/tmp -e CPL_TMPDIR=/tmp \
  --entrypoint python3 height-register \
  /work/build_fused_products.py \
    --learned-root "$LEARNED" \
    --sar-root /home/tabtahi/SATLOCK/dataset/SAR_RPC_ellip \
    --medfilter-tol 10 --agree-tol 50 \
  2>&1 | tee logs/fusion.log
echo "$(date)  SAR_learned build complete"
