#!/usr/bin/env python3
"""Synthetic verification of the geometry stages — no GDAL, no GPU, no matchers.

Builds a structured "reference", applies a KNOWN smooth, spatially-varying warp
(+ global affine) to make a "GEC", then drives the real pooling / consensus /
warp / metrics code with correspondences sampled from the known field (standing
in for the matcher). Checks:

  1. global-affine baseline improves SSIM/NCC vs raw GEC
  2. TPS residual recovers the spatially-varying part BETTER than global affine
  3. the affine gates accept a well-spread block and reject a collinear one
  4. the consensus filter drops a planted liar block

This validates everything except the matcher and GDAL IO (which need geohub3).
Run:  python test_geometry.py
"""
import numpy as np
import cv2

from config import GateConfig, WarpConfig
import block_register as br
import warp as wp
import metrics as me
from region_select import Block


def make_reference(h=768, w=1024, seed=0):
    rng = np.random.default_rng(seed)
    img = np.full((h, w), 40, np.float32)
    for _ in range(40):
        x0, y0 = rng.integers(0, w-60), rng.integers(0, h-60)
        cv2.rectangle(img, (x0, y0), (x0+rng.integers(30, 120), y0+rng.integers(30, 120)),
                      float(rng.integers(60, 220)), -1)
    for _ in range(30):
        cv2.line(img, (rng.integers(0, w), rng.integers(0, h)),
                 (rng.integers(0, w), rng.integers(0, h)), float(rng.integers(150, 255)),
                 rng.integers(1, 4))
    return cv2.GaussianBlur(img, (3, 3), 0)


def known_field(h, w):
    """A smooth spatially-varying displacement (ref->GEC) + a small global affine."""
    A = np.array([[1.01, 0.012, 6.0], [-0.010, 1.008, -4.0]], np.float64)  # global

    def disp(x, y):  # extra smooth local wobble on top of the affine
        dx = 5.0*np.sin(2*np.pi*y/h) + 3.0*np.cos(2*np.pi*x/w)
        dy = 4.0*np.cos(2*np.pi*x/w) - 2.5*np.sin(2*np.pi*y/h)
        return dx, dy
    return A, disp


def warp_ref_to_gec(ref, A, disp):
    h, w = ref.shape
    ys, xs = np.mgrid[0:h, 0:w].astype(np.float64)
    # affine maps ref->gec sampling coords, plus smooth wobble
    gx = A[0, 0]*xs + A[0, 1]*ys + A[0, 2]
    gy = A[1, 0]*xs + A[1, 1]*ys + A[1, 2]
    dx, dy = disp(xs, ys)
    return cv2.remap(ref, (gx+dx).astype(np.float32), (gy+dy).astype(np.float32),
                     cv2.INTER_CUBIC, borderMode=cv2.BORDER_REFLECT)


def sample_correspondences(A, disp, h, w, n=1500, noise=0.4, seed=1):
    """Stand in for the matcher: GEC<->ref pairs implied by the known field.

    The remap defines gec[p] = ref[A(p)+wobble(p)], so A maps GEC->ref and the
    ref match for GEC point p is A(p)+wobble(p). src=GEC, dst=ref.
    """
    rng = np.random.default_rng(seed)
    gec_pts = rng.uniform([20, 20], [w-20, h-20], size=(n, 2))
    x, y = gec_pts[:, 0], gec_pts[:, 1]
    rx = A[0, 0]*x + A[0, 1]*y + A[0, 2]
    ry = A[1, 0]*x + A[1, 1]*y + A[1, 2]
    dxv, dyv = disp(x, y)
    ref_pts = np.stack([rx+dxv, ry+dyv], 1) + rng.normal(0, noise, (n, 2))
    return gec_pts.astype(np.float32), ref_pts.astype(np.float32)  # src(GEC), dst(ref)


def test_warp_and_metrics():
    ref = make_reference()
    h, w = ref.shape
    A, disp = known_field(h, w)
    gec = warp_ref_to_gec(ref, A, disp)
    src, dst = sample_correspondences(A, disp, h, w)

    A_fit, _ = wp.fit_global_affine(src, dst)
    warped_affine = wp.warp_global_affine(gec, A_fit, ref.shape)
    base = me.compare(gec, warped_affine, ref)

    mx, my = wp.fit_tps_field(src, dst, ref.shape, smoothing=1.0)
    tps = me.compare(gec, wp.warp_tps(gec, mx, my), ref)

    print(f"  raw  SSIM={base['raw']['ssim']:.3f} NCC={base['raw']['ncc']:.3f}")
    print(f"  affine SSIM={base['warped']['ssim']:.3f} NCC={base['warped']['ncc']:.3f} "
          f"(dNCC {base['warped']['ncc']-base['raw']['ncc']:+.3f})")
    print(f"  tps    SSIM={tps['warped']['ssim']:.3f} NCC={tps['warped']['ncc']:.3f} "
          f"(dNCC {tps['warped']['ncc']-base['raw']['ncc']:+.3f})")
    # NCC is the unambiguous alignment signal on this (non-SAR) synthetic; SSIM's
    # luminance/contrast terms + SAR-style prep + warp-edge zeros make it noisy
    # here. On real SAR<->gold both move together (that's me.compare's criterion).
    assert base["warped"]["ncc"] > base["raw"]["ncc"], "global affine should raise NCC vs raw"
    assert tps["warped"]["ncc"] > base["warped"]["ncc"], "TPS should beat global affine"
    print("  PASS: NCC raw < affine < tps (direction + ordering correct)")


def test_gates():
    g = GateConfig()
    # well-spread inliers from a near-identity affine -> accept
    rng = np.random.default_rng(0)
    pts = rng.uniform(0, 1000, (60, 2)).astype(np.float32)
    A = np.array([[1.0, 0.01, 2.0], [-0.01, 1.0, -1.0]], np.float64)
    ok, reason = br._affine_gates(A, pts, 1000*1000, g)
    assert ok, f"well-spread block should pass, got {reason}"
    # collinear inliers -> reject (under-constrained)
    line = np.stack([np.linspace(0, 1000, 60), np.linspace(0, 1000, 60)*1.0+5], 1).astype(np.float32)
    ok2, reason2 = br._affine_gates(A, line, 1000*1000, g)
    assert not ok2, "collinear block should fail"
    print(f"  PASS: spread accepted; collinear rejected ({reason2})")


def test_consensus():
    g = GateConfig()
    rng = np.random.default_rng(0)
    res = []
    for i in range(12):  # consistent blocks ~(3,-2)
        s = rng.uniform(0, 100, (30, 2)).astype(np.float32)
        d = s + np.array([3.0, -2.0], np.float32)
        res.append(br.BlockResult(i*10, 0, "affine", "ok", 30, (3.0, -2.0), s, d,
                                   np.ones(30, np.float32)))
    # one liar ~(40, 30)
    s = rng.uniform(0, 100, (30, 2)).astype(np.float32)
    res.append(br.BlockResult(999, 0, "affine", "ok", 30, (40.0, 30.0), s,
                              s + [40, 30], np.ones(30, np.float32)))
    out = br.consensus_filter(res, g)
    liar = [r for r in out if r.r0 == 999][0]
    assert liar.model == "drop" and liar.reason == "consensus", "liar should be dropped"
    print("  PASS: consensus filter dropped the planted liar block")


if __name__ == "__main__":
    print("[warp + metrics]"); test_warp_and_metrics()
    print("[affine gates]");   test_gates()
    print("[consensus]");      test_consensus()
    print("ALL GEOMETRY TESTS PASSED")
