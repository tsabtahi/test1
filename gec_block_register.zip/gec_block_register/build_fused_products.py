#!/usr/bin/env python3
"""Build final SAR_learned products via multi-matcher agreement (CPU).

Per scene dir containing roma/ and xoftr/ runs (matches.csv + transform.json):
  1. median-relative filter each matcher's matches (--medfilter-tol), fit affine
  2. agreement = mean distance between the two affines on a 20x20 grid over the
     matched region (production signal — no tie points involved)
  3. agreement <= --agree-tol  ->  FUSED affine = mean(A_roma, A_xoftr)
     (averaging two affines' outputs == averaging their matrices), re-warp the
     RPC-ellipsoid product on the run's common grid, write
        <scene>_reg_fused.tif  +  fused.json (agreement, affines, decision)
  4. else -> fallback.json marker (product = the RPC-ellipsoid tif, unchanged;
     use --copy-fallback to physically copy it in)

    python build_fused_products.py \
        --learned-root /home/tabtahi/SATLOCK/dataset/SAR_learned \
        --sar-root /home/tabtahi/SATLOCK/dataset/SAR_RPC_ellip \
        --medfilter-tol 10 --agree-tol 50
"""
import argparse
import csv
import glob
import json
import math
import os
import shutil
import zlib

import numpy as np
import cv2
import rasterio
from rasterio.vrt import WarpedVRT
from rasterio.enums import Resampling


def load_matches(run_dir):
    tf = json.load(open(os.path.join(run_dir, "transform.json")))
    src, dst = [], []
    with open(os.path.join(run_dir, "matches.csv")) as f:
        for r in csv.DictReader(f):
            src.append([float(r["x_sar_px"]), float(r["y_sar_px"])])
            dst.append([float(r["x_wv_px"]), float(r["y_wv_px"])])
    return tf, np.array(src), np.array(dst)


def m_per_px(g):
    lat = g[5]
    return 0.5 * (abs(g[0]) * 111320.0 * max(math.cos(math.radians(lat)), 1e-3)
                  + abs(g[4]) * 111320.0)


def medfilter_fit(src, dst, tol_px, min_kept=20):
    if len(src) < 3:
        return None
    disp = dst - src
    med = np.median(disp, axis=0)
    keep = np.linalg.norm(disp - med, axis=1) <= tol_px
    if keep.sum() < min_kept:
        return None
    A, _ = cv2.estimateAffine2D(src[keep].astype(np.float32), dst[keep].astype(np.float32),
                                method=cv2.RANSAC, ransacReprojThreshold=3.0,
                                maxIters=10000, confidence=0.9999)
    return A


def grid_agreement_m(A_r, A_x, src_r, src_x, mpp):
    allpts = np.vstack([src_r, src_x])
    gx = np.linspace(allpts[:, 0].min(), allpts[:, 0].max(), 20)
    gy = np.linspace(allpts[:, 1].min(), allpts[:, 1].max(), 20)
    GC, GR = np.meshgrid(gx, gy)
    def ap(A, c, r):
        return A[0, 0] * c + A[0, 1] * r + A[0, 2], A[1, 0] * c + A[1, 1] * r + A[1, 2]
    cr, rr = ap(A_r, GC.ravel(), GR.ravel())
    cx, rx = ap(A_x, GC.ravel(), GR.ravel())
    return float(np.mean(np.hypot(cr - cx, rr - rx)) * mpp)


def rewarp(sar_path, tf_r, run_dir, A, out_tif):
    """Warp the rpc_ellip product by fused affine A on the run's common grid.
    Grid geometry comes from transform.json (grid_transform + width/height);
    for older runs without dims, falls back to reading a reg tif in run_dir."""
    from rasterio.transform import Affine
    g = tf_r["grid_transform"]
    W, H = tf_r.get("grid_width"), tf_r.get("grid_height")
    crs = tf_r.get("crs")
    if not (W and H):
        ref = glob.glob(os.path.join(run_dir, "*_reg_*.tif"))
        if not ref:
            raise RuntimeError("no grid dims in transform.json and no reg tif to read them from")
        with rasterio.open(ref[0]) as r:
            W, H, crs = r.width, r.height, r.crs
    transform = Affine(g[0], g[1], g[2], g[3], g[4], g[5])
    with rasterio.open(sar_path) as s:
        with WarpedVRT(s, crs=crs, transform=transform, width=W, height=H,
                       resampling=Resampling.cubic) as vrt:
            arr = vrt.read(1).astype(np.float32)
    warped = cv2.warpAffine(arr, A.astype(np.float64), (W, H))
    prof = dict(driver="GTiff", height=H, width=W, count=1, dtype="float32",
                transform=transform, crs=crs, compress="deflate", predictor=2,
                tiled=True, blockxsize=512, blockysize=512)
    tmp = out_tif + ".tmp.tif"
    with rasterio.open(tmp, "w", **prof) as d:
        d.write(warped, 1)
    os.replace(tmp, out_tif)


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--learned-root", required=True)
    ap.add_argument("--sar-root", required=True)
    ap.add_argument("--medfilter-tol", type=float, default=10.0)
    ap.add_argument("--agree-tol", type=float, default=50.0)
    ap.add_argument("--copy-fallback", action="store_true",
                    help="physically copy the rpc_ellip tif into fallback scenes")
    ap.add_argument("--overwrite", action="store_true")
    ap.add_argument("--shard", default=None,
                    help="i/N — process only scenes in shard i of N (deterministic "
                         "crc32 split; run N containers in parallel)")
    args = ap.parse_args()

    scenes = sorted(os.path.basename(d) for d in glob.glob(os.path.join(args.learned_root, "*"))
                    if os.path.isdir(d))
    if args.shard:
        si, sn = (int(v) for v in args.shard.split("/"))
        scenes = [s for s in scenes if zlib.crc32(s.encode()) % sn == si]
        print(f"[shard {si}/{sn}] {len(scenes)} scenes")
    n_fused = n_fb = n_skip = 0
    for s in scenes:
        sdir = os.path.join(args.learned_root, s)
        out_tif = os.path.join(sdir, f"{s}_reg_fused.tif")
        if (os.path.exists(out_tif) or os.path.exists(os.path.join(sdir, "fallback.json"))) \
                and not args.overwrite:
            n_skip += 1
            continue
        rd, xd = os.path.join(sdir, "roma"), os.path.join(sdir, "xoftr")
        ok = all(os.path.exists(os.path.join(d, "matches.csv")) for d in (rd, xd))
        decision = None
        try:
          if ok:
            tf_r, src_r, dst_r = load_matches(rd)
            tf_x, src_x, dst_x = load_matches(xd)
            g = tf_r["grid_transform"]
            mpp = m_per_px(g)
            A_r = medfilter_fit(src_r, dst_r, args.medfilter_tol / mpp)
            A_x = medfilter_fit(src_x, dst_x, args.medfilter_tol / mpp)
            if A_r is not None and A_x is not None:
                agree = grid_agreement_m(A_r, A_x, src_r, src_x, mpp)
                if agree <= args.agree_tol:
                    A_f = 0.5 * (A_r + A_x)
                    sar = os.path.join(args.sar_root, s, f"{s}_rpc_ellip.tif")
                    if os.path.exists(sar):
                        rewarp(sar, tf_r, rd, A_f, out_tif)
                        json.dump(dict(scene=s, decision="fused", agreement_m=agree,
                                       medfilter_tol_m=args.medfilter_tol,
                                       agree_tol_m=args.agree_tol,
                                       affine_roma=A_r.tolist(), affine_xoftr=A_x.tolist(),
                                       affine_fused=A_f.tolist(),
                                       grid_transform=g, crs=tf_r.get("crs")),
                                  open(os.path.join(sdir, "fused.json"), "w"), indent=2)
                        print(f"[fused   ] {s}  agree {agree:.1f} m")
                        n_fused += 1
                        continue
                    decision = "missing_sar"
                else:
                    decision = f"disagree ({agree:.1f} m)"
            else:
                decision = "medfilter_fit_failed"
          else:
            decision = "missing_matches"
        except Exception as ex:
            # one corrupt matches.csv (e.g. a job killed mid-write) must not
            # kill the whole shard — record it and move on
            decision = f"error:{type(ex).__name__}"
        # fallback
        fb = dict(scene=s, decision="fallback", reason=decision,
                  product=os.path.join(args.sar_root, s, f"{s}_rpc_ellip.tif"))
        json.dump(fb, open(os.path.join(sdir, "fallback.json"), "w"), indent=2)
        if args.copy_fallback and os.path.exists(fb["product"]):
            shutil.copy2(fb["product"], os.path.join(sdir, f"{s}_rpc_ellip.tif"))
        print(f"[fallback] {s}  ({decision})")
        n_fb += 1
    print(f"\ndone: {n_fused} fused, {n_fb} fallback, {n_skip} skipped (existing)")


if __name__ == "__main__":
    main()
