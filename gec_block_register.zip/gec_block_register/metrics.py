"""Scoring vs the hand-aligned gold (reuse the existing harness conventions).

SSIM + NCC on Lee-despeckled crops, same family as sar_metrics.py. The headline
comparison the baseline must win:

    GEC(raw) vs gold   <   warped-GEC vs gold

i.e. the learned registration's SSIM/NCC beats raw GEC (and ideally the RPC
products we know mostly hurt). SSIM/NCC are appropriate for SAR<->SAR gold; for
cross-modal GEC<->EO scoring add MI/NMI/gradient-edge correlation (weak here, so
gold scoring is the trustworthy signal).
"""
import numpy as np

from preprocessing import lee_filter


def _prep(a, lee_size=5):
    a = a.astype(np.float32)
    if a.ndim == 3:
        a = a.mean(2)
    a = np.log1p(np.clip(a, 0, None))
    a = lee_filter(a, lee_size)
    lo, hi = np.percentile(a, 2), np.percentile(a, 98)
    if hi - lo < 1e-8:
        hi = lo + 1.0
    return np.clip((a - lo) / (hi - lo), 0, 1)


def ncc(a, b, valid=None):
    a, b = a.ravel(), b.ravel()
    if valid is not None:
        v = valid.ravel()
        a, b = a[v], b[v]
    if a.size < 16:
        return float("nan")
    a = a - a.mean()
    b = b - b.mean()
    d = np.sqrt((a * a).sum() * (b * b).sum())
    return float((a * b).sum() / d) if d > 0 else float("nan")


def ssim(a, b, valid=None):
    from skimage.metrics import structural_similarity as sk_ssim
    if valid is not None:
        # zero out invalid so they don't bias the windows (coarse but fine for baseline)
        a = a * valid
        b = b * valid
    return float(sk_ssim(a, b, data_range=1.0))


def gradient_ncc(a, b, valid=None):
    """NCC on Sobel-gradient (edge) maps. More robust than raw NCC when the two
    products don't share an intensity relationship (useful toward the GEC<->EO
    cross-modal case; for SAR<->SAR gold it tracks plain NCC)."""
    from region_select import sobel_mag
    ga, gb = sobel_mag(a.astype(np.float32)), sobel_mag(b.astype(np.float32))
    return ncc(ga, gb, valid)


def score_pair(moving, gold, lee_size=5):
    """moving: product (GEC / RPC-ellip / USGS); gold: reference. ssim+ncc+gncc."""
    m = _prep(moving, lee_size)
    g = _prep(gold, lee_size)
    valid = (moving if moving.ndim == 2 else moving.mean(2)) > 0
    return {"ssim": ssim(m, g, valid), "ncc": ncc(m, g, valid),
            "gncc": gradient_ncc(m, g, valid)}


def compare(raw_gec, warped_gec, gold, lee_size=5):
    """Side-by-side: raw vs warped against gold, with deltas."""
    raw = score_pair(raw_gec, gold, lee_size)
    war = score_pair(warped_gec, gold, lee_size)
    return {
        "raw":     raw,
        "warped":  war,
        "d_ssim":  war["ssim"] - raw["ssim"],
        "d_ncc":   war["ncc"] - raw["ncc"],
        "improved": (war["ssim"] > raw["ssim"]) and (war["ncc"] > raw["ncc"]),
    }
