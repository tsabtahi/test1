#!/usr/bin/env python3
"""Transfer tie points through a learned registration run (CE90 candidate 3).

Takes the transform.json + matches.csv persisted by run_height_aware.py and maps
tie-point positions (e.g. the lon_rpc/lat_rpc column pair from residuals.csv)
to their refined post-registration positions. No imagery, no GPU, no rasterio.

Two modes, matching the handoff's options:
  --mode affine : (A) pure matrix path — lonlat -> grid px -> pixel affine ->
                  lonlat. Only valid for warp_model=global_affine runs.
  --mode local  : (B) local-flow — inverse-distance-weighted interpolation of the
                  k nearest matches' displacement at each tie point. Works for
                  any warp model (required for tps), and is the physically
                  appropriate choice if residual error is terrain-dependent.

Usage:
  python apply_tiepoints.py --run-dir out_height/roma/<scene> \
      --points residuals_scene.csv --lon-col lon_rpc --lat-col lat_rpc \
      --mode local --out refined.csv

Output CSV = input columns + lon_refined, lat_refined (+ n_near, mean_dist_px in
local mode). Feed lon_refined/lat_refined to the existing haversine in
compute_ce90.py as r_learned_m.
"""
import argparse
import csv
import json
import os

import numpy as np


def load_run(run_dir):
    with open(os.path.join(run_dir, "transform.json")) as f:
        tf = json.load(f)
    matches = []
    with open(os.path.join(run_dir, "matches.csv")) as f:
        for row in csv.DictReader(f):
            matches.append(row)
    return tf, matches


def lonlat_to_px(lon, lat, g):
    """Invert x = a*c + b*r + cc ; y = d*c + e*r + ff for (col,row)."""
    a, b, cc, d, e, ff = g
    M = np.array([[a, b], [d, e]], float)
    Minv = np.linalg.inv(M)
    v = np.stack([lon - cc, lat - ff], axis=-1)
    px = v @ Minv.T
    return px[..., 0], px[..., 1]


def px_to_lonlat(col, row, g):
    a, b, cc, d, e, ff = g
    return a * col + b * row + cc, d * col + e * row + ff


def refine_affine(lons, lats, tf):
    if tf.get("pixel_affine_2x3") is None:
        raise SystemExit("run has no pixel affine (warp_model="
                         f"{tf.get('warp_model')}) — use --mode local")
    A = np.array(tf["pixel_affine_2x3"], float)  # 2x3, SAR px -> WV px
    g = tf["grid_transform"]
    c, r = lonlat_to_px(np.asarray(lons), np.asarray(lats), g)
    c2 = A[0, 0] * c + A[0, 1] * r + A[0, 2]
    r2 = A[1, 0] * c + A[1, 1] * r + A[1, 2]
    lon2, lat2 = px_to_lonlat(c2, r2, g)
    return lon2, lat2, None


def refine_local(lons, lats, tf, matches, k=8, power=2.0, max_px=2000.0):
    """IDW of the k nearest matches' displacement, in grid-pixel space."""
    g = tf["grid_transform"]
    ms = np.array([[float(m["x_sar_px"]), float(m["y_sar_px"]),
                    float(m["x_wv_px"]), float(m["y_wv_px"])] for m in matches])
    src = ms[:, :2]
    disp = ms[:, 2:4] - ms[:, :2]
    c, r = lonlat_to_px(np.asarray(lons), np.asarray(lats), g)
    pts = np.stack([c, r], axis=-1)

    lon2 = np.empty_like(np.asarray(lons, float))
    lat2 = np.empty_like(lon2)
    diag = []
    for i, p in enumerate(np.atleast_2d(pts)):
        d = np.linalg.norm(src - p, axis=1)
        idx = np.argsort(d)[:k]
        dn, dd = d[idx], disp[idx]
        near = dn <= max_px
        if not near.any():
            # no support nearby -> identity (flagged via n_near=0)
            dv = np.zeros(2)
            diag.append((0, float("nan")))
        else:
            dn, dd = dn[near], dd[near]
            w = 1.0 / np.maximum(dn, 1e-6) ** power
            dv = (w[:, None] * dd).sum(0) / w.sum()
            diag.append((int(near.sum()), float(dn.mean())))
        c2, r2 = p[0] + dv[0], p[1] + dv[1]
        lon2[i], lat2[i] = px_to_lonlat(c2, r2, g)
    return lon2, lat2, diag


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--run-dir", required=True,
                    help="a run output dir containing transform.json + matches.csv")
    ap.add_argument("--points", required=True, help="CSV with tie-point lon/lat columns")
    ap.add_argument("--lon-col", default="lon")
    ap.add_argument("--lat-col", default="lat")
    ap.add_argument("--mode", default="local", choices=["affine", "local"])
    ap.add_argument("--k", type=int, default=8, help="local mode: neighbors")
    ap.add_argument("--max-px", type=float, default=2000.0,
                    help="local mode: ignore matches farther than this (grid px)")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    tf, matches = load_run(args.run_dir)
    rows = []
    with open(args.points) as f:
        rdr = csv.DictReader(f)
        fields = rdr.fieldnames
        for row in rdr:
            rows.append(row)
    lons = [float(r[args.lon_col]) for r in rows]
    lats = [float(r[args.lat_col]) for r in rows]

    if args.mode == "affine":
        lon2, lat2, diag = refine_affine(lons, lats, tf)
    else:
        lon2, lat2, diag = refine_local(lons, lats, tf, matches,
                                        k=args.k, max_px=args.max_px)

    out_fields = fields + ["lon_refined", "lat_refined"]
    if diag is not None:
        out_fields += ["n_near", "mean_dist_px"]
    with open(args.out, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=out_fields)
        w.writeheader()
        for i, r in enumerate(rows):
            r["lon_refined"] = f"{lon2[i]:.8f}"
            r["lat_refined"] = f"{lat2[i]:.8f}"
            if diag is not None:
                r["n_near"] = diag[i][0]
                r["mean_dist_px"] = (f"{diag[i][1]:.1f}"
                                     if np.isfinite(diag[i][1]) else "")
            w.writerow(r)
    print(f"wrote {args.out}  ({len(rows)} points, mode={args.mode}, "
          f"matcher={tf.get('matcher')}, scene={tf.get('scene')})")


if __name__ == "__main__":
    main()
