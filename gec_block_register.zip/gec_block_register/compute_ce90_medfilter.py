#!/usr/bin/env python3
"""CE90 with MEDIAN-RELATIVE match filtering (CPU, from saved matches).

Per scene: keep only correspondences whose displacement is within `tol` metres of
the scene's MEDIAN match displacement (the consensus correction). This trims
scattering mismatches WITHOUT throwing away the real bulk shift the way an
absolute cap does. Then refit one affine on the survivors and transfer tie points.

Scoring is honest: tie points are ALWAYS scored against ground truth (lon_eo,
lat_eo). We filter the matches that build the transform, never the residuals that
grade it. Reports CE90 over ALL tie points plus coverage (how many scenes yielded
a usable transform).

    python compute_ce90_medfilter.py \
        --residuals /home/tabtahi/SATLOCK/ce90_out/residuals.csv \
        --out-root  /home/tabtahi/SATLOCK/gec_block_register/out_height \
        --experiments xoftr_all roma_all \
        --tols 5 10 15 25 --out /home/tabtahi/SATLOCK/ce90_out/medfilter
"""
import argparse
import collections
import csv
import json
import math
import os

import numpy as np
import cv2


def haversine_m(lon1, lat1, lon2, lat2):
    R = 6371008.8
    p1, p2 = math.radians(lat1), math.radians(lat2)
    a = (math.sin(math.radians(lat2 - lat1) / 2) ** 2
         + math.cos(p1) * math.cos(p2) * math.sin(math.radians(lon2 - lon1) / 2) ** 2)
    return 2 * R * math.asin(math.sqrt(a))


def stats(vals):
    v = np.asarray([x for x in vals if np.isfinite(x)], float)
    if v.size == 0:
        return dict(n=0, median=float("nan"), rmse=float("nan"), ce90=float("nan"), p95=float("nan"))
    return dict(n=int(v.size), median=float(np.median(v)),
                rmse=float(np.sqrt(np.mean(v ** 2))),
                ce90=float(np.percentile(v, 90)), p95=float(np.percentile(v, 95)))


def load_run(run_dir):
    with open(os.path.join(run_dir, "transform.json")) as f:
        tf = json.load(f)
    src, dst = [], []
    with open(os.path.join(run_dir, "matches.csv")) as f:
        for r in csv.DictReader(f):
            src.append([float(r["x_sar_px"]), float(r["y_sar_px"])])
            dst.append([float(r["x_wv_px"]), float(r["y_wv_px"])])
    return tf, np.array(src), np.array(dst)


def m_per_px(g):
    lat = g[5]
    mx = abs(g[0]) * 111320.0 * max(math.cos(math.radians(lat)), 1e-3)
    my = abs(g[4]) * 111320.0
    return 0.5 * (mx + my)


def lonlat_to_px(lon, lat, g):
    a, b, c, d, e, f = g
    Minv = np.linalg.inv(np.array([[a, b], [d, e]], float))
    v = np.stack([np.asarray(lon) - c, np.asarray(lat) - f], -1)
    px = v @ Minv.T
    return px[..., 0], px[..., 1]


def px_to_lonlat(col, row, g):
    a, b, c, d, e, f = g
    return a * col + b * row + c, d * col + e * row + f


def median_filter_fit(src, dst, tol_px, ransac_px=3.0):
    """Keep matches within tol_px of the MEDIAN displacement vector, then refit.
    Returns (A 2x3, n_kept, n_total)."""
    if len(src) < 3:
        return None, 0, len(src)
    disp = dst - src
    med = np.median(disp, axis=0)                       # consensus shift
    off = np.linalg.norm(disp - med, axis=1)            # deviation from consensus
    keep = off <= tol_px
    s, d = src[keep], dst[keep]
    if len(s) < 3:
        return None, int(keep.sum()), len(src)
    A, _ = cv2.estimateAffine2D(s.astype(np.float32), d.astype(np.float32),
                                method=cv2.RANSAC, ransacReprojThreshold=ransac_px,
                                maxIters=10000, confidence=0.9999)
    return A, int(keep.sum()), len(src)


def refine(lons, lats, A, g):
    c, r = lonlat_to_px(lons, lats, g)
    c2 = A[0, 0] * c + A[0, 1] * r + A[0, 2]
    r2 = A[1, 0] * c + A[1, 1] * r + A[1, 2]
    return px_to_lonlat(c2, r2, g)


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--residuals", required=True)
    ap.add_argument("--out-root", required=True)
    ap.add_argument("--experiments", nargs="+", required=True)
    ap.add_argument("--tols", type=float, nargs="+", default=[5, 10, 15, 25],
                    help="metres of allowed deviation from the scene median displacement")
    ap.add_argument("--min-kept", type=int, default=20,
                    help="scene needs at least this many surviving matches to be scored")
    ap.add_argument("--scene-col", default="scene")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)

    rows = list(csv.DictReader(open(args.residuals)))
    by_scene = collections.defaultdict(list)
    for r in rows:
        by_scene[r[args.scene_col]].append(r)
    rpc_all = [float(r["r_rpc_m"]) for r in rows if r.get("r_rpc_m") not in ("", None)]

    tol_labels = [("inf", float("inf"))] + [(f"{t:g}m", t) for t in args.tols]
    lines = ["CE90 — median-relative match filter (refit + tie-point transfer)", ""]
    lines.append(f"RPC-ellip baseline (all points): CE90 {stats(rpc_all)['ce90']:.2f}  "
                 f"median {stats(rpc_all)['median']:.2f}  n {stats(rpc_all)['n']}")

    for exp in args.experiments:
        lines.append(f"\n===== {exp} =====")
        lines.append(f"  {'tol':<8}{'n_pts':>7}{'cover':>7}{'median':>9}{'rmse':>9}{'ce90':>9}{'p95':>9}"
                     f" |{'sys_ce90':>9}{'sys_med':>8}{'sys_rmse':>9}")
        lines.append("  " + "-" * 84)
        for lbl, tm in tol_labels:
            resid, rpc_paired, scenes_ok, scenes_tot = [], [], 0, 0
            sys_res = []          # SYSTEM: learned where scored, RPC fallback elsewhere
            for scene, pts in by_scene.items():
                rpc_scene = [float(p["r_rpc_m"]) for p in pts
                             if p.get("r_rpc_m") not in ("", None)]
                run_dir = os.path.join(args.out_root, exp, scene)
                if not os.path.exists(os.path.join(run_dir, "matches.csv")):
                    sys_res.extend(rpc_scene)      # no run -> fallback
                    continue
                scenes_tot += 1
                tf, src, dst = load_run(run_dir)
                g = tf["grid_transform"]
                tol_px = (tm / m_per_px(g)) if np.isfinite(tm) else np.inf
                A, nkept, ntot = median_filter_fit(src, dst, tol_px)
                if A is None or nkept < args.min_kept:
                    sys_res.extend(rpc_scene)      # filtered out -> fallback
                    continue
                scenes_ok += 1
                lons = np.array([float(p["lon_rpc"]) for p in pts])
                lats = np.array([float(p["lat_rpc"]) for p in pts])
                rlon, rlat = refine(lons, lats, A, g)
                for i, p in enumerate(pts):
                    rm = haversine_m(rlon[i], rlat[i],
                                     float(p["lon_eo"]), float(p["lat_eo"]))
                    resid.append(rm)
                    sys_res.append(rm)
                    rpc_paired.append(float(p["r_rpc_m"]))
            st = stats(resid)
            sy = stats(sys_res)
            cover = f"{scenes_ok}/{scenes_tot}"
            lines.append(f"  {lbl:<8}{st['n']:>7}{cover:>7}{st['median']:>9.2f}"
                         f"{st['rmse']:>9.2f}{st['ce90']:>9.2f}{st['p95']:>9.2f}"
                         f" |{sy['ce90']:>9.2f}{sy['median']:>8.2f}{sy['rmse']:>9.2f}")
        # paired RPC on the widest (inf) set for reference already shown as baseline

    txt = "\n".join(lines)
    with open(os.path.join(args.out, "summary.txt"), "w") as f:
        f.write(txt + "\n")
    print(txt)
    print(f"\n[out] {args.out}/summary.txt")


if __name__ == "__main__":
    main()
