#!/usr/bin/env python3
"""Height-aware block registration: RPC-ellip SAR -> WV, DEM altitude ladder.

    python run_height_aware.py --scene <scene-ID> [--warp global_affine|tps]

Uses the DEM to harvest correspondences from NEAR-GROUND pixels first (where the
RPC-ellipsoid ortho is most trustworthy — elevated terrain carries residual
layover/parallax displacement), and only admits higher terrain rung-by-rung if
the scene doesn't yield enough points.

Pipeline:
    1. co-locate SAR(rpc_ellip) + WV + DEM on one common 4326 grid
    2. preprocess; tile; region-select by post-Lee texture
    3. HARVEST: RoMa-match every kept block ONCE (GPU); attach DEM height to
       every raw correspondence
    4. LADDER (pure CPU, no re-matching): for each per-scene DEM percentile rung
       (P30 -> P50 -> P70 -> P85 -> all): height-filter -> per-block RANSAC +
       gates -> consensus -> pool; stop at the first rung with enough points
    5. fit warp (global affine baseline | TPS) on the winning pool; resample;
       write georeferenced GeoTIFF + report (incl. per-rung yield table)

Height filtering runs BEFORE per-block RANSAC so displaced high-altitude points
cannot steer the block affines.
"""
import argparse
import collections
import json
import os

import numpy as np

from config import Config
import io_geo
import preprocessing as pp
from region_select import tile, select_regions, nodata_mask, cloud_mask
from matchers import build_matcher
import block_register as br
import warp as wp
import height_ladder as hl

# Defaults from the project layout (all overridable).
DEF_SAR_ROOT = "/home/tabtahi/SATLOCK/dataset/SAR_RPC_ellip"
DEF_DEM_ROOT = "/home/tabtahi/SATLOCK/dataset/SAR_RPC_ellip_dem"
DEF_WV_ROOT = ("/home/kashley/satlock/mosaic_datasets/"
               "eo_sar_umbra_subset_HH_unique_v2/wv_dailytake_output")


def default_paths(scene):
    import glob
    sar = f"{DEF_SAR_ROOT}/{scene}/{scene}_rpc_ellip.tif"
    dem = f"{DEF_DEM_ROOT}/{scene}/{scene}_dem_ellip.tif"
    wv_hits = sorted(glob.glob(f"{DEF_WV_ROOT}/{scene}/mosaic/*.tif"))
    wv = wv_hits[0] if wv_hits else None
    return sar, dem, wv


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--scene", help="scene-ID (derives sar/dem/wv paths)")
    ap.add_argument("--sar", help="explicit SAR rpc_ellip GeoTIFF")
    ap.add_argument("--dem", help="explicit DEM ellip GeoTIFF")
    ap.add_argument("--wv", help="explicit WV mosaic GeoTIFF")
    ap.add_argument("--warp", default="global_affine", choices=["global_affine", "tps"])
    ap.add_argument("--matcher", default="roma", choices=["roma", "xoftr"],
                    help="dense RoMa (default) or semi-dense XoFTR — same ladder/gates")
    ap.add_argument("--xoftr-ckpt", default="/opt/weights/weights_xoftr_640.ckpt")
    ap.add_argument("--common-gsd", type=float, default=0.5)
    ap.add_argument("--conf-thresh", type=float, default=0.20)
    ap.add_argument("--min-points", type=int, default=200)
    ap.add_argument("--rungs", type=float, nargs="+", default=[30, 50, 70, 85, 100],
                    help="per-scene DEM percentile ladder (select=ladder only)")
    ap.add_argument("--select", default="ladder", choices=["ladder", "all", "nostruct"],
                    help="point selection: ladder (height rungs) | all (no selection) | "
                         "nostruct (exclude tall man-made structure via DEM roughness)")
    ap.add_argument("--struct-window", type=int, default=5,
                    help="nostruct: roughness window (px on the common grid)")
    ap.add_argument("--struct-thresh", type=float, default=8.0,
                    help="nostruct: local height range (m) above which = structure")
    ap.add_argument("--max-disp-m", type=float, default=None,
                    help="discard correspondences whose implied shift exceeds this "
                         "(meters); physical sanity gate for all/nostruct experiments")
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--block", type=int, default=None,
                    help="block size in common-grid px (default 2048)")
    ap.add_argument("--no-nodata-filter", action="store_true",
                    help="keep blocks that are mostly SAR nodata")
    ap.add_argument("--no-cloud-filter", action="store_true",
                    help="keep blocks that are mostly WV cloud")
    ap.add_argument("--max-nodata-frac", type=float, default=None,
                    help="drop block if SAR nodata exceeds this fraction (default 0.80)")
    ap.add_argument("--max-cloud-frac", type=float, default=None,
                    help="drop block if WV cloud exceeds this fraction (default 0.30)")
    ap.add_argument("--no-viz", action="store_true", help="skip PNG visualization panels")
    ap.add_argument("--no-tif", action="store_true",
                    help="skip writing the registered GeoTIFF (matches/transform/report only; "
                         "use for large batches where only the fused product is kept)")
    ap.add_argument("--out", default="out_height")
    args = ap.parse_args()

    scene_sar = scene_dem = scene_wv = None
    if args.scene:
        scene_sar, scene_dem, scene_wv = default_paths(args.scene)
    sar = args.sar or scene_sar
    dem = args.dem or scene_dem
    wv = args.wv or scene_wv
    if not all([sar, wv]):
        raise SystemExit("need --scene or explicit --sar/--wv paths")
    need_dem = args.select in ("ladder", "nostruct")
    if need_dem and not dem:
        raise SystemExit(f"--select {args.select} needs a DEM; use --select all to run without one")
    checks = [("sar", sar), ("wv", wv)] + ([("dem", dem)] if (dem and need_dem) else [])
    if dem and not need_dem and not os.path.exists(dem):
        dem = None  # DEM path guessed from scene but absent — fine for select=all
    for label, p in checks:
        if not os.path.exists(p):
            raise SystemExit(f"SKIP:missing_{label} — {p}")
    os.makedirs(args.out, exist_ok=True)

    cfg = Config(device=args.device, matcher=args.matcher, reference="wv",
                 conf_thresh=args.conf_thresh, common_gsd=args.common_gsd)
    cfg.xoftr_ckpt = args.xoftr_ckpt
    if args.block is not None:
        cfg.grid.block = args.block
    if args.max_nodata_frac is not None:
        cfg.region.max_nodata_frac = args.max_nodata_frac
    if args.max_cloud_frac is not None:
        cfg.region.max_cloud_frac = args.max_cloud_frac
    cfg.warp.model = args.warp
    lcfg = hl.LadderConfig(percentiles=tuple(args.rungs), min_points=args.min_points)

    # 1. co-locate SAR + WV, then (if provided) warp the DEM onto the SAME grid
    print("[grid] co-locating SAR(rpc_ellip) + WV on a common 4326 grid")
    sar_arr, wv_arr, transform, crs = io_geo.read_on_common_grid(sar, wv, cfg.common_gsd)
    H, W = sar_arr.shape[:2]
    if dem and os.path.exists(dem):
        print(f"       grid {sar_arr.shape}; warping DEM onto it")
        dem_arr = io_geo.warp_to_grid(dem, transform, crs, W, H, resampling="bilinear")
        cutoffs = hl.rung_cutoffs(dem_arr, lcfg)
        v = dem_arr[hl.dem_valid_mask(dem_arr, lcfg)]
        print(f"[dem]  height range {v.min():.0f}..{v.max():.0f} m; "
              f"rungs {[f'P{p:g}={c:.0f}m' for p, c in zip(lcfg.percentiles, cutoffs)]}")
    else:
        dem_arr = None
        cutoffs = [float("inf")] * len(lcfg.percentiles)
        print(f"       grid {sar_arr.shape}; no DEM (select={args.select}, heights unavailable)")

    # 2. preprocess + tile + region select
    sar_rgb = pp.preprocess_sar(sar_arr, cfg.preproc)
    wv_rgb = pp.preprocess_reference(wv_arr, is_sar=False, cfg=cfg.preproc)
    blocks = tile(sar_arr.shape, cfg.grid)

    # content gates: unmatchable SAR (nodata collar) and unmatchable WV (cloud).
    # Masks are computed once scene-wide; blocks take their fraction of each.
    nd = None if args.no_nodata_filter else nodata_mask(sar_arr, cfg.region.nodata_value)
    cl = None if args.no_cloud_filter else cloud_mask(
        wv_arr, cfg.region.cloud_bright_pct, cfg.region.cloud_sat_max,
        cfg.region.cloud_min_dn)
    if nd is not None:
        print(f"[mask] SAR nodata covers {100*float(nd.mean()):.1f}% of the grid")
    if cl is not None:
        print(f"[mask] WV cloud covers {100*float(cl.mean()):.1f}% of the grid")

    blocks = select_regions(sar_rgb[..., 0], blocks, cfg.region,
                            cfg.preproc.lee_size, nodata=nd, cloud=cl)
    kept = [b for b in blocks if b.keep]
    drops = {}
    for b in blocks:
        if not b.keep:
            drops[b.reason] = drops.get(b.reason, 0) + 1
    print(f"[grid] block {cfg.grid.block}px: {len(blocks)} blocks, {len(kept)} kept"
          + (f"  dropped: {drops}" if drops else ""))
    if not kept:
        print("[FAIL] no blocks survived the content/texture gates")
        _report(args, [], hl.LadderResult(0, 0.0, 0.0, 0, 0), None)
        return

    # 3. HARVEST — RoMa once per block; attach DEM heights to every raw match
    matcher = build_matcher(cfg)
    raws = []
    for i, b in enumerate(kept):
        raw = br.harvest_block(b, sar_rgb, wv_rgb, matcher, cfg.conf_thresh)
        if len(raw.conf) and dem_arr is not None:
            origin = np.array([b.c0, b.r0], np.float32)
            raw.heights = hl.sample_heights(dem_arr, raw.src + origin)
        elif len(raw.conf):
            raw.heights = np.full(len(raw.conf), np.nan)
        else:
            raw.heights = np.zeros((0,), np.float64)
        raws.append(raw)
        if (i + 1) % 10 == 0:
            print(f"       matched {i+1}/{len(kept)} blocks "
                  f"({sum(len(r.conf) for r in raws)} raw matches so far)")
    n_raw = sum(len(r.conf) for r in raws)
    print(f"[match] {n_raw} raw correspondences from {len(raws)} blocks (GPU pass done)")

    # 4. POINT SELECTION — pure CPU refiltering, no re-matching
    ladder = hl.LadderResult(0, 0.0, 0.0, 0, 0)
    chosen = None
    keep_masks = None   # per-raw bool arrays for nostruct

    # convert the meters displacement cap to common-grid pixels (deg/px -> m/px)
    max_disp_px = None
    if args.max_disp_m is not None:
        lat0 = 0.5 * (transform.f + (transform.f + transform.e * sar_arr.shape[0]))
        m_per_px_x = abs(transform.a) * 111320.0 * max(np.cos(np.radians(lat0)), 1e-3)
        m_per_px_y = abs(transform.e) * 111320.0
        m_per_px = 0.5 * (m_per_px_x + m_per_px_y)
        max_disp_px = args.max_disp_m / m_per_px
        print(f"[gate]  max displacement {args.max_disp_m:g} m = {max_disp_px:.1f} px "
              f"({m_per_px:.2f} m/px)")

    if args.select == "nostruct":
        smask = hl.structure_mask(dem_arr, hl.dem_valid_mask(dem_arr, lcfg),
                                  window=args.struct_window, thresh_m=args.struct_thresh)
        frac = float(smask.mean())
        print(f"[struct] roughness>{args.struct_thresh:g}m in {args.struct_window}px window "
              f"flags {100*frac:.1f}% of scene as structure")
        keep_masks = []
        for r in raws:
            if len(r.conf):
                origin = np.array([r.blk.c0, r.blk.r0], np.float32)
                keep_masks.append(~hl.sample_mask(smask, r.src + origin))
            else:
                keep_masks.append(np.zeros((0,), bool))
        n_excl = sum(int((~m).sum()) for m in keep_masks)
        print(f"[struct] excluding {n_excl} of {n_raw} raw correspondences on structure")

    if args.select in ("all", "nostruct"):
        # single pass, no height cutoff; record as a one-rung "ladder" for reporting
        cutoff_all = cutoffs[-1]
        results = [br.gate_block(r, cfg.gate, height_cutoff=None,
                                 keep_mask=(keep_masks[i] if keep_masks else None),
                                 max_disp_px=max_disp_px)
                   for i, r in enumerate(raws)]
        results = br.consensus_filter(results, cfg.gate)
        src, dst, conf = br.pool(results)
        n_blk = sum(1 for r in results if r.model != "drop")
        ladder.per_rung.append((100.0, cutoff_all, len(src), n_blk))
        ladder.rung_index, ladder.percentile = 0, 100.0
        ladder.height_cutoff_m = cutoff_all
        ladder.n_points, ladder.n_blocks = len(src), n_blk
        ladder.exhausted = not (len(src) >= lcfg.min_points and n_blk >= lcfg.min_blocks)
        chosen = (results, src, dst, conf)
        print(f"[select={args.select}] {len(src)} points from {n_blk} blocks"
              + ("  [WARN: below min_points/min_blocks]" if ladder.exhausted else ""))
    else:
        for ri, (pct, cutoff) in enumerate(zip(lcfg.percentiles, cutoffs)):
            results = [br.gate_block(r, cfg.gate, height_cutoff=cutoff,
                                     max_disp_px=max_disp_px) for r in raws]
            results = br.consensus_filter(results, cfg.gate)
            src, dst, conf = br.pool(results)
            n_blk = sum(1 for r in results if r.model != "drop")
            ladder.per_rung.append((pct, cutoff, len(src), n_blk))
            print(f"[rung] P{pct:g} (<= {cutoff:.0f} m): {len(src)} points from {n_blk} blocks")
            if len(src) >= lcfg.min_points and n_blk >= lcfg.min_blocks:
                ladder.rung_index, ladder.percentile = ri, pct
                ladder.height_cutoff_m = cutoff
                ladder.n_points, ladder.n_blocks = len(src), n_blk
                chosen = (results, src, dst, conf)
                break
        if chosen is None:  # even the top rung fell short — use it anyway, flag it
            ladder.exhausted = True
            ladder.rung_index = len(cutoffs) - 1
            ladder.percentile = lcfg.percentiles[-1]
            ladder.height_cutoff_m = cutoffs[-1]
            results = [br.gate_block(r, cfg.gate, height_cutoff=cutoffs[-1],
                                     max_disp_px=max_disp_px) for r in raws]
            results = br.consensus_filter(results, cfg.gate)
            src, dst, conf = br.pool(results)
            ladder.n_points, ladder.n_blocks = len(src), sum(
                1 for r in results if r.model != "drop")
            chosen = (results, src, dst, conf)
            print(f"[warn] ladder exhausted: only {len(src)} points at the all-heights rung")

    results, src, dst, conf = chosen
    print(f"[pool] using rung P{ladder.percentile:g} "
          f"(cutoff {ladder.height_cutoff_m:.0f} m): {ladder.n_points} points")

    if len(src) < 6:
        print("[FAIL] too few correspondences even at the top rung.")
        _report(args, results, ladder, None)
        return

    # 5. warp + write + report
    # suffix encodes matcher, experiment, and disp cap: reg_R_all / reg_R_all_d10
    SUFFIX = {"roma": "reg_R", "xoftr": "reg_xf"}
    suffix = SUFFIX[args.matcher] + ("" if args.select == "ladder" else f"_{args.select}")
    if args.max_disp_m is not None:
        suffix += f"_d{args.max_disp_m:g}"
    scene_name = args.scene or os.path.splitext(os.path.basename(sar))[0]

    warped, winfo = wp.apply_warp(sar_arr, src, dst, sar_arr.shape, cfg.warp)
    if warped is None:
        print(f"[FAIL] warp failed: {winfo}")
        _report(args, results, ladder, winfo)
        return
    if args.no_tif:
        print("[out]  --no-tif: skipping registered GeoTIFF write")
    else:
        out_tif = os.path.join(args.out, f"{scene_name}_{suffix}.tif")
        try:
            io_geo.write_geotiff(out_tif, warped.astype(np.float32), transform, crs)
            print(f"[out]  wrote {out_tif}")
        except Exception as e:
            print(f"[out]  GeoTIFF write skipped ({e}); saving npy")
            np.save(os.path.join(args.out, f"{scene_name}_{suffix}.npy"), warped)

    # Persist the correction for TIE-POINT TRANSFER (CE90 candidate 3):
    #  - transform.json : the fitted pixel-space affine + the common-grid
    #    geotransform + CRS, so (lon,lat) -> refined (lon,lat) is a pure
    #    matrix path (handoff option A)
    #  - matches.csv    : every pooled correspondence with pixel AND lon/lat
    #    coords + confidence + DEM height, enabling local-flow interpolation
    #    (handoff option B) and the residual-vs-height diagnostic
    _save_correction(args.out, scene_name, suffix, args.matcher, winfo,
                     src, dst, conf, dem_arr, transform, crs,
                     grid_shape=sar_arr.shape[:2])

    if not args.no_viz:
        print("[viz]  rendering panels (overview / points / quiver / blocks / before-after)")
        import visualize_height as vz
        if dem_arr is not None:
            dem_ok = hl.dem_valid_mask(dem_arr, lcfg)
            vz.overview(sar_rgb, wv_rgb, dem_arr, dem_ok, ladder.height_cutoff_m,
                        os.path.join(args.out, "overview.png"))
            vz.points_height(sar_rgb, raws, dem_arr, dem_ok, cutoffs,
                             list(lcfg.percentiles), ladder.height_cutoff_m,
                             os.path.join(args.out, "points_height.png"))
            vz.quiver_height(raws, ladder.height_cutoff_m, sar_arr.shape,
                             os.path.join(args.out, "quiver_height.png"))
        vz.blocks_map(kept, results, sar_arr.shape,
                      os.path.join(args.out, "blocks.png"))
        warped_rgb = pp.preprocess_sar(warped, cfg.preproc)
        vz.triptych(wv_rgb, sar_rgb, warped_rgb, results, ladder.height_cutoff_m,
                    os.path.join(args.out, "triptych.png"))
        vz.before_after(sar_rgb, warped_rgb, wv_rgb,
                        os.path.join(args.out, "before_after.png"))

    _report(args, results, ladder, winfo)
    print(f"[done] report in {args.out}/report.json")


def _save_correction(out_dir, scene_name, suffix, matcher, winfo,
                     src, dst, conf, dem_arr, transform, crs, grid_shape=None):
    """Persist transform.json + matches.csv so tie points transfer without
    re-matching. Grid transform stored as the 6 rasterio Affine coeffs
    (x = a*col + b*row + c ; y = d*col + e*row + f)."""
    import csv as _csv
    T = transform  # rasterio Affine
    tf = {
        "scene": scene_name, "matcher": matcher, "suffix": suffix,
        "crs": str(crs),
        "grid_transform": [T.a, T.b, T.c, T.d, T.e, T.f],
        "grid_width": int(grid_shape[1]) if grid_shape else None,
        "grid_height": int(grid_shape[0]) if grid_shape else None,
        "warp_model": winfo.get("model"),
        "pixel_affine_2x3": winfo.get("affine"),  # SAR px -> WV px on the common grid (None for tps)
        "note": ("apply_tiepoints.py --mode affine uses pixel_affine_2x3; "
                 "--mode local interpolates matches.csv displacements (needed for tps)"),
    }
    with open(os.path.join(out_dir, "transform.json"), "w") as f:
        json.dump(tf, f, indent=2)

    import height_ladder as _hl
    if dem_arr is not None:
        heights = _hl.sample_heights(dem_arr, src)
    else:
        heights = np.full(len(src), np.nan)
    lon_s = T.a * src[:, 0] + T.b * src[:, 1] + T.c
    lat_s = T.d * src[:, 0] + T.e * src[:, 1] + T.f
    lon_d = T.a * dst[:, 0] + T.b * dst[:, 1] + T.c
    lat_d = T.d * dst[:, 0] + T.e * dst[:, 1] + T.f
    with open(os.path.join(out_dir, "matches.csv"), "w", newline="") as f:
        w = _csv.writer(f)
        w.writerow(["x_sar_px", "y_sar_px", "x_wv_px", "y_wv_px",
                    "lon_sar", "lat_sar", "lon_wv", "lat_wv", "conf", "height_m"])
        for i in range(len(src)):
            w.writerow([f"{src[i,0]:.2f}", f"{src[i,1]:.2f}",
                        f"{dst[i,0]:.2f}", f"{dst[i,1]:.2f}",
                        f"{lon_s[i]:.8f}", f"{lat_s[i]:.8f}",
                        f"{lon_d[i]:.8f}", f"{lat_d[i]:.8f}",
                        f"{conf[i]:.4f}", f"{heights[i]:.1f}" if np.isfinite(heights[i]) else "inf"])
    print(f"[out]  wrote transform.json + matches.csv ({len(src)} correspondences)")


def _report(args, results, ladder: hl.LadderResult, winfo):
    report = {
        "inputs": {"sar": args.sar or args.scene, "dem": args.dem,
                   "wv": args.wv, "warp": args.warp, "matcher": args.matcher,
                   "select": args.select,
                   "block": args.block,
                   "nodata_filter": not args.no_nodata_filter,
                   "cloud_filter": not args.no_cloud_filter,
                   "max_disp_m": args.max_disp_m,
                   "struct_window": args.struct_window if args.select == "nostruct" else None,
                   "struct_thresh_m": args.struct_thresh if args.select == "nostruct" else None},
        "ladder": {
            "rung_used": {"percentile": ladder.percentile,
                          "height_cutoff_m": ladder.height_cutoff_m,
                          "n_points": ladder.n_points, "n_blocks": ladder.n_blocks},
            "exhausted": ladder.exhausted,
            "per_rung": [{"percentile": p, "cutoff_m": c, "n_points": n, "n_blocks": b}
                         for (p, c, n, b) in ladder.per_rung],
        },
        "block_models": dict(collections.Counter(r.model for r in results)),
        "fallback_reasons": dict(collections.Counter(r.reason for r in results)),
        "warp": winfo,
    }
    with open(os.path.join(args.out, "report.json"), "w") as f:
        json.dump(report, f, indent=2)


if __name__ == "__main__":
    main()
