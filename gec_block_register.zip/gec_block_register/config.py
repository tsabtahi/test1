"""Configuration for the GEC block-registration baseline (v1).

Design recap (decisions from the brainstorm, encoded here so the pipeline reads
declaratively):

- The GRID is for harvesting correspondences, not for warping. Blocks give the
  matcher fixed-size, well-distributed inputs; every surviving match is pooled
  and a SINGLE transform is fit to the pool. No per-block warp => no seams.
- BASELINE warp = one global affine from the pooled matches. It is intentionally
  the simplest learned correction (the floor to beat raw GEC). The smooth TPS
  residual that captures spatially-varying distortion is shipped as `warp="tps"`
  for the next rung.
- Per-block RANSAC + trustworthiness GATES exist to clean the pool and to log
  WHY blocks fail (the fallback-reason histogram is the real diagnostic).
- Region selection uses post-Lee local variance/entropy to skip blocks with no
  matchable SAR structure before spending GPU on them.
"""
from dataclasses import dataclass, field


@dataclass
class PreprocConfig:
    log_transform: bool = True
    despeckle: bool = True
    lee_size: int = 5            # matches the existing metrics harness (5x5 Lee)
    edges: bool = False          # Sobel structural map (often helps cross-modal)
    pmin: float = 2.0
    pmax: float = 98.0


@dataclass
class GridConfig:
    block: int = 2048            # block size in common-grid pixels
    overlap: float = 0.25        # fractional overlap between adjacent blocks


@dataclass
class RegionConfig:
    # Skip blocks whose post-Lee texture is too low to match on. Percentile-based
    # so it normalizes across the wide GSD range (0.04-0.34 m) in the archive.
    use_region_filter: bool = True
    measure: str = "gradient_var"   # "gradient_var" | "entropy" | "variance"
    keep_percentile: float = 40.0   # keep blocks above this within-scene percentile
    min_abs: float = 1e-4           # absolute floor; below this is flat regardless
    # --- content gates, applied BEFORE the texture percentile -------------------
    # SAR nodata: GEC/ortho products carry large black collars and wedge-shaped
    # nodata from the rotated footprint. A block that is mostly nodata yields
    # matches only on the collar edge, which are geometrically meaningless.
    max_nodata_frac: float = 0.80   # drop block if >this fraction of SAR is nodata
    nodata_value: float = 0.0
    # WV cloud: cloud tops match nothing in SAR, and bright smooth cloud reliably
    # produces high-confidence false correspondences (the ocean-scene failure).
    max_cloud_frac: float = 0.30    # drop block if >this fraction of WV is cloud
    cloud_bright_pct: float = 88.0  # scene-wide brightness percentile = cloud floor
    cloud_sat_max: float = 0.20     # clouds are bright AND desaturated (RGB only)
    cloud_min_dn: float = 0.35      # abs floor (0-1) so dark scenes aren't all "cloud"


@dataclass
class GateConfig:
    # Per-block affine trustworthiness gates (see block_register.py).
    ransac_thresh: float = 3.0
    min_inliers_affine: int = 15    # below -> not enough for a stable 6-DOF fit
    min_inliers_trans: int = 4      # below -> drop the block entirely
    aniso_min: float = 0.10         # lambda2/lambda1 of inlier spread (collinearity)
    hull_frac_min: float = 0.20     # inlier convex-hull area / block area
    cond_max: float = 1e3           # condition number of the affine design
    sv_lo: float = 0.90             # affine 2x2 singular values must sit in...
    sv_hi: float = 1.10             # ...[sv_lo, sv_hi] (few-percent scale error)
    rot_deg_max: float = 8.0        # plausible local rotation
    consensus_mad_k: float = 4.0    # block-displacement outlier rejection (gate 5)


@dataclass
class WarpConfig:
    model: str = "global_affine"    # "global_affine" (baseline) | "tps"
    ransac_thresh: float = 3.0
    tps_smoothing: float = 1.0       # RBF smoothing; higher = stiffer field


@dataclass
class Config:
    device: str = "cuda"
    matcher: str = "roma"            # "roma" | "xoftr"
    xoftr_ckpt: str = "/opt/weights/weights_xoftr_640.ckpt"  # used when matcher=xoftr
    reference: str = "gold"          # "gold" (SAR, easier, validation) | "wv" (EO, deployable)
    conf_thresh: float = 0.20        # matcher confidence/certainty floor
    common_gsd: float = 0.5          # meters; common working resolution per pair
    preproc: PreprocConfig = field(default_factory=PreprocConfig)
    grid: GridConfig = field(default_factory=GridConfig)
    region: RegionConfig = field(default_factory=RegionConfig)
    gate: GateConfig = field(default_factory=GateConfig)
    warp: WarpConfig = field(default_factory=WarpConfig)
