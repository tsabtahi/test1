#!/usr/bin/env python3
"""Build a complete scene manifest for SAR_learned.

One entry per scene, always with a usable product path:
  * fused   -> the learned fused product (<scene>_reg_fused.tif)
  * fallback-> the RPC-ellipsoid product; if that is missing too, the raw GEC
Also carries the scene centre lon/lat + bbox (read from the product header),
the decision, the agreement metre value, and the fallback reason.

    python build_scene_manifest.py \
        --learned-root /home/tabtahi/SATLOCK/dataset/SAR_learned \
        --sar-root     /home/tabtahi/SATLOCK/dataset/SAR_RPC_ellip \
        --gec-root     /home/kashley/satlock/mosaic_datasets/eo_sar_umbra_subset_HH_unique_v2/SAR \
        --out /home/tabtahi/SATLOCK/dataset/SAR_learned/scene_manifest.json

Outputs scene_manifest.json (+ .csv alongside) with a summary block:
  {"generated": ..., "counts": {...}, "scenes": [ {...}, ... ]}
"""
import argparse
import csv
import datetime
import glob
import json
import os

import rasterio
from rasterio.warp import transform_bounds


def geo_info(path):
    """centre lon/lat + bbox in EPSG:4326; None if unreadable."""
    try:
        with rasterio.open(path) as ds:
            b = ds.bounds
            if ds.crs is None:
                return None
            w, s, e, n = transform_bounds(ds.crs, "EPSG:4326", *b, densify_pts=21)
            return dict(lon=round((w + e) / 2, 6), lat=round((s + n) / 2, 6),
                        bbox=[round(w, 6), round(s, 6), round(e, 6), round(n, 6)],
                        width=ds.width, height=ds.height,
                        crs=str(ds.crs))
    except Exception:
        return None


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--learned-root", required=True)
    ap.add_argument("--sar-root", required=True, help="SAR_RPC_ellip root (fallback product)")
    ap.add_argument("--gec-root", default=None, help="raw GEC root (last-resort fallback)")
    ap.add_argument("--wv-root", default=None,
                    help="WV archive root; each scene at <wv-root>/<scene>/mosaic/*.tif")
    ap.add_argument("--no-geo", action="store_true",
                    help="skip reading raster headers (much faster, no lon/lat)")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    scenes = sorted(os.path.basename(d) for d in glob.glob(os.path.join(args.learned_root, "*"))
                    if os.path.isdir(d))
    entries, counts = [], dict(fused=0, fallback_rpc=0, fallback_gec=0, missing=0, with_wv=0)

    for i, s in enumerate(scenes, 1):
        sdir = os.path.join(args.learned_root, s)
        fused_tif = os.path.join(sdir, f"{s}_reg_fused.tif")
        rpc_tif = os.path.join(args.sar_root, s, f"{s}_rpc_ellip.tif")

        e = dict(scene=s)
        if os.path.exists(fused_tif):
            e.update(product=fused_tif, product_type="fused_learned", decision="fused")
            counts["fused"] += 1
            fj = os.path.join(sdir, "fused.json")
            if os.path.exists(fj):
                try:
                    d = json.load(open(fj))
                    e["agreement_m"] = round(float(d.get("agreement_m", float("nan"))), 3)
                    e["medfilter_tol_m"] = d.get("medfilter_tol_m")
                    e["agree_tol_m"] = d.get("agree_tol_m")
                except Exception:
                    pass
        else:
            reason = None
            fb = os.path.join(sdir, "fallback.json")
            if os.path.exists(fb):
                try:
                    reason = json.load(open(fb)).get("reason")
                except Exception:
                    pass
            if os.path.exists(rpc_tif):
                e.update(product=rpc_tif, product_type="rpc_ellipsoid",
                         decision="fallback", fallback_reason=reason)
                counts["fallback_rpc"] += 1
            else:
                gec = None
                if args.gec_root:
                    hits = glob.glob(os.path.join(args.gec_root, s, "*_GEC.tif")) \
                        or glob.glob(os.path.join(args.gec_root, s, "*.tif"))
                    gec = hits[0] if hits else None
                if gec:
                    e.update(product=gec, product_type="gec_raw",
                             decision="fallback", fallback_reason=reason)
                    counts["fallback_gec"] += 1
                else:
                    e.update(product=None, product_type=None,
                             decision="unavailable", fallback_reason=reason)
                    counts["missing"] += 1

        # paired WorldView reference (the EO image this scene was registered to)
        if args.wv_root:
            hits = sorted(glob.glob(os.path.join(args.wv_root, s, "mosaic", "*.tif")))
            e["wv"] = hits[0] if hits else None
            if len(hits) > 1:
                e["wv_all"] = hits
            if hits:
                counts["with_wv"] = counts.get("with_wv", 0) + 1

        if not args.no_geo and e.get("product"):
            g = geo_info(e["product"])
            if g:
                e.update(g)
            if e.get("wv"):
                gw = geo_info(e["wv"])
                if gw:
                    e["wv_bbox"] = gw["bbox"]
                    e["wv_size"] = [gw["width"], gw["height"]]
        entries.append(e)
        if i % 200 == 0:
            print(f"  ...{i}/{len(scenes)}", flush=True)

    out = dict(generated=datetime.datetime.utcnow().isoformat() + "Z",
               learned_root=args.learned_root, sar_root=args.sar_root,
               gec_root=args.gec_root,
               counts=dict(counts, total=len(entries)),
               scenes=entries)
    with open(args.out, "w") as f:
        json.dump(out, f, indent=2)

    csv_path = os.path.splitext(args.out)[0] + ".csv"
    cols = ["scene", "decision", "product_type", "product", "wv", "lon", "lat",
            "agreement_m", "fallback_reason"]
    with open(csv_path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        w.writerows(entries)

    print(f"\n{counts['fused']} fused | {counts['fallback_rpc']} rpc-ellip fallback | "
          f"{counts['fallback_gec']} gec fallback | {counts['missing']} unavailable "
          f"| total {len(entries)}")
    if args.wv_root:
        print(f"paired WV found for {counts.get('with_wv', 0)} / {len(entries)} scenes")
    print(f"[out] {args.out}\n[out] {csv_path}")


if __name__ == "__main__":
    main()
