"""Matchers: XoFTR and RoMa behind one interface.

Both take two HxWx3 uint8 block crops (A = GEC, B = reference) and return
correspondences (kpts_a, kpts_b, confidence) in BLOCK-LOCAL pixel coords. The
block-register stage globalizes them by adding the block origin.

Lazy imports so the geometry/synthetic test runs without torch/RoMa/XoFTR.

RoMa setup (geohub3):  pip install git+https://github.com/Parskatt/RoMa.git
  NOTE: pass use_custom_corr=False (or patch modules) — the fast `local_corr`
  CUDA kernel isn't pip-installed and crashes on Linux otherwise.
XoFTR setup:  git clone https://github.com/OnderT/XoFTR ; download 640/840 ckpt.
  Import lower_config from src.utils.data_io (avoids a pytorch_lightning import).
"""
from dataclasses import dataclass, field

import numpy as np


@dataclass
class Matches:
    kpts_a: np.ndarray              # (N,2) GEC block-local x,y
    kpts_b: np.ndarray              # (N,2) reference block-local x,y
    conf: np.ndarray               # (N,)
    meta: dict = field(default_factory=dict)

    def __len__(self):
        return len(self.conf)


class RoMaMatcher:
    name = "roma"

    def __init__(self, device="cuda", max_matches=5000):
        self.device, self.max_matches, self._m = device, max_matches, None

    def _load(self):
        if self._m is not None:
            return
        import torch
        from romatch import roma_outdoor
        self._m = roma_outdoor(device=self.device, use_custom_corr=False)
        for mod in self._m.modules():
            if hasattr(mod, "use_custom_corr"):
                mod.use_custom_corr = False
        self._torch = torch

    def match(self, a_rgb, b_rgb):
        self._load()
        import tempfile, os
        from PIL import Image
        with tempfile.TemporaryDirectory() as td:
            pa, pb = os.path.join(td, "a.png"), os.path.join(td, "b.png")
            Image.fromarray(a_rgb).save(pa)
            Image.fromarray(b_rgb).save(pb)
            Ha, Wa = a_rgb.shape[:2]
            Hb, Wb = b_rgb.shape[:2]
            warp, cert = self._m.match(pa, pb, device=self.device)
            matches, conf = self._m.sample(warp, cert, num=self.max_matches)
            ka, kb = self._m.to_pixel_coordinates(matches, Ha, Wa, Hb, Wb)
        ka, kb = ka.cpu().numpy(), kb.cpu().numpy()
        conf = conf.cpu().numpy().reshape(-1)
        if conf.size and conf.max() > 1:
            conf = conf / conf.max()
        return Matches(ka, kb, conf, {"matcher": self.name})


class XoFTRMatcher:
    name = "xoftr"

    def __init__(self, device="cuda", ckpt=None, coarse_thr=0.3, fine_thr=0.1):
        self.device, self.ckpt = device, ckpt
        self.coarse_thr, self.fine_thr, self._m = coarse_thr, fine_thr, None

    def _load(self):
        if self._m is not None:
            return
        import torch
        from src.xoftr import XoFTR
        from src.config.default import get_cfg_defaults
        from src.utils.data_io import lower_config
        cfg = lower_config(get_cfg_defaults(inference=True))
        cfg["xoftr"]["match_coarse"]["thr"] = self.coarse_thr
        cfg["xoftr"]["fine"]["thr"] = self.fine_thr
        cfg["xoftr"]["fine"]["denser"] = False
        m = XoFTR(config=cfg["xoftr"])
        m.load_state_dict(torch.load(self.ckpt, map_location="cpu")["state_dict"], strict=True)
        self._m = m.eval().to(self.device)
        self._torch = torch

    def match(self, a_rgb, b_rgb):
        self._load()
        import cv2
        t = self._torch
        # XoFTR wants grayscale (1,1,H,W) in [0,1], H/W divisible by 8.
        a = self._pad8(cv2.cvtColor(a_rgb, cv2.COLOR_RGB2GRAY))
        b = self._pad8(cv2.cvtColor(b_rgb, cv2.COLOR_RGB2GRAY))
        ta = t.from_numpy(a)[None][None].float().to(self.device) / 255.
        tb = t.from_numpy(b)[None][None].float().to(self.device) / 255.
        batch = {"image0": ta, "image1": tb}
        with t.no_grad():
            self._m(batch)
        ka = batch["mkpts0_f"].cpu().numpy()
        kb = batch["mkpts1_f"].cpu().numpy()
        conf = batch["mconf_f"].cpu().numpy().reshape(-1)
        if conf.size and conf.max() > 1:
            conf = conf / conf.max()
        return Matches(ka, kb, conf, {"matcher": self.name})

    @staticmethod
    def _pad8(g):
        h, w = g.shape
        H, W = (h + 7) // 8 * 8, (w + 7) // 8 * 8
        out = np.zeros((H, W), g.dtype)
        out[:h, :w] = g
        return out


def build_matcher(cfg):
    if cfg.matcher == "roma":
        return RoMaMatcher(device=cfg.device)
    if cfg.matcher == "xoftr":
        return XoFTRMatcher(device=cfg.device, ckpt=cfg.xoftr_ckpt)
    raise ValueError(f"unknown matcher {cfg.matcher}")
