"""Region selection + block tiling.

Region selection answers "where is there matchable SAR structure?" using a
texture measure on the despeckled SAR, so we don't spend GPU matching flat
water/smooth/layover blocks. Measures (per block):

- gradient_var : variance of Sobel magnitude  (default; sees field/terrain edges
                 that OSM can't, rewards distributed structure not lone scatterers)
- entropy      : Shannon entropy of the intensity histogram
- variance     : raw intensity variance (cheapest; biased toward bright targets)

Selection is PERCENTILE-based within the scene so a single threshold behaves
consistently across the wide GSD range. It is a PRIOR (where to look), not the
answer — matcher inlier ratio per block is the posterior that actually decides.

Caveat carried from the brainstorm: an empty/low-texture block means "no prior",
not "definitely skip" — but for the baseline we do skip below the floor to keep
compute bounded, and log the skip so coverage is auditable.
"""
from dataclasses import dataclass

import numpy as np

from config import GridConfig, RegionConfig
from preprocessing import lee_filter, sobel_mag


@dataclass
class Block:
    r0: int
    c0: int          # top-left in common-grid pixels
    h: int
    w: int
    score: float = 0.0
    keep: bool = True
    reason: str = "keep"        # keep | nodata | cloud | low_texture
    nodata_frac: float = 0.0
    cloud_frac: float = 0.0

    @property
    def slice(self):
        return (slice(self.r0, self.r0 + self.h), slice(self.c0, self.c0 + self.w))


def tile(shape, cfg: GridConfig):
    """Overlapping blocks covering an HxW grid."""
    H, W = shape[:2]
    step = max(1, int(round(cfg.block * (1 - cfg.overlap))))
    blocks = []
    for r0 in range(0, max(1, H - 1), step):
        for c0 in range(0, max(1, W - 1), step):
            h = min(cfg.block, H - r0)
            w = min(cfg.block, W - c0)
            if h < cfg.block // 2 or w < cfg.block // 2:
                continue  # drop slivers at the far edges
            blocks.append(Block(r0, c0, h, w))
    return blocks


def _block_score(sar_gray, blk: Block, measure, lee_size=5):
    patch = sar_gray[blk.slice].astype(np.float32)
    if patch.size == 0:
        return 0.0
    den = lee_filter(patch, lee_size)
    if measure == "variance":
        return float(np.var(den))
    if measure == "entropy":
        hist, _ = np.histogram(den, bins=64, range=(den.min(), den.max() + 1e-6))
        p = hist / max(hist.sum(), 1)
        p = p[p > 0]
        return float(-(p * np.log2(p)).sum())
    # gradient_var (default)
    return float(np.var(sobel_mag(den)))


def nodata_mask(sar_gray, nodata_value=0.0):
    """True where the SAR carries no data (black collar / rotated-footprint wedge)."""
    a = sar_gray
    if a.ndim == 3:
        a = a.mean(2)
    return ~np.isfinite(a) | (a <= nodata_value)


def cloud_mask(wv, bright_pct=88.0, sat_max=0.20, min_dn=0.35):
    """Scene-wide cloud mask for the WV reference.

    Cloud is bright AND desaturated AND (implicitly) scene-relatively extreme.
    The brightness floor is a SCENE percentile so it adapts to exposure, with an
    absolute floor so a uniformly dark scene doesn't report its brightest 12% as
    cloud. On single-band WV the saturation test is skipped (brightness only).
    """
    a = wv.astype(np.float32)
    if a.max() > 1.5:                       # assume 0-255 -> normalize
        a = a / 255.0
    if a.ndim == 3 and a.shape[2] >= 3:
        mx, mn = a[..., :3].max(2), a[..., :3].min(2)
        bright = a[..., :3].mean(2)
        sat = (mx - mn) / np.maximum(mx, 1e-6)
    else:
        bright = a if a.ndim == 2 else a[..., 0]
        sat = np.zeros_like(bright)
    v = bright[np.isfinite(bright) & (bright > 0)]
    if v.size == 0:
        return np.zeros(bright.shape, bool)
    thr = max(float(np.percentile(v, bright_pct)), float(min_dn))
    return (bright >= thr) & (sat <= sat_max)


def _frac(mask, blk: Block):
    sub = mask[blk.slice]
    return float(sub.mean()) if sub.size else 0.0


def select_regions(sar_gray, blocks, cfg: RegionConfig, lee_size=5,
                   nodata=None, cloud=None):
    """Mark keep/skip per block.

    Order matters: CONTENT gates (nodata, cloud) run first and are absolute —
    a mostly-black or mostly-cloud block is unmatchable regardless of texture.
    The texture percentile is then computed over the SURVIVING blocks only, so a
    scene that is half nodata doesn't drag its own threshold down.
    """
    if not cfg.use_region_filter:
        for b in blocks:
            b.keep, b.reason = True, "keep"
        return blocks

    eligible = []
    for b in blocks:
        if nodata is not None:
            b.nodata_frac = _frac(nodata, b)
            if b.nodata_frac > cfg.max_nodata_frac:
                b.keep, b.reason = False, "nodata"
                continue
        if cloud is not None:
            b.cloud_frac = _frac(cloud, b)
            if b.cloud_frac > cfg.max_cloud_frac:
                b.keep, b.reason = False, "cloud"
                continue
        eligible.append(b)

    if not eligible:
        return blocks
    scores = np.array([_block_score(sar_gray, b, cfg.measure, lee_size) for b in eligible])
    thr = max(np.percentile(scores, cfg.keep_percentile), cfg.min_abs)
    for b, s in zip(eligible, scores):
        b.score = s
        b.keep = s >= thr
        b.reason = "keep" if b.keep else "low_texture"
    return blocks
