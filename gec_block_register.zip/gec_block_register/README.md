# GEC Block-Registration — v1 Baseline

Learned, block-wise registration of raw **GEC SAR** to a reference (hand-aligned
**gold** SAR, or **WV** EO), replacing the RPC+DEM re-projection that degraded
alignment. Built from the brainstorm decisions; this is the **baseline rung**.

## The one idea that makes it work

**The grid harvests correspondences; it does NOT warp.** Seams only appear if you
fit a transform per block and warp each block separately. We don't. Overlapping
blocks give the matcher well-distributed, fixed-size inputs; every surviving match
is **pooled** and a **single** transform is fit to the whole pool. No per-block
warp ⇒ no seams.

```
co-locate GEC + ref on one 4326 grid (WarpedVRT)
      → preprocess (log → Lee → [Sobel] → stretch)
      → tile into overlapping blocks + region-select by post-Lee texture
      → match each block (RoMa / XoFTR)
      → per-block RANSAC affine + TRUSTWORTHINESS GATES  ← cleans the pool, logs why
      → consensus filter (drop blocks that disagree with the scene)
      → POOL clean correspondences → ONE transform → resample GEC
      → score vs gold (SSIM/NCC) + per-block fallback report
```

## Baseline vs next rung (one flag)

- `--warp global_affine` **(baseline)** — a single RANSAC affine on the pooled
  matches. Simplest learned correction, the floor to beat raw GEC. Intentionally
  *cannot* model terrain/layover-driven local distortion — that's the point of a
  baseline.
- `--warp tps` **(next)** — global affine **+** a smooth thin-plate-spline residual
  over the pooled displacements. One continuous field (no seams) that captures the
  spatially-varying correction. Already shipped; flip the flag once the baseline
  proves out.

The synthetic test confirms the ordering holds end-to-end: alignment NCC goes
raw `0.64` → affine `0.85` → tps `1.00`.

## Trustworthiness gates (per block)

A block-affine must pass all of these or it's downgraded/dropped — these catch the
confident-liar blocks that a low inlier-RMSE hides:

| gate | rejects | on fail |
|---|---|---|
| ≥15 inliers | noise-fit affines | downgrade→translation |
| spread / anisotropy + hull coverage | collinear matches (great fit along a line, garbage off it) | downgrade→translation |
| condition number | ill-conditioned fits | downgrade→translation |
| 2×2 SVD plausibility (scale∈[0.9,1.1], small rotation, det>0) | RANSAC locked onto a wrong-but-consistent set | **drop** |
| neighbor/scene consensus (MAD on displacement) | repeated-structure mismatches | **drop** |

Downgrade keeps the point pairs (the matches are fine, only the 6-DOF *model* is
locally unsupported); drop discards them (likely wrong). **The fallback-reason
histogram in `report.json` is the real diagnostic** — if most blocks fail on
spread, blocks are too small/texture-poor; if on SVD, the matcher is producing
garbage and no warp will save it.

## Region selection

Post-Lee local **gradient variance** (default), entropy, or variance, percentile-
thresholded within the scene (normalizes the 0.04–0.34 m GSD range). Skips flat
water/smooth/layover blocks before spending GPU. It's a prior (where to look) —
the matcher inlier ratio per block is the posterior that decides.

## Run

```bash
pip install -r requirements.txt          # + RoMa/XoFTR on geohub3 (see requirements)

# Validate on GEC↔gold first (same-modality, easier), score against gold:
python run_baseline.py \
    --gec  .../SAR/<scene>/<scene>_GEC.tif \
    --ref  .../aligned_92_pa/SAR/<scene>/<scene>_GEC.tif \
    --reference gold --matcher roma --warp global_affine --out out/

# Deployable cross-modal target (GEC↔WV), still scored against gold:
python run_baseline.py --gec .../GEC.tif --ref .../wv_mosaic.tif \
    --gold .../aligned_92_pa/.../GEC.tif --reference wv --matcher roma --out out/
```

Outputs: `gec_registered.tif` (georeferenced), `report.json` (block models,
fallback-reason histogram, pooled inliers, warp matrix, SSIM/NCC vs gold).

## Height-aware registration (DEM altitude ladder)

`run_height_aware.py` registers the **RPC-ellip SAR to WV** harvesting
correspondences from **near-ground pixels first** — the ortho is most trustworthy
there, while elevated terrain carries residual layover/parallax displacement that
biases the fit. RoMa matches each block **once** (GPU); the altitude ladder is
pure CPU post-filtering on cached matches with DEM heights attached, so climbing
a rung never re-matches. Height filtering runs BEFORE per-block RANSAC so
displaced elevated points cannot steer the block affines.

```bash
python run_height_aware.py --scene <scene-ID>          # derives sar/dem/wv paths
python run_height_aware.py --sar .../x_rpc_ellip.tif --dem .../x_dem_ellip.tif \
    --wv .../mosaic/wv.tif --warp global_affine --min-points 200
```

Ladder = per-scene DEM percentiles (default P30→P50→P70→P85→all), stopping at the
first rung with ≥`--min-points` pooled points from ≥4 blocks. `report.json` logs
the per-rung yield table and which rung/height-cutoff was used — the diagnostic
for how terrain-limited each scene is.

Verified synthetically: on gradual terrain with height-proportional sub-RANSAC-
threshold displacement, the unfiltered fit is biased **0.69 px** while the ladder
recovers the ground transform to **0.08 px** (RANSAC alone cannot reject the
contamination in that regime; it can when elevated offsets are large + minority).

### Docker (GPU, swappable matcher)

`Dockerfile.register` builds a self-contained GPU image: torch base + rasterio
wheels (own GDAL — sidesteps the numpy<2 vs torch fight), **RoMa and XoFTR
weights baked at build time** so runtime needs no network (build on geohub3).

```bash
docker build -t height-register -f Dockerfile.register .

docker run --rm --gpus all \
  -v /home/tabtahi/SATLOCK/dataset:/home/tabtahi/SATLOCK/dataset \
  -v /home/kashley/satlock/mosaic_datasets:/home/kashley/satlock/mosaic_datasets \
  -v $PWD/out_height:/work/out_height \
  height-register --scene <scene-ID> --matcher roma          # or: --matcher xoftr
```

The matcher is a run-time flag, not a build-time choice — both live in one image
behind the same `Matches` contract, so ladder/gates/warp are identical and RoMa
vs XoFTR is a clean A/B on the same scene.

## Metrics comparison (GEC vs RPC-ellip vs USGS-10m)



`run_metrics.py` scores multiple geocoded products against a reference over N
matched 512px crops and prints the project comparison table:

```bash
python run_metrics.py --n-crops 100 --reference gold --out metrics_out/
# override any path:
python run_metrics.py --n-crops 100 --reference gold \
    --gec-dir      .../eo_sar_umbra_subset_HH_unique_v2/SAR \
    --rpc-ellip-dir .../eo_sar_umbra_subset_HH_unique_v2_rpc_ellip/SAR_RPC_ellip \
    --usgs-dir     .../eo_sar_umbra_subset_HH_unique_v2_USGS10m/SAR_RPC \
    --gold-dir     .../eo_sar_umbra_subset_HH_unique_v2_aligned_92_pa/SAR
```

Every product is warped onto the reference's native grid (reference not resampled)
so the same crop window is pixel-comparable; scenes are joined by their <scene-ID>
folder. Crops are chosen where ALL products + reference are valid and textured.

- `--reference gold` (default): accuracy vs ground truth — RPC-ellip / USGS should
  BEAT GEC if ortho helps. Reports SSIM / NCC / gradient-NCC medians + win% vs GEC.
- `--reference gec`: deviation of each ortho from raw GEC (GEC drops as a column).

Outputs: `per_crop.csv` (every crop × product) and `summary.json` (per-product
median/mean + win-rate). Default paths point at the geohub3 layout; all overridable.



```bash
python test_geometry.py
```
Drives the real pooling / gates / consensus / warp / metrics code with synthetic
correspondences. Validates everything except the matcher and GDAL IO.

## Layout

```
config.py          all knobs (grid, region, gates, warp)
io_geo.py          WarpedVRT co-location to a common 4326 grid + GeoTIFF write
preprocessing.py   log / Lee / Sobel / stretch
region_select.py   post-Lee texture scoring + block tiling
matchers/          RoMa + XoFTR behind one interface (lazy-imported)
block_register.py  per-block match → RANSAC affine → gates → consensus → pool
warp.py            pooled global affine (baseline) | TPS residual (next)
metrics.py         SSIM / NCC vs gold
run_baseline.py    end-to-end CLI
test_geometry.py   synthetic verification of the geometry
```

## Known limitations (deliberately deferred to v2)

- **No coarse pre-alignment.** If the GEC↔ref offset exceeds the block overlap,
  a block's true match can fall outside it. Baseline uses large (1024px) blocks to
  absorb modest offsets; a whole-scene low-res pre-align to bound the offset is the
  first v2 add.
- **Baseline warp is global.** The spatially-varying correction needs `--warp tps`
  (shipped) or a per-block smooth affine field (Lie-algebra interpolation, v2).
- **Consensus gate is scene-global** (MAD on displacement), not true spatial-
  neighbor agreement — the cheaper proxy for the baseline.
- **GSD→degrees** uses a flat-earth approximation per scene; a metric CRS is the
  cleaner v2.

## Environment (geohub3 / GDAL container)

- `osgeo/gdal:ubuntu-small` lacks pip → `apt install python3-pip` first; pip 22 has
  no `--break-system-packages`.
- Pin `numpy<2` for the GDAL bindings' ABI.
- RoMa: `pip install git+https://github.com/Parskatt/RoMa.git`, and pass
  `use_custom_corr=False` (handled in `matchers/`) — the `local_corr` CUDA kernel
  isn't pip-installed.
- GEC rotated/odd transforms → always read via WarpedVRT (done in `io_geo`).
- numpy 2.x: `np.ptp(arr)` not `arr.ptp()`.
```
