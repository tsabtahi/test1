#!/bin/bash
# Multi-GPU batch: shard all triple-complete scenes across every visible GPU.
# One worker per GPU; each worker runs BOTH matchers (roma then xoftr) for its
# scenes, pinned to its device. Resumable (report.json = done). Flap-tolerant
# (3 tries per run). Workers never collide: scenes are assigned by index modulo.
#
#   ./run_multi_gpu.sh            # auto-detect GPU count
#   ./run_multi_gpu.sh 2          # or force a count
#
# Monitor:  tail -f logs/gpu_worker_*.log
# Stop:     pkill -f run_multi_gpu.sh ; docker kill $(docker ps -q --filter ancestor=height-register)
set -u
cd /home/tabtahi/SATLOCK/gec_block_register
mkdir -p out_height/roma out_height/xoftr logs

NGPU=${1:-$(nvidia-smi -L 2>/dev/null | wc -l)}
if [ "$NGPU" -lt 1 ]; then echo "no GPUs visible (nvidia-smi -L empty)"; exit 1; fi
echo "$(date)  sharding across ${NGPU} GPU(s)"

# inventory (DEM file drives eligibility; SAR+WV must also exist)
> scenes_gpu.txt
for d in /home/tabtahi/SATLOCK/dataset/SAR_RPC_ellip_dem/*/*_dem_ellip.tif; do
  s=$(basename "$d" _dem_ellip.tif)
  sa="/home/tabtahi/SATLOCK/dataset/SAR_RPC_ellip/${s}/${s}_rpc_ellip.tif"
  w=$(ls /home/kashley/satlock/mosaic_datasets/eo_sar_umbra_subset_HH_unique_v2/wv_dailytake_output/${s}/mosaic/*.tif 2>/dev/null | head -1)
  if [ -f "$sa" ] && [ -n "$w" ]; then echo "$s" >> scenes_gpu.txt
  else echo "[incomplete] $s" >> logs/incomplete_gpu.txt; fi
done
total=$(wc -l < scenes_gpu.txt)
echo "$(date)  ${total} scenes x 2 matchers across ${NGPU} workers"

worker() {
  gpu=$1
  i=0
  while read scene; do
    i=$((i+1))
    # shard: this worker takes scenes where (i-1) % NGPU == gpu
    if [ $(( (i-1) % NGPU )) -ne "$gpu" ]; then continue; fi
    dem="/home/tabtahi/SATLOCK/dataset/SAR_RPC_ellip_dem/${scene}/${scene}_dem_ellip.tif"
    sar="/home/tabtahi/SATLOCK/dataset/SAR_RPC_ellip/${scene}/${scene}_rpc_ellip.tif"
    wv=$(ls /home/kashley/satlock/mosaic_datasets/eo_sar_umbra_subset_HH_unique_v2/wv_dailytake_output/${scene}/mosaic/*.tif | head -1)
    for matcher in roma xoftr; do
      out="out_height/${matcher}/${scene}"
      if [ -f "${out}/report.json" ]; then
        echo "[gpu${gpu} skip] ${matcher} ${scene}"; continue
      fi
      for attempt in 1 2 3; do
        echo "[gpu${gpu} run ${i}/${total}] $(date +%H:%M) ${matcher} ${scene} (try ${attempt})"
        docker run --rm --gpus "\"device=${gpu}\"" \
          -v /home/tabtahi/SATLOCK/dataset:/home/tabtahi/SATLOCK/dataset \
          -v /home/kashley/satlock/mosaic_datasets:/home/kashley/satlock/mosaic_datasets \
          -v /home/tabtahi/SATLOCK/gec_block_register/out_height:/work/out_height \
          height-register \
          --sar "$sar" --dem "$dem" --wv "$wv" \
          --matcher "${matcher}" --device cuda \
          --out "/work/out_height/${matcher}/${scene}" \
          >> "logs/${matcher}_${scene}.log" 2>&1
        if [ -f "${out}/report.json" ]; then break; fi
        echo "[gpu${gpu} retry] ${matcher} ${scene} failed; 60s"
        sleep 60
      done
    done
  done < scenes_gpu.txt
  echo "[gpu${gpu}] $(date) worker done"
}

pids=""
for g in $(seq 0 $((NGPU-1))); do
  worker "$g" > "logs/gpu_worker_${g}.log" 2>&1 &
  pids="$pids $!"
  echo "worker gpu${g} pid $!"
done
wait $pids
echo "$(date)  multi-GPU batch complete"
