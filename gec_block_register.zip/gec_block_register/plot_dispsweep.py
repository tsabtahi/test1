#!/usr/bin/env python3
"""Plot the match-displacement threshold sweep (CE90 / median / RMSE vs tolerance).

Standalone: numbers hardcoded below, no repo imports. Just needs matplotlib+numpy.
    python plot_dispsweep.py            # writes dispsweep_plot.png (+ .pdf)

The story the plots tell:
  * median (top) is flat and LOW everywhere (~5-6 m) for both matchers — the
    typical tie point is refined well below the RPC baseline.
  * CE90 (middle) and RMSE (bottom) swing wildly with threshold — a few outlier
    points dominate them. XoFTR stays near/under RPC; RoMa's tail blows up.
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ---- hardcoded results ---------------------------------------------------------
RPC = {"median_m": 9.53, "rmse_m": 48.08, "ce90_m": 26.05, "n": 3037}

# threshold in metres; "inf" plotted at the right edge
THRESH = ["inf", 5, 10, 15, 20, 25, 50, 60, 70, 80, 90, 100]

ROMA = {  # tol -> (n, median, rmse, ce90)
    "inf": (3037, 5.30, 731.36, 585.11),
    5:     (2919, 9.60, 513.25, 243.50),
    10:    (2936, 5.92, 480.07, 331.48),
    15:    (2943, 5.33, 378.61, 172.73),
    20:    (3016, 5.44, 586.59, 159.45),
    25:    (3037, 5.08, 582.37,  66.95),
    50:    (3037, 5.12, 661.08,  72.44),
    60:    (3037, 5.06, 645.76,  76.73),
    70:    (3037, 5.09, 706.22, 102.08),
    80:    (3037, 5.14, 562.76, 155.20),
    90:    (3037, 5.12, 584.91,  57.32),
    100:   (3037, 4.97, 663.45,  64.40),
}
XOFTR = {
    "inf": (3037, 5.65,  51.05, 30.65),
    5:     (3001, 8.15, 124.76, 30.34),
    10:    (3037, 6.61,  73.51, 30.43),
    15:    (3037, 6.11,  60.24, 29.31),
    20:    (3037, 6.20,  48.24, 34.44),
    25:    (3037, 5.84,  57.01, 26.49),
    50:    (3037, 5.81,  57.30, 26.46),
    60:    (3037, 6.04,  60.56, 31.30),
    70:    (3037, 6.12, 296.49, 36.31),
    80:    (3037, 6.14, 302.55, 33.20),
    90:    (3037, 6.04,  42.96, 27.82),
    100:   (3037, 6.07,  52.36, 29.71),
}

# ---- x positions: numeric for finite tols, "inf" pinned just past the max -------
finite = [t for t in THRESH if t != "inf"]
xmax = max(finite)
XPOS = {t: (t if t != "inf" else xmax * 1.18) for t in THRESH}
xticks = finite + [xmax * 1.18]
xticklabels = [str(t) for t in finite] + ["∞"]

ROMA_C, XOFTR_C, RPC_C = "#c0392b", "#2471a3", "#555555"


def series_finite(D, idx):
    return [XPOS[t] for t in finite], [D[t][idx] for t in finite]


fig, axes = plt.subplots(3, 1, figsize=(9, 10), sharex=True)
metrics = [("median_m", 1, "Median error (m)", False),
           ("ce90_m",   3, "CE90 (m)",          True),
           ("rmse_m",   2, "RMSE (m)",          True)]

for ax, (key, idx, ylabel, logy) in zip(axes, metrics):
    xr, yr = series_finite(ROMA, idx)
    xx, yx = series_finite(XOFTR, idx)
    ax.plot(xr, yr, "o-", color=ROMA_C, label="RoMa", lw=1.8, ms=5)
    ax.plot(xx, yx, "s-", color=XOFTR_C, label="XoFTR", lw=1.8, ms=5)
    # inf = no-filter condition, drawn detached (open markers, no connecting line)
    ax.plot(XPOS["inf"], ROMA["inf"][idx], "o", mfc="none", mec=ROMA_C, ms=7, mew=1.6)
    ax.plot(XPOS["inf"], XOFTR["inf"][idx], "s", mfc="none", mec=XOFTR_C, ms=7, mew=1.6)
    base = RPC[key]
    ax.axhline(base, color=RPC_C, ls="--", lw=1.5,
               label=f"RPC-ellip baseline ({base:.1f} m)")
    ax.axvline((xmax + xmax * 1.18) / 2, color="#ddd", lw=0.8)  # divider before inf
    if logy:
        ax.set_yscale("log")
    ax.set_ylabel(ylabel, fontsize=11)
    ax.grid(True, which="both", alpha=0.25)
    ax.legend(fontsize=9, loc="upper right")
    if key == "ce90_m":
        ax.axhspan(0, base, color="green", alpha=0.05)
        ax.text(finite[1], base * 0.72, "below RPC baseline = win",
                fontsize=8, color="green", style="italic")

axes[-1].set_xlabel("Match-displacement tolerance (m)  —  ∞ = no filter", fontsize=11)
axes[-1].set_xticks(xticks)
axes[-1].set_xticklabels(xticklabels)
axes[0].set_title("Match-displacement threshold sweep  ·  GEC-ellip + learned refinement\n"
                  "median stays low everywhere; CE90/RMSE are outlier-driven",
                  fontsize=12)
fig.tight_layout()
fig.savefig("dispsweep_plot.png", dpi=150, facecolor="white")
fig.savefig("dispsweep_plot.pdf", facecolor="white")
print("wrote dispsweep_plot.png, dispsweep_plot.pdf")
