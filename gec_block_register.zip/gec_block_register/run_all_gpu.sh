#!/bin/bash
# GPU batch: RoMa + XoFTR over ALL triple-complete scenes (DEM+SAR+WV).
# Resumable (report.json = done). GPU-flap tolerant (3 tries per run, 60s apart).
# Outputs: out_height/roma/<scene>/<scene>_reg_R.tif
#          out_height/xoftr/<scene>/<scene>_reg_xf.tif
# plus per-run report.json, transform.json, matches.csv, and the six PNG panels.
set -u
cd /home/tabtahi/SATLOCK/gec_block_register
mkdir -p out_height/roma out_height/xoftr logs

# inventory
> scenes_gpu.txt
for d in /home/tabtahi/SATLOCK/dataset/SAR_RPC_ellip_dem/*/*_dem_ellip.tif; do
  s=$(basename "$d" _dem_ellip.tif)
  sa="/home/tabtahi/SATLOCK/dataset/SAR_RPC_ellip/${s}/${s}_rpc_ellip.tif"
  w=$(ls /home/kashley/satlock/mosaic_datasets/eo_sar_umbra_subset_HH_unique_v2/wv_dailytake_output/${s}/mosaic/*.tif 2>/dev/null | head -1)
  if [ -f "$sa" ] && [ -n "$w" ]; then echo "$s" >> scenes_gpu.txt
  else echo "[incomplete] $s" >> logs/incomplete_gpu.txt; fi
done
total=$(wc -l < scenes_gpu.txt)
echo "$(date)  ${total} scenes x 2 matchers queued"

i=0
while read scene; do
  i=$((i+1))
  dem="/home/tabtahi/SATLOCK/dataset/SAR_RPC_ellip_dem/${scene}/${scene}_dem_ellip.tif"
  sar="/home/tabtahi/SATLOCK/dataset/SAR_RPC_ellip/${scene}/${scene}_rpc_ellip.tif"
  wv=$(ls /home/kashley/satlock/mosaic_datasets/eo_sar_umbra_subset_HH_unique_v2/wv_dailytake_output/${scene}/mosaic/*.tif | head -1)
  for matcher in roma xoftr; do
    out="out_height/${matcher}/${scene}"
    if [ -f "${out}/report.json" ]; then
      echo "[skip ${i}/${total}] ${matcher} ${scene} (done)"; continue
    fi
    for attempt in 1 2 3; do
      echo "===== [run ${i}/${total}] $(date +%H:%M) ${matcher} ${scene} (try ${attempt}) ====="
      docker run --rm --gpus all \
        -v /home/tabtahi/SATLOCK/dataset:/home/tabtahi/SATLOCK/dataset \
        -v /home/kashley/satlock/mosaic_datasets:/home/kashley/satlock/mosaic_datasets \
        -v /home/tabtahi/SATLOCK/gec_block_register/out_height:/work/out_height \
        height-register \
        --sar "$sar" --dem "$dem" --wv "$wv" \
        --matcher "${matcher}" --device cuda \
        --out "/work/out_height/${matcher}/${scene}" \
        2>&1 | tee -a "logs/${matcher}_${scene}.log"
      if [ -f "${out}/report.json" ]; then break; fi
      echo "[retry] ${matcher} ${scene} failed (GPU flap?); waiting 60s"
      sleep 60
    done
  done
done < scenes_gpu.txt
echo "$(date)  GPU batch complete"
