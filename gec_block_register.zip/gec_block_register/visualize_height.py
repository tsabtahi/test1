"""Visualization for height-aware registration.

Five panels, saved as PNGs in the run's out dir. Everything is rendered from the
data already in memory at the end of run_height_aware (no re-reads). Scenes are
large (~9k px); panels downsample to DISPLAY_PX for rendering speed.

The one that matters most scientifically is quiver_height.png: displacement
vectors split by the chosen height cutoff. If the elevated (excluded) vectors are
visibly longer / systematically rotated vs the ground vectors, the ladder's
premise is confirmed on that scene; if they look identical, the scene didn't need
height filtering (flat or low-relief) — both are useful to know per scene.
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LightSource
from matplotlib.patches import Rectangle

DISPLAY_PX = 1500


def _downsample(arr, max_px=DISPLAY_PX):
    """Stride-downsample to ~max_px on the long side. Returns (arr, scale)."""
    H, W = arr.shape[:2]
    step = max(1, int(np.ceil(max(H, W) / max_px)))
    return arr[::step, ::step], 1.0 / step


def _stretch(a, lo=2, hi=98):
    a = a.astype(np.float32)
    v = a[np.isfinite(a) & (a > 0)]
    if v.size == 0:
        return np.zeros_like(a)
    p0, p1 = np.percentile(v, (lo, hi))
    if p1 - p0 < 1e-8:
        p1 = p0 + 1
    return np.clip((a - p0) / (p1 - p0), 0, 1)


def _dem_render(dem, valid, cutoff=None, ax=None, title="DEM (ellipsoidal height)"):
    """Hillshade + terrain colormap; optional cutoff contour."""
    d = np.where(valid, dem, np.nan)
    finite = d[np.isfinite(d)]
    ls = LightSource(azdeg=315, altdeg=45)
    norm = _stretch(np.nan_to_num(d, nan=np.nanmin(d) if finite.size else 0), 1, 99)
    rgb = ls.shade(norm, cmap=plt.cm.terrain, blend_mode="soft",
                   vert_exag=2.0, dx=1, dy=1)
    ax.imshow(rgb, interpolation="nearest")
    if cutoff is not None and finite.size and np.nanmin(d) < cutoff < np.nanmax(d):
        ax.contour(d, levels=[cutoff], colors="crimson", linewidths=1.2)
        ax.plot([], [], color="crimson", lw=1.2, label=f"cutoff {cutoff:.0f} m")
        ax.legend(loc="lower right", fontsize=7)
    ax.set_title(title, fontsize=9)
    ax.set_xticks([]); ax.set_yticks([])


def overview(sar_rgb, wv_rgb, dem, dem_valid, cutoff, out_path):
    """SAR | WV | DEM(hillshade + cutoff contour) on the common grid."""
    s, sc = _downsample(sar_rgb)
    w, _ = _downsample(wv_rgb)
    d, _ = _downsample(dem)
    dv, _ = _downsample(dem_valid.astype(np.uint8))
    fig, ax = plt.subplots(1, 3, figsize=(16, 5.6))
    ax[0].imshow(s, interpolation="nearest"); ax[0].set_title("SAR (rpc_ellip, preprocessed)", fontsize=9)
    ax[1].imshow(w, interpolation="nearest"); ax[1].set_title("WV (reference)", fontsize=9)
    for a in ax[:2]:
        a.set_xticks([]); a.set_yticks([])
    _dem_render(d, dv.astype(bool), cutoff, ax=ax[2])
    fig.tight_layout()
    fig.savefig(out_path, dpi=110, facecolor="white"); plt.close(fig)


def points_height(sar_rgb, raws, dem, dem_valid, cutoffs, percentiles,
                  chosen_cutoff, out_path, max_pts=4000):
    """All raw match points on the SAR, colored by DEM height; cutoff split;
    inset: scene height histogram with the rung ladder."""
    s, sc = _downsample(sar_rgb)
    pts, hs = [], []
    for r in raws:
        if len(r.conf) == 0:
            continue
        origin = np.array([r.blk.c0, r.blk.r0], np.float32)
        pts.append(r.src + origin)
        hs.append(r.heights)
    fig, ax = plt.subplots(figsize=(10, 8))
    ax.imshow(s, interpolation="nearest")
    if pts:
        P = np.vstack(pts) * sc
        H = np.concatenate(hs)
        if len(P) > max_pts:
            idx = np.random.default_rng(0).choice(len(P), max_pts, replace=False)
            P, H = P[idx], H[idx]
        finite = np.isfinite(H)
        kept = finite & (H <= chosen_cutoff)
        exc = finite & (H > chosen_cutoff)
        ax.scatter(P[kept, 0], P[kept, 1], s=3, c=H[kept], cmap="viridis",
                   vmin=np.nanpercentile(H[finite], 1) if finite.any() else 0,
                   vmax=np.nanpercentile(H[finite], 99) if finite.any() else 1,
                   label=f"used (≤{chosen_cutoff:.0f} m): {int(kept.sum())}")
        ax.scatter(P[exc, 0], P[exc, 1], s=5, facecolors="none",
                   edgecolors="crimson", linewidths=0.5,
                   label=f"excluded (> cutoff): {int(exc.sum())}")
        sm = plt.cm.ScalarMappable(cmap="viridis")
        sm.set_array(H[finite] if finite.any() else [0, 1])
        fig.colorbar(sm, ax=ax, fraction=0.03, pad=0.01, label="DEM height (m)")
        ax.legend(loc="lower right", fontsize=8)
    ax.set_title("match points by height (excluded = red rings)", fontsize=10)
    ax.set_xticks([]); ax.set_yticks([])

    # inset: DEM histogram + rung ladder
    axh = fig.add_axes([0.12, 0.12, 0.24, 0.18])
    v = dem[dem_valid]
    if v.size:
        axh.hist(v, bins=60, color="steelblue", alpha=0.8, log=True)
        for p, c in zip(percentiles, cutoffs):
            axh.axvline(c, color="crimson" if c == chosen_cutoff else "gray",
                        lw=1.4 if c == chosen_cutoff else 0.8, ls="--")
            axh.text(c, axh.get_ylim()[1] * 0.9, f"P{p:g}", rotation=90,
                     fontsize=6, ha="right")
    axh.set_title("scene heights + rungs", fontsize=7)
    axh.tick_params(labelsize=6)
    fig.savefig(out_path, dpi=110, facecolor="white", bbox_inches="tight")
    plt.close(fig)


def quiver_height(raws, chosen_cutoff, shape, out_path, max_arrows=600,
                  arrow_scale=None):
    """Displacement vectors (dst-src) at match points, split ground vs elevated.

    THE hypothesis check: if elevated (excluded) arrows are longer/rotated vs the
    ground arrows, height filtering is earning its keep on this scene.
    """
    src, disp, hs = [], [], []
    for r in raws:
        if len(r.conf) == 0:
            continue
        origin = np.array([r.blk.c0, r.blk.r0], np.float32)
        src.append(r.src + origin)
        disp.append(r.dst - r.src)
        hs.append(r.heights)
    fig, ax = plt.subplots(figsize=(10, 8))
    if src:
        S = np.vstack(src); D = np.vstack(disp); H = np.concatenate(hs)
        if len(S) > max_arrows:
            idx = np.random.default_rng(0).choice(len(S), max_arrows, replace=False)
            S, D, H = S[idx], D[idx], H[idx]
        finite = np.isfinite(H)
        g = finite & (H <= chosen_cutoff)
        e = finite & (H > chosen_cutoff)
        mg = np.linalg.norm(D[g], axis=1) if g.any() else np.array([0])
        me = np.linalg.norm(D[e], axis=1) if e.any() else np.array([0])
        q = dict(angles="xy", scale_units="xy",
                 scale=arrow_scale or max(np.median(mg), 1e-3) / 25.0, width=0.002)
        ax.quiver(S[g, 0], S[g, 1], D[g, 0], D[g, 1], color="tab:blue",
                  label=f"ground ≤ cutoff  (median {np.median(mg):.1f} px)", **q)
        if e.any():
            ax.quiver(S[e, 0], S[e, 1], D[e, 0], D[e, 1], color="crimson",
                      label=f"elevated > cutoff (median {np.median(me):.1f} px)", **q)
        ax.legend(loc="lower right", fontsize=8)
    ax.set_xlim(0, shape[1]); ax.set_ylim(shape[0], 0)
    ax.set_aspect("equal")
    ax.set_title("displacement quiver: ground (blue) vs elevated (red)", fontsize=10)
    fig.savefig(out_path, dpi=110, facecolor="white", bbox_inches="tight")
    plt.close(fig)


def blocks_map(blocks, results, shape, out_path):
    """Block grid colored by outcome; the spatial version of the fallback histogram."""
    colors = {"affine": "#2a9d2a", "translation": "#e9c46a", "drop": "#d62828"}
    fig, ax = plt.subplots(figsize=(9, 7.5))
    ax.set_xlim(0, shape[1]); ax.set_ylim(shape[0], 0)
    skipped = {(b.r0, b.c0) for b in blocks if not b.keep}
    for b in blocks:
        if (b.r0, b.c0) in skipped:
            ax.add_patch(Rectangle((b.c0, b.r0), b.w, b.h, facecolor="#bbb",
                                   edgecolor="white", alpha=0.5, lw=0.5))
    for r in results:
        ax.add_patch(Rectangle((r.c0, getattr(r, "r0", 0)),
                               blocks[0].w, blocks[0].h,
                               facecolor=colors.get(r.model, "#999"),
                               edgecolor="white", alpha=0.65, lw=0.5))
        ax.text(r.c0 + 20, r.r0 + 90, r.reason if r.model == "drop" else r.model,
                fontsize=5, color="black")
    for lbl, c in [("affine", "#2a9d2a"), ("translation", "#e9c46a"),
                   ("dropped", "#d62828"), ("region-skipped", "#bbb")]:
        ax.add_patch(Rectangle((0, 0), 0, 0, facecolor=c, label=lbl))
    ax.legend(loc="lower right", fontsize=8)
    ax.set_aspect("equal")
    ax.set_title("block outcomes", fontsize=10)
    ax.set_xticks([]); ax.set_yticks([])
    fig.savefig(out_path, dpi=110, facecolor="white", bbox_inches="tight")
    plt.close(fig)


def triptych(wv_rgb, sar_rgb, warped_rgb, results, chosen_cutoff, out_path,
             max_pts=1500):
    """WV (with matched dst points) | SAR (with matched src points) | registered SAR.

    Points shown are the GATED, POOLED correspondences that actually drove the
    warp (post-ladder, post-RANSAC, post-consensus) — green on both sides, so you
    can visually trace source -> destination across the first two panels, then
    judge the outcome in the third.
    """
    src = [r.src for r in results if len(r.src)]
    dst = [r.dst for r in results if len(r.dst)]
    fig, ax = plt.subplots(1, 3, figsize=(18, 6.2))

    w, sc_w = _downsample(wv_rgb)
    s, sc_s = _downsample(sar_rgb)
    wp, _ = _downsample(warped_rgb)

    ax[0].imshow(w, interpolation="nearest")
    ax[1].imshow(s, interpolation="nearest")
    ax[2].imshow(wp, interpolation="nearest")

    if src:
        S = np.vstack(src); D = np.vstack(dst)
        if len(S) > max_pts:
            idx = np.random.default_rng(0).choice(len(S), max_pts, replace=False)
            S, D = S[idx], D[idx]
        ax[0].scatter(D[:, 0] * sc_w, D[:, 1] * sc_w, s=4, c="#22dd22",
                      edgecolors="black", linewidths=0.2)
        ax[1].scatter(S[:, 0] * sc_s, S[:, 1] * sc_s, s=4, c="#22dd22",
                      edgecolors="black", linewidths=0.2)
        n = len(np.vstack(src))
    else:
        n = 0
    ax[0].set_title(f"WV (reference) — {n} matched points", fontsize=10)
    ax[1].set_title(f"SAR (rpc_ellip) — points ≤ {chosen_cutoff:.0f} m that drove the warp",
                    fontsize=10)
    ax[2].set_title("registered SAR (output)", fontsize=10)
    for a in ax:
        a.set_xticks([]); a.set_yticks([])
    fig.tight_layout()
    fig.savefig(out_path, dpi=110, facecolor="white"); plt.close(fig)


def before_after(sar_pre_rgb, warped_rgb, wv_rgb, out_path, tiles=8):
    """SAR<->WV checkerboard before vs after the fitted warp."""
    def checker(a, b):
        h, w = a.shape[:2]
        th, tw = h // tiles, w // tiles
        out = b.copy()
        for r in range(tiles):
            for c in range(tiles):
                if (r + c) % 2 == 0:
                    out[r*th:(r+1)*th, c*tw:(c+1)*tw] = a[r*th:(r+1)*th, c*tw:(c+1)*tw]
        return out
    s, _ = _downsample(sar_pre_rgb)
    wp, _ = _downsample(warped_rgb)
    w, _ = _downsample(wv_rgb)
    hh = min(s.shape[0], wp.shape[0], w.shape[0])
    ww = min(s.shape[1], wp.shape[1], w.shape[1])
    s, wp, w = s[:hh, :ww], wp[:hh, :ww], w[:hh, :ww]
    fig, ax = plt.subplots(1, 2, figsize=(15, 6.5))
    ax[0].imshow(checker(s, w), interpolation="nearest")
    ax[0].set_title("BEFORE: SAR / WV checkerboard", fontsize=10)
    ax[1].imshow(checker(wp, w), interpolation="nearest")
    ax[1].set_title("AFTER: registered SAR / WV checkerboard", fontsize=10)
    for a in ax:
        a.set_xticks([]); a.set_yticks([])
    fig.tight_layout()
    fig.savefig(out_path, dpi=110, facecolor="white"); plt.close(fig)
