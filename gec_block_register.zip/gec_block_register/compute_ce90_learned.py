#!/usr/bin/env python3
"""CE90 for the learned-refinement candidates, all experiments in one table.

Extends the existing GEC / RPC-ellip CE90 with learned candidates. For every
scene in residuals.csv it finds each learned run's transform.json + matches.csv
under out_height/<experiment>/<scene>/, pushes the tie point's (lon_rpc, lat_rpc)
through the learned correction (local-flow IDW by default), and scores against
the SAME hand-picked WV truth (lon_eo, lat_eo) — matched-pair property preserved.

Experiments are discovered from the out_height tree: e.g. roma, xoftr,
roma_all, xoftr_all, roma_nostruct, xoftr_nostruct.

    python compute_ce90_learned.py --residuals /home/tabtahi/SATLOCK/ce90_out/residuals.csv \
        --out-root /home/tabtahi/SATLOCK/gec_block_register/out_height \
        --out /home/tabtahi/SATLOCK/ce90_out/learned

Outputs: per_point.csv (every tie point x candidate residual), per_scene.csv,
summary.txt (the pooled table). Scenes/points without a valid learned run are
SKIPPED for that candidate (not zero-filled); untrusted runs (report exhausted /
below min points) are excluded by default and counted in the skip roster.
"""
import argparse
import csv
import glob
import json
import math
import os
import collections

import numpy as np

# reuse the transfer math from apply_tiepoints
import apply_tiepoints as apt


def haversine_m(lon1, lat1, lon2, lat2):
    R = 6371008.8
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = p2 - p1
    dl = math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * R * math.asin(math.sqrt(a))


def ce90(vals):
    v = np.asarray([x for x in vals if np.isfinite(x)], float)
    return float(np.percentile(v, 90)) if v.size else float("nan")


def stats(vals):
    v = np.asarray([x for x in vals if np.isfinite(x)], float)
    if v.size == 0:
        return dict(n=0, median=float("nan"), rmse=float("nan"), ce90=float("nan"))
    return dict(n=int(v.size), median=float(np.median(v)),
                rmse=float(np.sqrt(np.mean(v ** 2))), ce90=float(np.percentile(v, 90)))


def discover_experiments(out_root):
    """Experiment dirs = immediate children of out_root that contain scene dirs
    with transform.json. Skip cpu smoke trees unless asked."""
    exps = []
    for d in sorted(glob.glob(os.path.join(out_root, "*"))):
        if not os.path.isdir(d):
            continue
        name = os.path.basename(d)
        if glob.glob(os.path.join(d, "*", "transform.json")):
            exps.append(name)
    return exps


def run_trusted(run_dir, min_points):
    """Trust filter from the run's own report."""
    rp = os.path.join(run_dir, "report.json")
    if not os.path.exists(rp):
        return False, "no_report"
    with open(rp) as f:
        rep = json.load(f)
    lad = rep.get("ladder", {})
    if lad.get("exhausted"):
        return False, "exhausted"
    ru = lad.get("rung_used", {})
    if ru.get("n_points", 0) < min_points:
        return False, "few_points"
    return True, "ok"


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--residuals", required=True,
                    help="residuals.csv from compute_ce90.py (needs scene, lon_eo, lat_eo, lon_rpc, lat_rpc, r_gec_m, r_rpc_m)")
    ap.add_argument("--out-root", required=True, help="out_height root")
    ap.add_argument("--experiments", nargs="*", help="subset of experiment dirs (default: discover all)")
    ap.add_argument("--mode", default="local", choices=["local", "affine"])
    ap.add_argument("--k", type=int, default=8)
    ap.add_argument("--max-px", type=float, default=2000.0)
    ap.add_argument("--min-points", type=int, default=50, help="trust floor from report.json")
    ap.add_argument("--include-untrusted", action="store_true")
    ap.add_argument("--scene-col", default="scene")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)

    # load residuals, group by scene
    rows = list(csv.DictReader(open(args.residuals)))
    by_scene = collections.defaultdict(list)
    for r in rows:
        by_scene[r[args.scene_col]].append(r)
    print(f"[in] {len(rows)} tie points over {len(by_scene)} scenes")

    exps = args.experiments or discover_experiments(args.out_root)
    exps = [e for e in exps if not e.endswith("_cpu")]  # skip coarse smoke trees
    print(f"[exp] {exps}")

    # per point residuals: baseline columns carried through, one column per experiment
    per_point = []
    skips = collections.Counter()
    for scene, pts in by_scene.items():
        lons = [float(p["lon_rpc"]) for p in pts]
        lats = [float(p["lat_rpc"]) for p in pts]
        refined = {}
        for e in exps:
            run_dir = os.path.join(args.out_root, e, scene)
            if not os.path.exists(os.path.join(run_dir, "transform.json")):
                skips[(e, "no_run")] += 1
                continue
            ok, why = run_trusted(run_dir, args.min_points)
            if not ok and not args.include_untrusted:
                skips[(e, why)] += 1
                continue
            try:
                tf, matches = apt.load_run(run_dir)
                if args.mode == "affine":
                    lon2, lat2, diag = apt.refine_affine(lons, lats, tf)
                else:
                    lon2, lat2, diag = apt.refine_local(lons, lats, tf, matches,
                                                        k=args.k, max_px=args.max_px)
                refined[e] = (lon2, lat2, diag)
            except Exception as ex:
                skips[(e, f"error:{type(ex).__name__}")] += 1
        for i, p in enumerate(pts):
            out = dict(p)
            for e in exps:
                col = f"r_{e}_m"
                if e in refined:
                    lon2, lat2, diag = refined[e]
                    unsupported = diag is not None and diag[i][0] == 0
                    if unsupported:
                        out[col] = ""
                    else:
                        out[col] = f"{haversine_m(lon2[i], lat2[i], float(p['lon_eo']), float(p['lat_eo'])):.3f}"
                else:
                    out[col] = ""
            per_point.append(out)

    # write per_point
    fields = list(rows[0].keys()) + [f"r_{e}_m" for e in exps]
    with open(os.path.join(args.out, "per_point.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(per_point)

    # candidate columns: baselines + experiments
    cands = ["r_gec_m", "r_rpc_m"] + [f"r_{e}_m" for e in exps]

    def col_vals(rs, c):
        return [float(r[c]) for r in rs if r.get(c) not in (None, "", "nan")]

    # per scene
    with open(os.path.join(args.out, "per_scene.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["scene", "n_tiepoints"] + [f"{c}_{s}" for c in cands for s in ("n", "median", "ce90")])
        for scene, pts in by_scene.items():
            rs = [r for r in per_point if r[args.scene_col] == scene]
            row = [scene, len(rs)]
            for c in cands:
                st = stats(col_vals(rs, c))
                row += [st["n"], f"{st['median']:.2f}", f"{st['ce90']:.2f}"]
            w.writerow(row)

    # pooled summary — MATCHED-PAIR: only points where the candidate exists
    lines = ["CE90 — learned refinement candidates (pooled over all tie points)", ""]
    lines.append(f"{'candidate':<24}{'n_pts':>7}{'median_m':>10}{'rmse_m':>9}{'ce90_m':>9}")
    lines.append("-" * 59)
    for c in cands:
        st = stats(col_vals(per_point, c))
        lines.append(f"{c:<24}{st['n']:>7}{st['median']:>10.2f}{st['rmse']:>9.2f}{st['ce90']:>9.2f}")
    # paired comparison vs RPC-ellip on the SAME points, per experiment
    lines += ["", "Paired vs RPC-ellip (same tie points only):"]
    for e in exps:
        c = f"r_{e}_m"
        pairs = [(float(r["r_rpc_m"]), float(r[c])) for r in per_point
                 if r.get(c) not in (None, "", "nan") and r.get("r_rpc_m") not in (None, "", "nan")]
        if not pairs:
            lines.append(f"  {e:<20} no paired points")
            continue
        rp = [a for a, _ in pairs]; le = [b for _, b in pairs]
        wins = sum(1 for a, b in pairs if b < a)
        lines.append(f"  {e:<20} n={len(pairs):<5} rpc CE90 {ce90(rp):.2f} -> learned CE90 {ce90(le):.2f}"
                     f"  | median {np.median(rp):.2f} -> {np.median(le):.2f}"
                     f"  | learned better on {100*wins/len(pairs):.0f}% of points")
    lines += ["", "Skips (experiment, reason): count"]
    for (e, why), n in sorted(skips.items()):
        lines.append(f"  {e:<20} {why:<18} {n}")
    txt = "\n".join(lines)
    with open(os.path.join(args.out, "summary.txt"), "w") as f:
        f.write(txt + "\n")
    print("\n" + txt)
    print(f"\n[out] {args.out}/per_point.csv, per_scene.csv, summary.txt")


if __name__ == "__main__":
    main()
