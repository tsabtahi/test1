"""WorldView cloud masking with OmniCloudMask (DPIRD-DMA, MIT).

    Wright et al., "OmniCloudMask", Remote Sensing of Environment, 2025.
    https://github.com/DPIRD-DMA/OmniCloudMask

Returns a full-resolution boolean cloud mask on the pipeline's common grid, so
it drops straight into region_select.select_regions(cloud=...).

Design notes (each verified against the library source, v1.7.1):

* RESOLUTION. OCM is validated at 10-50 m (down to ~5 m); running finer than
  ~10 m "rarely helps". Our grid is 0.5 m, so the WV is read DIRECTLY at
  `ocm_gsd` (default 10 m) with nodata-aware AVERAGE resampling, and the coarse
  mask is block-replicated back. The factor is an integer and the coarse grid
  shares the fine grid's origin, so fine pixel (r, c) maps exactly to coarse
  (r // k, c // k).

* BANDS. OCM expects (Red, Green, NIR). Mosaic band order varies by product
  (visual RGB vs Maxar BGRN...), so the mapping is explicit (`bands`, 1-based,
  0 = no NIR). CHECK YOUR MOSAIC: `gdalinfo <wv.tif> | grep -i band`.

* NO-NIR PLACEHOLDER. The docs say pass zeros for a missing NIR. We pass the
  VALIDITY MASK instead (1 where WV has data, 0 in collars). OCM's per-band
  z-score maps any constant band to exactly 0, so the network input is
  bit-identical to the zero-NIR case — but (a) the array no longer trips the
  library's ">30% zeros" branch, which would otherwise halve the patch size and
  cut spatial context, and (b) OCM's own "all bands == 0 -> nodata" mask still
  flags exactly the collars.

* THRESHOLD. Confidence export gives softmax probabilities for
  {0 clear, 1 thick, 2 thin, 3 shadow}. cloud := P(thick) + P(thin) > threshold
  (shadow optional). This is a probability threshold, not an argmax.
"""
import os

import numpy as np

DEFAULT_WEIGHTS = "/opt/weights/ocm"     # baked at image build time


def coarse_grid(transform, width, height, k):
    """Coarse grid sharing the fine grid's origin, k fine px per coarse px."""
    from rasterio.transform import Affine
    T = transform
    Tc = Affine(T.a * k, T.b * k, T.c, T.d * k, T.e * k, T.f)
    return Tc, int(np.ceil(width / k)), int(np.ceil(height / k))


def cloud_mask_ocm(wv_path, transform, width, height, grid_gsd_m=0.5,
                   ocm_gsd_m=10.0, bands=(1, 2, 0), threshold=0.5,
                   include_shadow=False, device="cuda", weights_dir=None,
                   return_prob=False):
    """Full-res bool cloud mask (height, width) for the WV on the common grid."""
    try:
        from omnicloudmask import predict_from_array
    except ImportError as e:
        raise SystemExit(
            "omnicloudmask is not installed in this image. Rebuild with the "
            "updated Dockerfile.register, or run with --cloud-method heuristic "
            f"(or --no-cloud-filter). [{e}]")
    import io_geo

    k = max(1, int(round(ocm_gsd_m / grid_gsd_m)))
    Tc, wc, hc = coarse_grid(transform, width, height, k)

    r_b, g_b, n_b = bands
    read = [b for b in (r_b, g_b, n_b) if b]
    arr = io_geo.read_bands_on_grid(wv_path, read, Tc, wc, hc,
                                    resampling="average", src_nodata=0)
    by_band = dict(zip(read, arr))
    red, green = by_band[r_b], by_band[g_b]
    valid = (red > 0) | (green > 0)
    nir = by_band[n_b] if n_b else valid.astype(np.float32)   # see module docstring
    x = np.stack([red, green, nir]).astype(np.float32)

    if min(hc, wc) < 32:        # OCM hard minimum patch size
        raise ValueError(f"coarse WV grid {hc}x{wc} < 32 px; lower --ocm-gsd")

    wdir = weights_dir or (DEFAULT_WEIGHTS if os.path.isdir(DEFAULT_WEIGHTS) else None)
    kw = dict(export_confidence=True, softmax_output=True,
              inference_device=device, no_data_value=0, apply_no_data_mask=True)
    if wdir:
        kw["destination_model_dir"] = wdir
    conf = predict_from_array(x, **kw)                          # (4, hc, wc)

    p_cloud = conf[1] + conf[2] + (conf[3] if include_shadow else 0.0)
    coarse = (p_cloud > threshold) & valid

    full = np.repeat(np.repeat(coarse, k, axis=0), k, axis=1)[:height, :width]
    if return_prob:
        return full, p_cloud, k
    return full
