"""Preprocessing for matching (same family as the metrics harness / Stage-2).

DINOv2 / LoFTR backbones never saw speckle, so GEC SAR is reduced toward a
structural map before matching: log1p -> Lee despeckle -> optional Sobel ->
percentile stretch. EO (WV) reference is kept optical unless edge mode is on, in
which case both sides go to gradient maps so they share a representation.
"""
import numpy as np
from scipy.ndimage import uniform_filter

from config import PreprocConfig


def lee_filter(img, size=5):
    img = img.astype(np.float32)
    mean = uniform_filter(img, size)
    sqr = uniform_filter(img ** 2, size)
    var = sqr - mean ** 2
    overall = np.var(img)
    w = var / (var + overall + 1e-8)
    return mean + w * (img - mean)


def percentile_stretch(a, pmin=2.0, pmax=98.0):
    lo, hi = np.percentile(a, pmin), np.percentile(a, pmax)
    if hi - lo < 1e-8:
        hi = lo + 1.0
    return (np.clip((a - lo) / (hi - lo), 0, 1) * 255).astype(np.uint8)


def sobel_mag(a):
    import cv2
    gx = cv2.Sobel(a.astype(np.float32), cv2.CV_32F, 1, 0, ksize=3)
    gy = cv2.Sobel(a.astype(np.float32), cv2.CV_32F, 0, 1, ksize=3)
    return np.sqrt(gx ** 2 + gy ** 2)


def preprocess_sar(sar, cfg: PreprocConfig = None):
    """Single-band GEC SAR -> HxWx3 uint8."""
    cfg = cfg or PreprocConfig()
    a = np.clip(sar.astype(np.float32), 0, None)
    if cfg.log_transform:
        a = np.log1p(a)
    if cfg.despeckle:
        a = lee_filter(a, cfg.lee_size)
    if cfg.edges:
        a = sobel_mag(a)
    u8 = percentile_stretch(a, cfg.pmin, cfg.pmax)
    return np.stack([u8] * 3, -1)


def preprocess_reference(ref, is_sar, cfg: PreprocConfig = None):
    """Reference can be SAR gold (single band) or EO/WV (3 band)."""
    cfg = cfg or PreprocConfig()
    import cv2
    if is_sar:
        return preprocess_sar(ref if ref.ndim == 2 else ref[..., 0], cfg)
    # EO
    rgb = ref if ref.ndim == 3 else np.stack([ref] * 3, -1)
    if cfg.edges:
        g = cv2.cvtColor(rgb.astype(np.uint8), cv2.COLOR_RGB2GRAY).astype(np.float32)
        u8 = percentile_stretch(sobel_mag(g), cfg.pmin, cfg.pmax)
        return np.stack([u8] * 3, -1)
    out = np.zeros(rgb.shape[:2] + (3,), np.uint8)
    for c in range(3):
        out[..., c] = percentile_stretch(rgb[..., c].astype(np.float32), cfg.pmin, cfg.pmax)
    return out
