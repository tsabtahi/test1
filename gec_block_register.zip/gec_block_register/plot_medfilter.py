#!/usr/bin/env python3
"""Plot the MEDIAN-RELATIVE match filter sweep (CE90 / median / RMSE vs tolerance).

Standalone: numbers hardcoded, no repo imports. matplotlib + numpy only.
    python plot_medfilter.py        # writes medfilter_plot.png (+ .pdf)

Same layout as plot_dispsweep.py. This is the filter that WON: tolerance here is
metres of allowed deviation from the scene's MEDIAN (consensus) displacement, not
absolute movement — so it trims scatter without discarding the real bulk shift.
XoFTR @5-10 m drops CE90 below the RPC baseline; RoMa's median is great but its
RMSE tail stays huge (a few coherent-but-wrong regions the filter can't catch).
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ---- hardcoded results ---------------------------------------------------------
RPC = {"median_m": 9.53, "rmse_m": 48.08, "ce90_m": 26.05, "n": 3037}

THRESH = ["inf", 5, 10, 15, 25]     # metres deviation from scene-median displacement

# tol -> (n_pts, cover_scenes, median, rmse, ce90)
XOFTR = {
    "inf": (3037, 66, 5.65, 51.05, 30.65),
    5:     (2709, 57, 4.94, 83.61, 18.47),
    10:    (3033, 65, 5.65, 47.43, 20.78),
    15:    (3033, 65, 5.86, 47.34, 24.06),
    25:    (3037, 66, 5.94, 50.21, 30.15),
}
ROMA = {
    "inf": (3037, 66, 5.30, 731.36, 585.11),
    5:     (2864, 58, 4.76, 336.39,  23.90),
    10:    (3034, 65, 4.95, 572.10,  44.18),
    15:    (3037, 66, 5.09, 634.66,  44.33),
    25:    (3037, 66, 4.94, 571.91,  48.15),
}
COVER_TOT = 66

# index into the value tuples
I_MED, I_RMSE, I_CE90 = 2, 3, 4

# ---- x positions: finite tols numeric, "inf" pinned just past the max ----------
finite = [t for t in THRESH if t != "inf"]
xmax = max(finite)
XPOS = {t: (t if t != "inf" else xmax * 1.25) for t in THRESH}
xticks = finite + [xmax * 1.25]
xticklabels = [str(t) for t in finite] + ["∞"]

ROMA_C, XOFTR_C, RPC_C = "#c0392b", "#2471a3", "#555555"


def series_finite(D, idx):
    return [XPOS[t] for t in finite], [D[t][idx] for t in finite]


fig, axes = plt.subplots(3, 1, figsize=(8.5, 10), sharex=True)
metrics = [("median_m", I_MED,  "Median error (m)", False),
           ("ce90_m",   I_CE90, "CE90 (m)",          True),
           ("rmse_m",   I_RMSE, "RMSE (m)",          True)]

for ax, (key, idx, ylabel, logy) in zip(axes, metrics):
    xr, yr = series_finite(ROMA, idx)
    xx, yx = series_finite(XOFTR, idx)
    ax.plot(xr, yr, "o-", color=ROMA_C, label="RoMa", lw=1.8, ms=6)
    ax.plot(xx, yx, "s-", color=XOFTR_C, label="XoFTR", lw=1.8, ms=6)
    # inf = no-filter, detached open markers
    ax.plot(XPOS["inf"], ROMA["inf"][idx], "o", mfc="none", mec=ROMA_C, ms=8, mew=1.7)
    ax.plot(XPOS["inf"], XOFTR["inf"][idx], "s", mfc="none", mec=XOFTR_C, ms=8, mew=1.7)
    base = RPC[key]
    ax.axhline(base, color=RPC_C, ls="--", lw=1.5,
               label=f"RPC-ellip baseline ({base:.1f} m)")
    ax.axvline((xmax + xmax * 1.25) / 2, color="#ddd", lw=0.8)
    if logy:
        ax.set_yscale("log")
    ax.set_ylabel(ylabel, fontsize=11)
    ax.grid(True, which="both", alpha=0.25)
    ax.legend(fontsize=9, loc="best")
    if key == "ce90_m":
        ax.axhspan(0, base, color="green", alpha=0.06)
        ax.text(12, base * 0.5, "below RPC baseline = win",
                fontsize=8, color="green", style="italic", ha="center")

axes[-1].set_xlabel("Deviation from scene-median displacement (m)  —  ∞ = no filter",
                    fontsize=11)
axes[-1].set_xticks(xticks)
axes[-1].set_xticklabels(xticklabels)
axes[0].set_title("Median-relative match filter  ·  GEC-ellip + learned refinement\n"
                  "XoFTR drops CE90 below the RPC baseline; RoMa keeps a heavy RMSE tail",
                  fontsize=12)

# annotate coverage under each XoFTR point on the CE90 panel (the honest caveat)
axce = axes[1]
for t in finite:
    n, cov, med, rmse, ce90 = XOFTR[t]
    axce.annotate(f"{cov}/{COVER_TOT}", (XPOS[t], ce90), fontsize=7, color=XOFTR_C,
                  xytext=(0, 8), textcoords="offset points", ha="center")

fig.tight_layout()
fig.savefig("medfilter_plot.png", dpi=150, facecolor="white")
fig.savefig("medfilter_plot.pdf", facecolor="white")
print("wrote medfilter_plot.png, medfilter_plot.pdf")
