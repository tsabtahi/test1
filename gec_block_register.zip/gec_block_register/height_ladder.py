"""Height-aware correspondence filtering (DEM ladder).

Physics: the RPC-ellipsoid ortho is most accurate for pixels at/near the terrain
reference; elevated terrain carries residual layover/parallax displacement. So we
harvest correspondences from NEAR-GROUND pixels first, and only admit higher
terrain if the scene doesn't yield enough points.

Key architecture point: RoMa matching is the expensive GPU step and it is dense —
so we MATCH ONCE per block, attach a DEM height to every raw correspondence, and
run the altitude ladder as pure CPU post-filtering. Climbing a rung never re-runs
the matcher. The height filter is applied BEFORE per-block RANSAC/gates so that
systematically-displaced high-altitude points cannot skew the block affines.

Rungs are per-scene DEM percentiles (scale-free: works for flat Iowa and for
mountains alike). The ladder stops at the first rung whose pooled, gated
correspondence count reaches `min_points`.
"""
from dataclasses import dataclass, field

import numpy as np


@dataclass
class LadderConfig:
    percentiles: tuple = (30.0, 50.0, 70.0, 85.0, 100.0)  # rungs, low -> all
    min_points: int = 200          # pooled clean correspondences needed to stop
    min_blocks: int = 4            # and at least this many contributing blocks
    dem_nodata_below: float = -1000.0  # DEM values below this are nodata


@dataclass
class LadderResult:
    rung_index: int                # which rung satisfied the target (or last)
    percentile: float
    height_cutoff_m: float         # absolute ellipsoidal height at that rung
    n_points: int
    n_blocks: int
    per_rung: list = field(default_factory=list)  # [(pct, cutoff, n_pts, n_blk)]
    exhausted: bool = False        # True if even the top rung fell short


def dem_valid_mask(dem, cfg: LadderConfig):
    return np.isfinite(dem) & (dem > cfg.dem_nodata_below)


def rung_cutoffs(dem, cfg: LadderConfig):
    """Absolute height cutoff per rung from the scene's valid-DEM distribution."""
    v = dem[dem_valid_mask(dem, cfg)]
    if v.size == 0:
        # degenerate DEM -> single all-pass rung
        return [np.inf for _ in cfg.percentiles]
    return [float(np.percentile(v, p)) for p in cfg.percentiles]


def sample_heights(dem, pts_xy):
    """DEM height at each correspondence's GEC/ortho pixel (nearest neighbor).

    pts_xy are (x, y) in the common-grid frame the DEM is warped onto. Points
    falling outside the DEM get +inf so they only pass the final (all) rung.
    """
    H, W = dem.shape
    x = np.round(pts_xy[:, 0]).astype(int)
    y = np.round(pts_xy[:, 1]).astype(int)
    inside = (x >= 0) & (x < W) & (y >= 0) & (y < H)
    h = np.full(len(pts_xy), np.inf, np.float64)
    h[inside] = dem[y[inside], x[inside]]
    h[~np.isfinite(h)] = np.inf
    return h


def filter_matches_by_height(kpts_src, kpts_dst, conf, heights, cutoff):
    """Keep correspondences whose sampled DEM height <= cutoff."""
    keep = heights <= cutoff
    return kpts_src[keep], kpts_dst[keep], conf[keep], keep


# --- point-selection modes (ablation experiments) --------------------------------
#  ladder   : the height ladder (default) — near-ground first, admit higher rungs
#  all      : NO height selection; every gated correspondence admitted
#  nostruct : everything EXCEPT tall man-made structure. The DEM is bare-earth
#             terrain, so buildings mostly aren't in it; the DEM-only proxy is
#             LOCAL ROUGHNESS — the height range within a small window. Buildings /
#             towers / bridge decks give sharp local relief that natural terrain
#             does not. Points where local range > struct_thresh_m are excluded.

def structure_mask(dem, valid, window=5, thresh_m=8.0):
    """True where the DEM shows sharp local relief (proxy for man-made structure).

    Uses a max-min range in a (window x window) neighborhood. Only reliable if the
    DEM has real building relief (DSM-like or high-res 3DEP); on smooth bare-earth
    DEMs the mask will be mostly empty, which is a correct 'no structure detected'.
    """
    from scipy.ndimage import maximum_filter, minimum_filter, binary_dilation, binary_fill_holes
    d = np.where(valid, dem, np.nan)
    finite = np.isfinite(d)
    fill = np.nanmedian(d) if finite.any() else 0.0
    d0 = np.where(finite, d, fill)
    rng = maximum_filter(d0, size=window) - minimum_filter(d0, size=window)
    edges = (rng > thresh_m) & finite
    # Roughness only fires at structure EDGES; a flat rooftop interior has zero
    # local range. Dilate then fill holes so the whole footprint is excluded,
    # not just its outline. Dilation radius ~ window so adjacent buildings merge.
    filled = binary_fill_holes(binary_dilation(edges, iterations=max(1, window // 2)))
    return filled & finite


def sample_mask(mask, pts_xy):
    """Boolean mask value at each point (nearest neighbor); outside -> False."""
    H, W = mask.shape
    x = np.round(pts_xy[:, 0]).astype(int)
    y = np.round(pts_xy[:, 1]).astype(int)
    inside = (x >= 0) & (x < W) & (y >= 0) & (y < H)
    out = np.zeros(len(pts_xy), bool)
    out[inside] = mask[y[inside], x[inside]]
    return out
