#!/usr/bin/env python3
"""Displacement-threshold ablation on SAVED matches (CPU only, no re-matching).

For each learned run we already have matches.csv (every correspondence, pixel +
lon/lat) and the grid transform. This sweep, per threshold T (meters):

  1. drop correspondences whose match displacement |dst-src| > T  (match-displacement
     filter, option (a) — the physical sanity gate)
  2. refit ONE global affine (SAR-grid px -> WV-grid px) from what remains, RANSAC
  3. push every tie point (lon_rpc,lat_rpc) through that affine -> refined position
  4. CE90 vs the hand-picked WV truth (lon_eo,lat_eo)

Produces a CE90-vs-threshold table per matcher (roma, xoftr) plus the no-filter
baseline (T=inf) and the raw RPC-ellip baseline. No GPU, no imagery, seconds.

    python compute_ce90_dispsweep.py \
        --residuals /home/tabtahi/SATLOCK/ce90_out/residuals.csv \
        --out-root  /home/tabtahi/SATLOCK/gec_block_register/out_height \
        --experiments roma_all xoftr_all \
        --thresholds 5 10 15 --out /home/tabtahi/SATLOCK/ce90_out/dispsweep
"""
import argparse
import collections
import csv
import glob
import json
import math
import os

import numpy as np
import cv2


def haversine_m(lon1, lat1, lon2, lat2):
    R = 6371008.8
    p1, p2 = math.radians(lat1), math.radians(lat2)
    a = (math.sin(math.radians(lat2 - lat1) / 2) ** 2
         + math.cos(p1) * math.cos(p2) * math.sin(math.radians(lon2 - lon1) / 2) ** 2)
    return 2 * R * math.asin(math.sqrt(a))


def stats(vals):
    v = np.asarray([x for x in vals if np.isfinite(x)], float)
    if v.size == 0:
        return dict(n=0, median=float("nan"), rmse=float("nan"), ce90=float("nan"))
    return dict(n=int(v.size), median=float(np.median(v)),
                rmse=float(np.sqrt(np.mean(v ** 2))), ce90=float(np.percentile(v, 90)))


def load_run(run_dir):
    with open(os.path.join(run_dir, "transform.json")) as f:
        tf = json.load(f)
    src, dst = [], []
    with open(os.path.join(run_dir, "matches.csv")) as f:
        for r in csv.DictReader(f):
            src.append([float(r["x_sar_px"]), float(r["y_sar_px"])])
            dst.append([float(r["x_wv_px"]), float(r["y_wv_px"])])
    return tf, np.array(src), np.array(dst)


def m_per_px(g):
    lat = g[5]
    mx = abs(g[0]) * 111320.0 * max(math.cos(math.radians(lat)), 1e-3)
    my = abs(g[4]) * 111320.0
    return 0.5 * (mx + my)


def refit_affine(src, dst, max_disp_px, ransac_px=3.0):
    """Filter by displacement, refit SAR->WV affine. Returns 2x3 or None + n_used."""
    if len(src) < 3:
        return None, 0
    disp = np.linalg.norm(dst - src, axis=1)
    keep = disp <= max_disp_px if np.isfinite(max_disp_px) else np.ones(len(src), bool)
    s, d = src[keep], dst[keep]
    if len(s) < 3:
        return None, len(s)
    A, _ = cv2.estimateAffine2D(s.astype(np.float32), d.astype(np.float32),
                                method=cv2.RANSAC, ransacReprojThreshold=ransac_px,
                                maxIters=10000, confidence=0.9999)
    return A, len(s)


def lonlat_to_px(lon, lat, g):
    a, b, c, d, e, f = g
    Minv = np.linalg.inv(np.array([[a, b], [d, e]], float))
    v = np.stack([np.asarray(lon) - c, np.asarray(lat) - f], -1)
    px = v @ Minv.T
    return px[..., 0], px[..., 1]


def px_to_lonlat(col, row, g):
    a, b, c, d, e, f = g
    return a * col + b * row + c, d * col + e * row + f


def refine(lons, lats, A, g):
    c, r = lonlat_to_px(lons, lats, g)
    c2 = A[0, 0] * c + A[0, 1] * r + A[0, 2]
    r2 = A[1, 0] * c + A[1, 1] * r + A[1, 2]
    return px_to_lonlat(c2, r2, g)


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--residuals", required=True)
    ap.add_argument("--out-root", required=True)
    ap.add_argument("--experiments", nargs="+", required=True,
                    help="experiment dir names, e.g. roma_all xoftr_all")
    ap.add_argument("--thresholds", type=float, nargs="+", default=[5, 10, 15])
    ap.add_argument("--scene-col", default="scene")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)

    rows = list(csv.DictReader(open(args.residuals)))
    by_scene = collections.defaultdict(list)
    for r in rows:
        by_scene[r[args.scene_col]].append(r)

    thr_labels = [("inf", float("inf"))] + [(f"{t:g}m", t) for t in args.thresholds]

    # residual accumulators: candidate -> list of per-point residual metres
    pooled = collections.defaultdict(list)
    # also keep the RPC baseline straight from residuals.csv
    pooled["rpc_ellip"] = [float(r["r_rpc_m"]) for r in rows if r.get("r_rpc_m") not in ("", None)]

    per_point_out = []
    coverage = collections.Counter()

    for scene, pts in by_scene.items():
        lons = np.array([float(p["lon_rpc"]) for p in pts])
        lats = np.array([float(p["lat_rpc"]) for p in pts])
        eo = [(float(p["lon_eo"]), float(p["lat_eo"])) for p in pts]

        for exp in args.experiments:
            run_dir = os.path.join(args.out_root, exp, scene)
            if not os.path.exists(os.path.join(run_dir, "matches.csv")):
                continue
            tf, src, dst = load_run(run_dir)
            g = tf["grid_transform"]
            mpp = m_per_px(g)
            coverage[exp] += 1
            for lbl, tm in thr_labels:
                A, n_used = refit_affine(src, dst, tm / mpp if np.isfinite(tm) else np.inf)
                cand = f"{exp}@{lbl}"
                if A is None:
                    continue
                rlon, rlat = refine(lons, lats, A, g)
                for i, p in enumerate(pts):
                    rm = haversine_m(rlon[i], rlat[i], eo[i][0], eo[i][1])
                    pooled[cand].append(rm)

    # summary table
    lines = ["CE90 — match-displacement threshold ablation (refit from saved matches)", ""]
    lines.append(f"{'candidate':<22}{'n_pts':>7}{'median_m':>10}{'rmse_m':>9}{'ce90_m':>9}")
    lines.append("-" * 57)
    lines.append(f"{'rpc_ellip (baseline)':<22}" + _fmt(stats(pooled['rpc_ellip'])))
    for exp in args.experiments:
        lines.append("")
        for lbl, _ in thr_labels:
            cand = f"{exp}@{lbl}"
            lines.append(f"{cand:<22}" + _fmt(stats(pooled[cand])))
    lines += ["", "scenes with matches per experiment: "
              + ", ".join(f"{e}={coverage[e]}" for e in args.experiments)]
    txt = "\n".join(lines)
    with open(os.path.join(args.out, "summary.txt"), "w") as f:
        f.write(txt + "\n")

    # machine-readable
    with open(os.path.join(args.out, "sweep.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["candidate", "n_pts", "median_m", "rmse_m", "ce90_m"])
        w.writerow(["rpc_ellip"] + _row(stats(pooled["rpc_ellip"])))
        for exp in args.experiments:
            for lbl, _ in thr_labels:
                st = stats(pooled[f"{exp}@{lbl}"])
                w.writerow([f"{exp}@{lbl}"] + _row(st))
    print(txt)
    print(f"\n[out] {args.out}/summary.txt, sweep.csv")


def _fmt(st):
    return f"{st['n']:>7}{st['median']:>10.2f}{st['rmse']:>9.2f}{st['ce90']:>9.2f}"


def _row(st):
    return [st["n"], f"{st['median']:.3f}", f"{st['rmse']:.3f}", f"{st['ce90']:.3f}"]


if __name__ == "__main__":
    main()
