"""Crop-window selection for the metrics harness.

Scoring on whole scenes is dominated by no-data borders and flat regions. Instead
we pick fixed-size crop windows that (a) are mostly valid across ALL products and
the reference, and (b) have real texture (post-Lee gradient variance), then score
each product vs the reference on those windows. Same 512px crop convention as the
existing sar_metrics harness.
"""
import numpy as np

from preprocessing import lee_filter
from region_select import sobel_mag


def _window_score(gray, r0, c0, size, lee_size=5):
    patch = gray[r0:r0+size, c0:c0+size].astype(np.float32)
    if patch.size == 0:
        return 0.0
    return float(np.var(sobel_mag(lee_filter(patch, lee_size))))


def choose_crops(ref_gray, valid_stack, n, size=512, stride=None,
                 keep_percentile=60.0, min_valid_frac=0.9, lee_size=5):
    """Return up to n (r0, c0) crop origins.

    ref_gray     : reference intensity (drives the texture score)
    valid_stack  : list of boolean validity masks (ref + every product); a crop is
                   eligible only where ALL are valid (>= min_valid_frac).
    """
    H, W = ref_gray.shape
    stride = stride or size  # non-overlapping by default
    both_valid = np.logical_and.reduce(valid_stack) if valid_stack else np.ones_like(ref_gray, bool)

    cands = []
    for r0 in range(0, max(1, H - size + 1), stride):
        for c0 in range(0, max(1, W - size + 1), stride):
            vfrac = both_valid[r0:r0+size, c0:c0+size].mean()
            if vfrac < min_valid_frac:
                continue
            cands.append((r0, c0, _window_score(ref_gray, r0, c0, size, lee_size)))
    if not cands:
        return []
    scores = np.array([c[2] for c in cands])
    thr = np.percentile(scores, keep_percentile)
    kept = [(r, c) for (r, c, s) in cands if s >= thr]
    # highest-texture first, cap at n
    kept.sort(key=lambda rc: -_window_score(ref_gray, rc[0], rc[1], size, lee_size))
    return kept[:n]
