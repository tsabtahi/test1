#!/usr/bin/env python3
"""Multi-matcher agreement: gate scenes on RoMa<->XoFTR consensus, fuse, score CE90.

Per scene (CPU, saved matches only):
  1. median-relative filter each matcher's matches (tol = --medfilter-tol, the
     winning recipe), refit one affine per matcher
  2. AGREEMENT = mean distance (m) between the two affines' predictions at the
     scene's tie-point locations. Scene eligible iff agreement <= --agree-tol.
  3. eligible scenes: fused prediction = midpoint of the two matchers'
     predictions per tie point; score vs hand-picked WV truth
  4. report CE90 + coverage for: fused, roma-alone, xoftr-alone (same kept
     scenes, so comparisons are paired), and RPC baseline on kept + all scenes.

Sweeps several agree tolerances in one pass.

    python compute_ce90_agree.py \
        --residuals /home/tabtahi/SATLOCK/ce90_out/residuals.csv \
        --out-root  /home/tabtahi/SATLOCK/gec_block_register/out_height \
        --roma-exp roma_all --xoftr-exp xoftr_all \
        --medfilter-tol 10 --agree-tols 5 10 20 \
        --out /home/tabtahi/SATLOCK/ce90_out/agree
"""
import argparse
import collections
import csv
import json
import math
import os

import numpy as np
import cv2


def haversine_m(lon1, lat1, lon2, lat2):
    R = 6371008.8
    p1, p2 = math.radians(lat1), math.radians(lat2)
    a = (math.sin(math.radians(lat2 - lat1) / 2) ** 2
         + math.cos(p1) * math.cos(p2) * math.sin(math.radians(lon2 - lon1) / 2) ** 2)
    return 2 * R * math.asin(math.sqrt(a))


def stats(vals):
    v = np.asarray([x for x in vals if np.isfinite(x)], float)
    if v.size == 0:
        return dict(n=0, median=float("nan"), rmse=float("nan"), ce90=float("nan"))
    return dict(n=int(v.size), median=float(np.median(v)),
                rmse=float(np.sqrt(np.mean(v ** 2))), ce90=float(np.percentile(v, 90)))


def load_matches(run_dir):
    tf = json.load(open(os.path.join(run_dir, "transform.json")))
    src, dst = [], []
    with open(os.path.join(run_dir, "matches.csv")) as f:
        for r in csv.DictReader(f):
            src.append([float(r["x_sar_px"]), float(r["y_sar_px"])])
            dst.append([float(r["x_wv_px"]), float(r["y_wv_px"])])
    return tf, np.array(src), np.array(dst)


def m_per_px(g):
    lat = g[5]
    return 0.5 * (abs(g[0]) * 111320.0 * max(math.cos(math.radians(lat)), 1e-3)
                  + abs(g[4]) * 111320.0)


def medfilter_fit(src, dst, tol_px, min_kept=20):
    if len(src) < 3:
        return None
    disp = dst - src
    med = np.median(disp, axis=0)
    keep = np.linalg.norm(disp - med, axis=1) <= tol_px
    if keep.sum() < min_kept:
        return None
    A, _ = cv2.estimateAffine2D(src[keep].astype(np.float32), dst[keep].astype(np.float32),
                                method=cv2.RANSAC, ransacReprojThreshold=3.0,
                                maxIters=10000, confidence=0.9999)
    return A


def lonlat_to_px(lon, lat, g):
    Minv = np.linalg.inv(np.array([[g[0], g[1]], [g[3], g[4]]], float))
    v = np.stack([np.asarray(lon) - g[2], np.asarray(lat) - g[5]], -1)
    px = v @ Minv.T
    return px[..., 0], px[..., 1]


def px_to_lonlat(c, r, g):
    return g[0] * c + g[1] * r + g[2], g[3] * c + g[4] * r + g[5]


def apply_A(c, r, A):
    return A[0, 0] * c + A[0, 1] * r + A[0, 2], A[1, 0] * c + A[1, 1] * r + A[1, 2]


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--residuals", required=True)
    ap.add_argument("--out-root", required=True)
    ap.add_argument("--roma-exp", default="roma_all")
    ap.add_argument("--xoftr-exp", default="xoftr_all")
    ap.add_argument("--medfilter-tol", type=float, default=10.0)
    ap.add_argument("--agree-tols", type=float, nargs="+", default=[5, 10, 20])
    ap.add_argument("--scene-col", default="scene")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)

    rows = list(csv.DictReader(open(args.residuals)))
    by_scene = collections.defaultdict(list)
    for r in rows:
        by_scene[r[args.scene_col]].append(r)
    rpc_all = stats([float(r["r_rpc_m"]) for r in rows if r.get("r_rpc_m") not in ("", None)])

    # per scene: fit both matchers once, compute predictions + agreement
    scene_data = {}  # scene -> dict(agree_m, resid_fused, resid_roma, resid_xoftr, rpc)
    n_missing = 0
    for scene, pts in by_scene.items():
        rd = os.path.join(args.out_root, args.roma_exp, scene)
        xd = os.path.join(args.out_root, args.xoftr_exp, scene)
        if not (os.path.exists(os.path.join(rd, "matches.csv"))
                and os.path.exists(os.path.join(xd, "matches.csv"))):
            n_missing += 1
            continue
        tf_r, src_r, dst_r = load_matches(rd)
        tf_x, src_x, dst_x = load_matches(xd)
        g = tf_r["grid_transform"]           # same common grid for both runs
        mpp = m_per_px(g)
        A_r = medfilter_fit(src_r, dst_r, args.medfilter_tol / mpp)
        A_x = medfilter_fit(src_x, dst_x, args.medfilter_tol / mpp)
        if A_r is None or A_x is None:
            scene_data[scene] = dict(agree_m=float("inf"))
            continue
        lons = np.array([float(p["lon_rpc"]) for p in pts])
        lats = np.array([float(p["lat_rpc"]) for p in pts])
        c, r = lonlat_to_px(lons, lats, g)
        cr, rr = apply_A(c, r, A_r)
        cx, rx = apply_A(c, r, A_x)
        # AGREEMENT — production-available: evaluated on a fixed grid spanning the
        # matched region (NO tie-point information; computable from GEC+matches
        # alone). Affine disagreement varies smoothly, so grid sampling ~= any
        # other sampling; the extent comes from the matches' bounding box.
        allpts = np.vstack([src_r, src_x])
        gx = np.linspace(allpts[:, 0].min(), allpts[:, 0].max(), 20)
        gy = np.linspace(allpts[:, 1].min(), allpts[:, 1].max(), 20)
        GC, GR = np.meshgrid(gx, gy)
        gcr, grr = apply_A(GC.ravel(), GR.ravel(), A_r)
        gcx, grx = apply_A(GC.ravel(), GR.ravel(), A_x)
        agree = float(np.mean(np.hypot(gcr - gcx, grr - grx)) * mpp)
        # fused = midpoint
        cf, rf = 0.5 * (cr + cx), 0.5 * (rr + rx)
        lo_f, la_f = px_to_lonlat(cf, rf, g)
        lo_r, la_r = px_to_lonlat(cr, rr, g)
        lo_x, la_x = px_to_lonlat(cx, rx, g)
        res_f, res_r, res_x, rpc = [], [], [], []
        for i, p in enumerate(pts):
            eo = (float(p["lon_eo"]), float(p["lat_eo"]))
            res_f.append(haversine_m(lo_f[i], la_f[i], *eo))
            res_r.append(haversine_m(lo_r[i], la_r[i], *eo))
            res_x.append(haversine_m(lo_x[i], la_x[i], *eo))
            rpc.append(float(p["r_rpc_m"]))
        scene_data[scene] = dict(agree_m=agree, f=res_f, r=res_r, x=res_x, rpc=rpc)

    # per-scene table
    with open(os.path.join(args.out, "per_scene_agreement.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["scene", "agreement_m", "fused_ce90", "rpc_ce90", "n_pts"])
        for s, d in sorted(scene_data.items(), key=lambda kv: kv[1]["agree_m"]):
            if np.isfinite(d["agree_m"]) and "f" in d:
                w.writerow([s, f"{d['agree_m']:.2f}", f"{stats(d['f'])['ce90']:.2f}",
                            f"{stats(d['rpc'])['ce90']:.2f}", len(d["f"])])
            else:
                w.writerow([s, "inf", "", "", 0])

    lines = [f"Multi-matcher agreement gate  (medfilter tol {args.medfilter_tol:g} m; "
             f"agreement = mean RoMa-vs-XoFTR prediction distance on a fixed grid)", "",
             f"RPC baseline, ALL scenes: CE90 {rpc_all['ce90']:.2f}  median {rpc_all['median']:.2f}  n {rpc_all['n']}",
             f"scenes with both matchers: {len(scene_data)}  (missing either: {n_missing})", ""]
    hdr = f"{'agree_tol':<10}{'scenes':>8}{'n_pts':>7} | {'fused ce90':>11}{'med':>7}{'rmse':>8} | {'roma ce90':>10} | {'xoftr ce90':>11} | {'rpc ce90 (kept)':>16}"
    lines += [hdr, "-" * len(hdr)]
    for tol in args.agree_tols:
        kept = [d for d in scene_data.values() if np.isfinite(d["agree_m"])
                and d["agree_m"] <= tol and "f" in d]
        f_all = [v for d in kept for v in d["f"]]
        r_all = [v for d in kept for v in d["r"]]
        x_all = [v for d in kept for v in d["x"]]
        p_all = [v for d in kept for v in d["rpc"]]
        sf, sr, sx, sp = stats(f_all), stats(r_all), stats(x_all), stats(p_all)
        lines.append(f"{tol:<10g}{len(kept):>5}/{len(scene_data):<3}{sf['n']:>6} | "
                     f"{sf['ce90']:>11.2f}{sf['median']:>7.2f}{sf['rmse']:>8.2f} | "
                     f"{sr['ce90']:>10.2f} | {sx['ce90']:>11.2f} | {sp['ce90']:>16.2f}")

    # SYSTEM-LEVEL: every scene ships a product — fused where eligible, the
    # RPC-ellipsoid product as fallback where not (incl. scenes missing a run).
    # CE90 over ALL tie points: same denominator as the baseline, no coverage
    # asterisk; the learned fraction is disclosed alongside.
    lines += ["", "SYSTEM (fused where eligible, RPC-ellipsoid fallback elsewhere; ALL tie points):"]
    hdr2 = (f"{'agree_tol':<10}{'learned scenes':>15}{'learned pts':>13}{'n_pts':>7} | "
            f"{'system ce90':>12}{'med':>7}{'rmse':>8} | {'vs rpc ce90':>12}")
    lines += [hdr2, "-" * len(hdr2)]
    # rpc residuals for every scene (fallback source), incl. scenes without runs
    rpc_by_scene = {s: [float(p["r_rpc_m"]) for p in pts if p.get("r_rpc_m") not in ("", None)]
                    for s, pts in by_scene.items()}
    for tol in args.agree_tols:
        sys_res, n_learn_pts, n_learn_scenes = [], 0, 0
        for scene in by_scene:
            d = scene_data.get(scene)
            eligible = (d is not None and np.isfinite(d.get("agree_m", float("inf")))
                        and d["agree_m"] <= tol and "f" in d)
            if eligible:
                sys_res.extend(d["f"])
                n_learn_pts += len(d["f"])
                n_learn_scenes += 1
            else:
                sys_res.extend(rpc_by_scene[scene])
        ss = stats(sys_res)
        lines.append(f"{tol:<10g}{n_learn_scenes:>10}/{len(by_scene):<4}{n_learn_pts:>9}/{rpc_all['n']:<4}"
                     f"{ss['n']:>6} | {ss['ce90']:>12.2f}{ss['median']:>7.2f}{ss['rmse']:>8.2f} | "
                     f"{rpc_all['ce90']:>12.2f}")
    txt = "\n".join(lines)
    open(os.path.join(args.out, "summary.txt"), "w").write(txt + "\n")
    print(txt)
    print(f"\n[out] {args.out}/summary.txt, per_scene_agreement.csv")


if __name__ == "__main__":
    main()
