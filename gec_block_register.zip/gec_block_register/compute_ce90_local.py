#!/usr/bin/env python3
"""CE90 via LOCAL transfer + scene trust filtering (CPU, from saved matches).

Fixes the global-affine tail: instead of one affine per scene (which extrapolates
tie points far from the match cluster to hundreds of metres), each tie point is
moved by the inverse-distance-weighted displacement of its k nearest matches. A
tie point with no matches within max_px is UNSUPPORTED -> skipped, not flung.

Scene trust filter (drop the scenes poisoning the pool):
  * report exhausted / n_points < min-points            -> drop scene
  * pooled matches cover < min-hull-frac of the scene    -> drop scene (clustered)
  * fraction of tie points unsupported > max-unsupported -> drop scene (thin coverage)

Every drop is logged with its reason. Reports both the pooled CE90 over kept
scenes and, for comparison, what each dropped scene would have contributed.

    python compute_ce90_local.py \
        --residuals /home/tabtahi/SATLOCK/ce90_out/residuals.csv \
        --out-root  /home/tabtahi/SATLOCK/gec_block_register/out_height \
        --experiments xoftr_all roma_all \
        --k 8 --max-px 1500 --min-points 50 --min-hull-frac 0.05 \
        --max-unsupported 0.5 --out /home/tabtahi/SATLOCK/ce90_out/local
"""
import argparse
import collections
import csv
import json
import math
import os

import numpy as np
import cv2


def haversine_m(lon1, lat1, lon2, lat2):
    R = 6371008.8
    p1, p2 = math.radians(lat1), math.radians(lat2)
    a = (math.sin(math.radians(lat2 - lat1) / 2) ** 2
         + math.cos(p1) * math.cos(p2) * math.sin(math.radians(lon2 - lon1) / 2) ** 2)
    return 2 * R * math.asin(math.sqrt(a))


def stats(vals):
    v = np.asarray([x for x in vals if np.isfinite(x)], float)
    if v.size == 0:
        return dict(n=0, median=float("nan"), rmse=float("nan"), ce90=float("nan"), p95=float("nan"))
    return dict(n=int(v.size), median=float(np.median(v)),
                rmse=float(np.sqrt(np.mean(v ** 2))),
                ce90=float(np.percentile(v, 90)), p95=float(np.percentile(v, 95)))


def load_run(run_dir):
    with open(os.path.join(run_dir, "transform.json")) as f:
        tf = json.load(f)
    src, dst = [], []
    with open(os.path.join(run_dir, "matches.csv")) as f:
        for r in csv.DictReader(f):
            src.append([float(r["x_sar_px"]), float(r["y_sar_px"])])
            dst.append([float(r["x_wv_px"]), float(r["y_wv_px"])])
    rep = {}
    rp = os.path.join(run_dir, "report.json")
    if os.path.exists(rp):
        rep = json.load(open(rp))
    return tf, np.array(src), np.array(dst), rep


def lonlat_to_px(lon, lat, g):
    a, b, c, d, e, f = g
    Minv = np.linalg.inv(np.array([[a, b], [d, e]], float))
    v = np.stack([np.asarray(lon) - c, np.asarray(lat) - f], -1)
    px = v @ Minv.T
    return px[..., 0], px[..., 1]


def px_to_lonlat(col, row, g):
    a, b, c, d, e, f = g
    return a * col + b * row + c, d * col + e * row + f


def local_refine(lons, lats, src, dst, g, k, max_px, power=2.0):
    """IDW of k nearest matches' displacement. Returns refined lon/lat + n_near."""
    disp = dst - src
    c, r = lonlat_to_px(lons, lats, g)
    pts = np.stack([c, r], -1)
    out_lon = np.empty(len(pts)); out_lat = np.empty(len(pts)); n_near = np.zeros(len(pts), int)
    for i, p in enumerate(pts):
        d = np.linalg.norm(src - p, axis=1)
        idx = np.argsort(d)[:k]
        near = d[idx] <= max_px
        if not near.any():
            out_lon[i], out_lat[i] = np.nan, np.nan  # unsupported
            continue
        dn, dd = d[idx][near], disp[idx][near]
        w = 1.0 / np.maximum(dn, 1e-6) ** power
        dv = (w[:, None] * dd).sum(0) / w.sum()
        out_lon[i], out_lat[i] = px_to_lonlat(p[0] + dv[0], p[1] + dv[1], g)
        n_near[i] = int(near.sum())
    return out_lon, out_lat, n_near


def hull_frac(src, shape_hint=None):
    """Convex-hull area of matches / bounding-box area (spread proxy)."""
    if len(src) < 3:
        return 0.0
    hull = cv2.convexHull(src.astype(np.float32))
    ha = cv2.contourArea(hull)
    bb = (src[:, 0].max() - src[:, 0].min()) * (src[:, 1].max() - src[:, 1].min())
    return float(ha / bb) if bb > 0 else 0.0


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--residuals", required=True)
    ap.add_argument("--out-root", required=True)
    ap.add_argument("--experiments", nargs="+", required=True)
    ap.add_argument("--k", type=int, default=8)
    ap.add_argument("--max-px", type=float, default=1500.0)
    ap.add_argument("--min-points", type=int, default=50)
    ap.add_argument("--min-hull-frac", type=float, default=0.05)
    ap.add_argument("--max-unsupported", type=float, default=0.5,
                    help="drop scene if >this fraction of its tie points are unsupported")
    ap.add_argument("--scene-col", default="scene")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)

    rows = list(csv.DictReader(open(args.residuals)))
    by_scene = collections.defaultdict(list)
    for r in rows:
        by_scene[r[args.scene_col]].append(r)
    rpc_all = [float(r["r_rpc_m"]) for r in rows if r.get("r_rpc_m") not in ("", None)]

    for exp in args.experiments:
        kept, dropped = [], {}          # kept residuals; dropped scene -> (reason, would-be residuals)
        drop_reasons = collections.Counter()
        per_scene = []
        rpc_paired = []                 # RPC residuals on the SAME kept points

        for scene, pts in by_scene.items():
            run_dir = os.path.join(args.out_root, exp, scene)
            if not os.path.exists(os.path.join(run_dir, "matches.csv")):
                drop_reasons["no_run"] += 1
                continue
            tf, src, dst, rep = load_run(run_dir)
            g = tf["grid_transform"]

            # trust gates
            lad = rep.get("ladder", {})
            npts = lad.get("rung_used", {}).get("n_points", len(src))
            reason = None
            if lad.get("exhausted") or npts < args.min_points or len(src) < args.min_points:
                reason = "few_points"
            elif hull_frac(src) < args.min_hull_frac:
                reason = "clustered"

            lons = np.array([float(p["lon_rpc"]) for p in pts])
            lats = np.array([float(p["lat_rpc"]) for p in pts])
            rlon, rlat, n_near = local_refine(lons, lats, src, dst, g, args.k, args.max_px)
            resid = np.array([haversine_m(rlon[i], rlat[i],
                                          float(pts[i]["lon_eo"]), float(pts[i]["lat_eo"]))
                              if np.isfinite(rlon[i]) else np.nan for i in range(len(pts))])
            unsupported = np.mean(~np.isfinite(resid))
            if reason is None and unsupported > args.max_unsupported:
                reason = "thin_coverage"

            supported = resid[np.isfinite(resid)]
            rpc_scene = [float(p["r_rpc_m"]) for p in pts if p.get("r_rpc_m") not in ("", None)]
            per_scene.append((scene, reason or "keep", len(supported),
                              float(np.median(supported)) if supported.size else float("nan"),
                              stats(supported)["ce90"], float(unsupported)))
            if reason:
                drop_reasons[reason] += 1
                dropped[scene] = supported
                continue
            kept.extend(supported.tolist())
            rpc_paired.extend(rpc_scene)

        # write per-scene
        with open(os.path.join(args.out, f"{exp}_per_scene.csv"), "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["scene", "status", "n_supported", "median_m", "ce90_m", "frac_unsupported"])
            for row in sorted(per_scene, key=lambda x: -(x[4] if np.isfinite(x[4]) else 0)):
                w.writerow([row[0], row[1], row[2],
                            f"{row[3]:.2f}", f"{row[4]:.2f}", f"{row[5]:.2f}"])

        kst = stats(kept)
        allst = stats(kept + [v for arr in dropped.values() for v in arr.tolist()])
        rpcst = stats(rpc_paired)
        print(f"\n===== {exp}  (local transfer, k={args.k}, max_px={args.max_px:g}) =====")
        print(f"  scenes kept {len(by_scene)-sum(drop_reasons.values())} / {len(by_scene)}"
              f"   dropped: {dict(drop_reasons)}")
        print(f"  {'candidate':<26}{'n':>6}{'median':>9}{'rmse':>9}{'ce90':>9}{'p95':>9}")
        print("  " + "-" * 68)
        print(f"  {'RPC-ellip (kept scenes)':<26}{rpcst['n']:>6}{rpcst['median']:>9.2f}"
              f"{rpcst['rmse']:>9.2f}{rpcst['ce90']:>9.2f}{rpcst['p95']:>9.2f}")
        print(f"  {exp+' (kept)':<26}{kst['n']:>6}{kst['median']:>9.2f}"
              f"{kst['rmse']:>9.2f}{kst['ce90']:>9.2f}{kst['p95']:>9.2f}")
        print(f"  {exp+' (all scenes)':<26}{allst['n']:>6}{allst['median']:>9.2f}"
              f"{allst['rmse']:>9.2f}{allst['ce90']:>9.2f}{allst['p95']:>9.2f}")
        won = (np.isfinite(kst['ce90']) and np.isfinite(rpcst['ce90']) and kst['ce90'] < rpcst['ce90'])
        print(f"  -> kept-scene CE90 {'BEATS' if won else 'does NOT beat'} RPC-ellip "
              f"({kst['ce90']:.1f} vs {rpcst['ce90']:.1f} m)")
        with open(os.path.join(args.out, f"{exp}_summary.txt"), "w") as f:
            f.write(f"{exp} local transfer\nkept CE90 {kst['ce90']:.2f}  RPC {rpcst['ce90']:.2f}\n"
                    f"dropped {dict(drop_reasons)}\n")


if __name__ == "__main__":
    main()
