#!/bin/bash
# Multi-GPU ablation batch: --select all  and  --select nostruct, both matchers,
# every triple-complete scene, sharded across all visible GPUs.
# Outputs go to SEPARATE trees so nothing collides with the ladder runs:
#   out_height/roma_all/<scene>/<scene>_reg_R_all.tif
#   out_height/xoftr_all/<scene>/<scene>_reg_xf_all.tif
#   out_height/roma_nostruct/<scene>/<scene>_reg_R_nostruct.tif
#   out_height/xoftr_nostruct/<scene>/<scene>_reg_xf_nostruct.tif
# Each with report.json / transform.json / matches.csv / PNG panels.
#
#   ./run_ablations_gpu.sh            # auto-detect GPUs
#   ./run_ablations_gpu.sh 2          # force count
#   SELECTS="all" ./run_ablations_gpu.sh    # only one experiment
set -u
cd /home/tabtahi/SATLOCK/gec_block_register
mkdir -p logs

NGPU=${1:-$(nvidia-smi -L 2>/dev/null | wc -l)}
[ "$NGPU" -lt 1 ] && { echo "no GPUs visible"; exit 1; }
SELECTS=${SELECTS:-"all nostruct"}
MATCHERS=${MATCHERS:-"roma xoftr"}
echo "$(date)  ${NGPU} GPU(s); experiments: [${SELECTS}] x matchers: [${MATCHERS}]"

# inventory
> scenes_gpu.txt
for d in /home/tabtahi/SATLOCK/dataset/SAR_RPC_ellip_dem/*/*_dem_ellip.tif; do
  s=$(basename "$d" _dem_ellip.tif)
  sa="/home/tabtahi/SATLOCK/dataset/SAR_RPC_ellip/${s}/${s}_rpc_ellip.tif"
  w=$(ls /home/kashley/satlock/mosaic_datasets/eo_sar_umbra_subset_HH_unique_v2/wv_dailytake_output/${s}/mosaic/*.tif 2>/dev/null | head -1)
  [ -f "$sa" ] && [ -n "$w" ] && echo "$s" >> scenes_gpu.txt
done
total=$(wc -l < scenes_gpu.txt)
echo "$(date)  ${total} scenes queued"

# build the flat job list: scene x select x matcher, then shard jobs across GPUs
> jobs_ablation.txt
while read scene; do
  for sel in $SELECTS; do
    for m in $MATCHERS; do
      echo "${scene} ${sel} ${m}" >> jobs_ablation.txt
    done
  done
done < scenes_gpu.txt
njobs=$(wc -l < jobs_ablation.txt)
echo "$(date)  ${njobs} jobs across ${NGPU} workers"

worker() {
  gpu=$1; j=0
  while read scene sel m; do
    j=$((j+1))
    [ $(( (j-1) % NGPU )) -ne "$gpu" ] && continue
    dem="/home/tabtahi/SATLOCK/dataset/SAR_RPC_ellip_dem/${scene}/${scene}_dem_ellip.tif"
    sar="/home/tabtahi/SATLOCK/dataset/SAR_RPC_ellip/${scene}/${scene}_rpc_ellip.tif"
    wv=$(ls /home/kashley/satlock/mosaic_datasets/eo_sar_umbra_subset_HH_unique_v2/wv_dailytake_output/${scene}/mosaic/*.tif | head -1)
    exp="${m}_${sel}"
    out="out_height/${exp}/${scene}"
    if [ -f "${out}/report.json" ]; then echo "[gpu${gpu} skip] ${exp} ${scene}"; continue; fi
    for attempt in 1 2 3; do
      echo "[gpu${gpu} job ${j}/${njobs}] $(date +%H:%M) ${exp} ${scene} (try ${attempt})"
      docker run --rm --gpus "\"device=${gpu}\"" \
        -v /home/tabtahi/SATLOCK/dataset:/home/tabtahi/SATLOCK/dataset \
        -v /home/kashley/satlock/mosaic_datasets:/home/kashley/satlock/mosaic_datasets \
        -v /home/tabtahi/SATLOCK/gec_block_register/out_height:/work/out_height \
        height-register \
        --sar "$sar" --dem "$dem" --wv "$wv" \
        --matcher "${m}" --select "${sel}" --device cuda \
        --out "/work/out_height/${exp}/${scene}" \
        >> "logs/${exp}_${scene}.log" 2>&1
      [ -f "${out}/report.json" ] && break
      echo "[gpu${gpu} retry] ${exp} ${scene}; 60s"; sleep 60
    done
  done < jobs_ablation.txt
  echo "[gpu${gpu}] $(date) worker done"
}

pids=""
for g in $(seq 0 $((NGPU-1))); do
  worker "$g" > "logs/ablation_worker_${g}.log" 2>&1 &
  pids="$pids $!"; echo "worker gpu${g} pid $!"
done
wait $pids
echo "$(date)  ablation batch complete"
