"""Per-block registration: match -> RANSAC affine -> trustworthiness gates.

This is where the grid earns its keep and where confident-liar blocks get caught.
Each kept block is matched, RANSAC-cleaned, and run through the gates from the
brainstorm. The OUTPUT for the baseline is a pooled set of clean correspondences
(globalized to common-grid coords) plus a per-block log of what happened.

Gate policy (which failures DROP correspondences vs DOWNGRADE to translation):
  too_few         -> drop  (nothing trustworthy)
  implausible_svd -> drop  (RANSAC locked onto a self-consistent WRONG set)
  consensus       -> drop  (disagrees with the scene -> repeated-structure mismatch)
  under_constrained (spread/condition) -> keep correspondences, label "translation"
        (the point pairs are fine; only the 6-DOF MODEL is locally unsupported)

For the global-affine baseline we pool every KEPT correspondence and fit once.
The per-block affines + labels are what a v2 smooth affine field would consume.
"""
from dataclasses import dataclass, field

import cv2
import numpy as np

from config import GateConfig


@dataclass
class BlockResult:
    r0: int
    c0: int
    model: str                 # "affine" | "translation" | "drop"
    reason: str
    n_inliers: int
    disp: tuple                # (dx, dy) median inlier displacement, for gate 5
    src: np.ndarray = field(default_factory=lambda: np.zeros((0, 2), np.float32))  # GEC global
    dst: np.ndarray = field(default_factory=lambda: np.zeros((0, 2), np.float32))  # ref global
    conf: np.ndarray = field(default_factory=lambda: np.zeros((0,), np.float32))


def _affine_gates(A, src_in, block_area, g: GateConfig):
    """Return (ok_affine: bool, reason: str). src_in are inlier GEC points."""
    n = len(src_in)
    if n < g.min_inliers_affine:
        return False, "few_for_affine"

    # spread / collinearity
    c = src_in - src_in.mean(0)
    cov = c.T @ c / max(n - 1, 1)
    eig = np.linalg.eigvalsh(cov)
    eig = np.clip(eig, 0, None)
    aniso = (eig[0] / eig[1]) if eig[1] > 0 else 0.0
    try:
        hull_area = cv2.contourArea(cv2.convexHull(src_in.astype(np.float32)))
    except Exception:
        hull_area = 0.0
    if aniso < g.aniso_min or (hull_area / max(block_area, 1)) < g.hull_frac_min:
        return False, "under_constrained_spread"

    # conditioning of the centered point set
    s = np.linalg.svd(c, compute_uv=False)
    cond = (s[0] / s[-1]) if s[-1] > 1e-9 else np.inf
    if cond > g.cond_max:
        return False, "ill_conditioned"

    # physical plausibility of the 2x2 linear part
    M = A[:, :2]
    if np.linalg.det(M) <= 0:
        return False, "implausible_svd"
    sv = np.linalg.svd(M, compute_uv=False)
    if sv.min() < g.sv_lo or sv.max() > g.sv_hi:
        return False, "implausible_svd"
    U, _, Vt = np.linalg.svd(M)
    R = U @ Vt
    rot = abs(np.degrees(np.arctan2(R[1, 0], R[0, 0])))
    if rot > g.rot_deg_max:
        return False, "implausible_svd"
    return True, "ok"


@dataclass
class RawBlockMatches:
    """Cached output of the expensive matcher pass for one block — everything the
    (cheap, re-runnable) gate stage needs. Heights are attached once so the
    altitude ladder can filter without re-matching."""
    blk: object
    src: np.ndarray                # (N,2) block-LOCAL GEC/ortho x,y
    dst: np.ndarray                # (N,2) block-LOCAL reference x,y
    conf: np.ndarray               # (N,)
    heights: np.ndarray = None     # (N,) DEM height at each src point (global frame)


def harvest_block(blk, gec_rgb, ref_rgb, matcher, conf_thresh):
    """GPU pass: match one block, threshold by confidence. Run ONCE per block."""
    m = matcher.match(gec_rgb[blk.slice], ref_rgb[blk.slice])
    keep = m.conf >= conf_thresh
    return RawBlockMatches(blk, m.kpts_a[keep], m.kpts_b[keep], m.conf[keep])


def gate_block(raw: RawBlockMatches, g: GateConfig, height_cutoff=None, keep_mask=None,
               max_disp_px=None):
    """CPU pass: (height filter / keep mask / max-displacement gate) -> RANSAC affine -> gates.

    Filtering happens BEFORE RANSAC so bad correspondences cannot steer the block
    affine. max_disp_px discards matches whose implied shift |dst-src| exceeds the
    threshold — a physical sanity gate: the ellipsoid product is already ~25 m
    CE90, so a learned correspondence implying a large jump is almost certainly a
    mismatch (ship->cloud, repeated-structure lock), not a real correction.
    """
    blk = raw.blk
    src, dst, conf = raw.src, raw.dst, raw.conf
    keep = np.ones(len(conf), bool)
    if height_cutoff is not None and raw.heights is not None:
        keep &= raw.heights <= height_cutoff
    if keep_mask is not None:
        keep &= keep_mask
    if max_disp_px is not None and len(conf):
        keep &= np.linalg.norm(raw.dst - raw.src, axis=1) <= max_disp_px
    src, dst, conf = src[keep], dst[keep], conf[keep]

    origin = np.array([blk.c0, blk.r0], np.float32)  # x,y
    g_src, g_dst = src + origin, dst + origin

    if len(src) < g.min_inliers_trans:
        return BlockResult(blk.r0, blk.c0, "drop", "too_few", 0, (0, 0))

    A, mask = cv2.estimateAffine2D(src.astype(np.float32), dst.astype(np.float32),
                                   method=cv2.RANSAC, ransacReprojThreshold=g.ransac_thresh,
                                   maxIters=5000, confidence=0.999)
    if A is None or mask is None or int(mask.sum()) < g.min_inliers_trans:
        return BlockResult(blk.r0, blk.c0, "drop", "ransac_fail", 0, (0, 0))
    mask = mask.ravel().astype(bool)
    in_src, in_conf = src[mask], conf[mask]
    gin_src, gin_dst = g_src[mask], g_dst[mask]
    disp = tuple(np.median(dst[mask] - in_src, axis=0))

    ok, reason = _affine_gates(A, in_src, blk.h * blk.w, g)
    if reason in ("implausible_svd",):
        return BlockResult(blk.r0, blk.c0, "drop", reason, int(mask.sum()), disp)

    model = "affine" if ok else "translation"
    return BlockResult(blk.r0, blk.c0, model, reason if not ok else "ok",
                       int(mask.sum()), disp, gin_src, gin_dst, in_conf)


def register_block(blk, gec_rgb, ref_rgb, matcher, conf_thresh, g: GateConfig):
    """Match one block pair and gate it. Coords returned are GLOBAL (common-grid)."""
    a = gec_rgb[blk.slice]
    b = ref_rgb[blk.slice]
    m = matcher.match(a, b)
    keep = m.conf >= conf_thresh
    src, dst, conf = m.kpts_a[keep], m.kpts_b[keep], m.conf[keep]

    origin = np.array([blk.c0, blk.r0], np.float32)  # x,y
    g_src, g_dst = src + origin, dst + origin
    empty = np.zeros((0, 2), np.float32)

    if len(src) < g.min_inliers_trans:
        return BlockResult(blk.r0, blk.c0, "drop", "too_few", 0, (0, 0))

    # RANSAC affine to find inliers
    A, mask = cv2.estimateAffine2D(src.astype(np.float32), dst.astype(np.float32),
                                   method=cv2.RANSAC, ransacReprojThreshold=g.ransac_thresh,
                                   maxIters=5000, confidence=0.999)
    if A is None or mask is None or int(mask.sum()) < g.min_inliers_trans:
        return BlockResult(blk.r0, blk.c0, "drop", "ransac_fail", 0, (0, 0))
    mask = mask.ravel().astype(bool)
    in_src, in_dst, in_conf = src[mask], dst[mask], conf[mask]
    gin_src, gin_dst = g_src[mask], g_dst[mask]
    disp = tuple(np.median(in_dst - in_src, axis=0))  # (dx,dy)

    ok, reason = _affine_gates(A, in_src, blk.h * blk.w, g)
    if reason in ("implausible_svd",):
        # confident-liar -> drop the correspondences entirely
        return BlockResult(blk.r0, blk.c0, "drop", reason, int(mask.sum()), disp)

    model = "affine" if ok else "translation"
    return BlockResult(blk.r0, blk.c0, model, reason if not ok else "ok",
                       int(mask.sum()), disp, gin_src, gin_dst, in_conf)


def consensus_filter(results, g: GateConfig):
    """Gate 5: drop blocks whose displacement disagrees with the scene consensus
    (robust MAD outlier rejection on per-block (dx,dy)). Catches repeated-structure
    mismatches that pass the per-block gates."""
    live = [r for r in results if r.model != "drop" and r.n_inliers > 0]
    if len(live) < 3:
        return results
    D = np.array([r.disp for r in live])
    med = np.median(D, axis=0)
    mad = np.median(np.abs(D - med), axis=0) * 1.4826 + 1e-6
    for r in live:
        z = np.abs(np.array(r.disp) - med) / mad
        if np.any(z > g.consensus_mad_k):
            r.model, r.reason = "drop", "consensus"
            r.src = r.dst = np.zeros((0, 2), np.float32)
            r.conf = np.zeros((0,), np.float32)
    return results


def pool(results):
    """Union of kept correspondences across blocks -> arrays for the global fit."""
    src = [r.src for r in results if len(r.src)]
    dst = [r.dst for r in results if len(r.dst)]
    conf = [r.conf for r in results if len(r.conf)]
    if not src:
        return (np.zeros((0, 2), np.float32),) * 2 + (np.zeros((0,), np.float32),)
    return np.vstack(src), np.vstack(dst), np.concatenate(conf)
