#!/usr/bin/env python3
"""Visualize the gridded two-matcher consensus that drives the eligibility gate.

For each scene, the 20x20 grid spanning the matched region is pushed through
RoMa's affine and XoFTR's affine independently. Per grid point we get two
predicted destinations; the mean distance between them IS the agreement metric.
This renders that comparison so it can be read by eye:

  left   SAR with grid points coloured by per-point disagreement (m)
  right  dual quiver — where RoMa (blue) vs XoFTR (red) send each grid point,
         drawn from the same origin so agreement = overlapping arrows

Scenes are picked to span the agreement range (tight -> marginal -> rejected)
unless named explicitly.

    python plot_grid_consensus.py \
        --learned-root /home/tabtahi/SATLOCK/dataset/SAR_learned \
        --sar-root /home/tabtahi/SATLOCK/dataset/SAR_RPC_ellip \
        --n 5 --out /home/tabtahi/SATLOCK/ce90_out/grid_consensus.png
"""
import argparse
import csv
import glob
import json
import math
import os

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

GRID_N = 20


def load_matches(run_dir):
    tf = json.load(open(os.path.join(run_dir, "transform.json")))
    src, dst = [], []
    with open(os.path.join(run_dir, "matches.csv")) as f:
        for r in csv.DictReader(f):
            src.append([float(r["x_sar_px"]), float(r["y_sar_px"])])
            dst.append([float(r["x_wv_px"]), float(r["y_wv_px"])])
    return tf, np.array(src), np.array(dst)


def m_per_px(g):
    lat = g[5]
    return 0.5 * (abs(g[0]) * 111320.0 * max(math.cos(math.radians(lat)), 1e-3)
                  + abs(g[4]) * 111320.0)


def medfilter_fit(src, dst, tol_px, min_kept=20):
    import cv2
    if len(src) < 3:
        return None
    disp = dst - src
    med = np.median(disp, axis=0)
    keep = np.linalg.norm(disp - med, axis=1) <= tol_px
    if keep.sum() < min_kept:
        return None
    A, _ = cv2.estimateAffine2D(src[keep].astype(np.float32), dst[keep].astype(np.float32),
                                method=cv2.RANSAC, ransacReprojThreshold=3.0,
                                maxIters=10000, confidence=0.9999)
    return A


def apply_A(A, c, r):
    return A[0, 0] * c + A[0, 1] * r + A[0, 2], A[1, 0] * c + A[1, 1] * r + A[1, 2]


def scene_consensus(sdir, medfilter_tol):
    """Returns dict with grid, both predictions, per-point disagreement (m)."""
    rd, xd = os.path.join(sdir, "roma"), os.path.join(sdir, "xoftr")
    if not all(os.path.exists(os.path.join(d, "matches.csv")) for d in (rd, xd)):
        return None
    tf_r, src_r, dst_r = load_matches(rd)
    tf_x, src_x, dst_x = load_matches(xd)
    g = tf_r["grid_transform"]
    mpp = m_per_px(g)
    A_r = medfilter_fit(src_r, dst_r, medfilter_tol / mpp)
    A_x = medfilter_fit(src_x, dst_x, medfilter_tol / mpp)
    if A_r is None or A_x is None:
        return None
    allp = np.vstack([src_r, src_x])
    gx = np.linspace(allp[:, 0].min(), allp[:, 0].max(), GRID_N)
    gy = np.linspace(allp[:, 1].min(), allp[:, 1].max(), GRID_N)
    GC, GR = np.meshgrid(gx, gy)
    c, r = GC.ravel(), GR.ravel()
    cr, rr = apply_A(A_r, c, r)
    cx, rx = apply_A(A_x, c, r)
    dis_m = np.hypot(cr - cx, rr - rx) * mpp
    return dict(c=c, r=r, cr=cr, rr=rr, cx=cx, rx=rx, dis_m=dis_m,
                mean_m=float(dis_m.mean()), mpp=mpp,
                n_roma=len(src_r), n_xoftr=len(src_x),
                width=tf_r.get("grid_width"), height=tf_r.get("grid_height"))


def read_background(path, max_px=700):
    try:
        import rasterio
        from rasterio.enums import Resampling
        with rasterio.open(path) as ds:
            step = max(1, int(np.ceil(max(ds.width, ds.height) / max_px)))
            arr = ds.read(1, out_shape=(ds.height // step, ds.width // step),
                          resampling=Resampling.average).astype(np.float32)
        v = arr[np.isfinite(arr) & (arr > 0)]
        if v.size == 0:
            return None, 1.0
        lo, hi = np.percentile(v, (2, 98))
        return np.clip((arr - lo) / max(hi - lo, 1e-6), 0, 1), 1.0 / step
    except Exception:
        return None, 1.0


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--learned-root", required=True)
    ap.add_argument("--sar-root", default=None, help="for the background image")
    ap.add_argument("--scenes", nargs="*", help="explicit scene list (default: spread by agreement)")
    ap.add_argument("--n", type=int, default=5)
    ap.add_argument("--medfilter-tol", type=float, default=10.0)
    ap.add_argument("--agree-tol", type=float, default=50.0)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    if args.scenes:
        picked = args.scenes
    else:
        # spread across the agreement range using the decisions already on disk
        vals = []
        for d in sorted(glob.glob(os.path.join(args.learned_root, "*"))):
            if not os.path.isdir(d):
                continue
            fj, bj = os.path.join(d, "fused.json"), os.path.join(d, "fallback.json")
            a = None
            if os.path.exists(fj):
                try:
                    a = float(json.load(open(fj)).get("agreement_m"))
                except Exception:
                    pass
            elif os.path.exists(bj):
                try:
                    rs = json.load(open(bj)).get("reason") or ""
                    if rs.startswith("disagree"):
                        a = float(rs.split("(")[1].split()[0])
                except Exception:
                    pass
            if a is not None and np.isfinite(a):
                vals.append((a, os.path.basename(d)))
        vals.sort()
        if not vals:
            raise SystemExit("no scenes with an agreement value found")
        idx = np.linspace(0, len(vals) - 1, args.n).astype(int)
        picked = [vals[i][1] for i in idx]
        print("picked (by agreement spread):")
        for i in idx:
            print(f"  {vals[i][0]:8.2f} m  {vals[i][1]}")

    rows = []
    for s in picked:
        cons = scene_consensus(os.path.join(args.learned_root, s), args.medfilter_tol)
        if cons:
            rows.append((s, cons))
        else:
            print(f"  [skip] {s} (no usable match pair)")
    if not rows:
        raise SystemExit("nothing to plot")

    # one quiver scale for ALL rows so arrow length is comparable between scenes
    gmax = 1e-6
    for _, c in rows:
        gmax = max(gmax,
                   np.hypot(c["cr"] - c["c"], c["rr"] - c["r"]).max(),
                   np.hypot(c["cx"] - c["c"], c["rx"] - c["r"]).max())

    fig, axes = plt.subplots(len(rows), 2, figsize=(13, 4.6 * len(rows)),
                             squeeze=False)
    for i, (s, c) in enumerate(rows):
        ok = c["mean_m"] <= args.agree_tol
        bg, sc = (None, 1.0)
        if args.sar_root:
            p = os.path.join(args.sar_root, s, f"{s}_rpc_ellip.tif")
            if os.path.exists(p):
                bg, sc = read_background(p)

        # LEFT: grid points coloured by disagreement
        ax = axes[i][0]
        if bg is not None:
            ax.imshow(bg, cmap="gray", interpolation="nearest")
            X, Y = c["c"] * sc, c["r"] * sc
        else:
            X, Y = c["c"], c["r"]
            ax.invert_yaxis()
        sp = ax.scatter(X, Y, c=c["dis_m"], cmap="RdYlGn_r", s=42,
                        edgecolors="k", linewidths=0.3,
                        vmin=0, vmax=max(args.agree_tol, c["dis_m"].max()))
        plt.colorbar(sp, ax=ax, fraction=0.035, pad=0.01, label="RoMa vs XoFTR (m)")
        ax.set_title(f"{s[:34]}\nmean disagreement {c['mean_m']:.1f} m  "
                     f"[{'ELIGIBLE' if ok else 'REJECTED'}]",
                     fontsize=9, color=("#1a7f1a" if ok else "#b32020"))
        ax.set_xticks([]); ax.set_yticks([])

        # RIGHT: dual quiver from each grid origin
        ax = axes[i][1]
        dxr, dyr = c["cr"] - c["c"], c["rr"] - c["r"]
        dxx, dyx = c["cx"] - c["c"], c["rx"] - c["r"]
        mag = max(np.hypot(dxr, dyr).max(), np.hypot(dxx, dyx).max(), 1e-6)
        q = dict(angles="xy", scale_units="xy", scale=mag / 30.0)
        ax.quiver(c["c"], c["r"], dxr, dyr, color="tab:blue", label="RoMa",
                  width=0.006, alpha=0.85, **q)
        ax.quiver(c["c"], c["r"], dxx, dyx, color="crimson", label="XoFTR",
                  width=0.0028, **q)
        ax.scatter(c["c"], c["r"], s=4, c="k", zorder=3)
        ax.invert_yaxis(); ax.set_aspect("equal")
        ax.legend(fontsize=8, loc="upper right")
        mr = float(np.hypot(dxr, dyr).mean() * c["mpp"])
        mx = float(np.hypot(dxx, dyx).mean() * c["mpp"])
        ax.set_title(f"predicted displacement per grid point (row-scaled)\n"
                     f"RoMa {mr:.1f} m (n={c['n_roma']})   "
                     f"XoFTR {mx:.1f} m (n={c['n_xoftr']})", fontsize=9)
        ax.set_xticks([]); ax.set_yticks([])

    fig.suptitle("Gridded two-matcher consensus — agreement decides scene eligibility "
                 f"(tolerance {args.agree_tol:g} m)", fontsize=12, y=0.999)
    fig.tight_layout(rect=[0, 0, 1, 0.985])
    fig.savefig(args.out, dpi=140, facecolor="white")
    print(f"\n[out] {args.out}")


if __name__ == "__main__":
    main()
