"""Warp: pooled correspondences -> one transform -> resample GEC.

BASELINE (`global_affine`): a single RANSAC affine on the pooled matches. One
transform, no seams, the floor to beat. This is intentionally NOT enough to
capture terrain/layover-driven local distortion (that's the point of the
baseline) but it's a clean, interpretable correction driven by real GEC<->ref
correspondences rather than RPC+DEM re-projection.

NEXT RUNG (`tps`): global affine + a smooth thin-plate-spline residual fit to the
pooled displacements, regularized by `tps_smoothing`. Captures the spatially-
varying correction without block seams, because it is ONE continuous field over
all pooled matches. Shipped here so the upgrade is a flag flip.

All coords are common-grid pixels. The transform maps GEC -> ref, so warping
moves GEC content onto the reference geometry.
"""
import cv2
import numpy as np

from config import WarpConfig


def fit_global_affine(src, dst, thr=3.0):
    """src=GEC, dst=ref. Returns 2x3 affine (GEC->ref) + inlier mask."""
    A, mask = cv2.estimateAffine2D(src.astype(np.float32), dst.astype(np.float32),
                                   method=cv2.RANSAC, ransacReprojThreshold=thr,
                                   maxIters=10000, confidence=0.9999)
    mask = mask.ravel().astype(bool) if mask is not None else None
    return A, mask


def warp_global_affine(gec, A, out_shape):
    H, W = out_shape[:2]
    return cv2.warpAffine(gec, A, (W, H))


def fit_tps_field(src, dst, out_shape, smoothing=1.0):
    """Build remap maps for a smooth field. We interpolate ref->GEC (so each
    output/ref pixel knows where to sample in GEC) with a thin-plate RBF.
    """
    from scipy.interpolate import RBFInterpolator
    H, W = out_shape[:2]
    # fit from ref points to GEC points (inverse map for cv2.remap)
    rbf = RBFInterpolator(dst.astype(np.float64), src.astype(np.float64),
                          kernel="thin_plate_spline", smoothing=smoothing)
    ys, xs = np.mgrid[0:H, 0:W]
    grid = np.stack([xs.ravel(), ys.ravel()], axis=1).astype(np.float64)
    mapped = rbf(grid)  # (H*W, 2) -> GEC x,y to sample
    map_x = mapped[:, 0].reshape(H, W).astype(np.float32)
    map_y = mapped[:, 1].reshape(H, W).astype(np.float32)
    return map_x, map_y


def warp_tps(gec, map_x, map_y):
    return cv2.remap(gec, map_x, map_y, interpolation=cv2.INTER_CUBIC,
                     borderMode=cv2.BORDER_CONSTANT, borderValue=0)


def apply_warp(gec, src, dst, out_shape, cfg: WarpConfig):
    """Dispatch to the configured warp model. Returns (warped, info)."""
    info = {"model": cfg.model, "n_pool": len(src)}
    if cfg.model == "global_affine":
        A, mask = fit_global_affine(src, dst, cfg.ransac_thresh)
        if A is None:
            return None, dict(info, error="affine_fit_failed")
        info["n_inliers"] = int(mask.sum()) if mask is not None else None
        info["affine"] = A.tolist()
        return warp_global_affine(gec, A, out_shape), info
    if cfg.model == "tps":
        mx, my = fit_tps_field(src, dst, out_shape, cfg.tps_smoothing)
        return warp_tps(gec, mx, my), info
    raise ValueError(f"unknown warp model {cfg.model}")
