#!/usr/bin/env python3
"""Metrics comparison over N crops: GEC vs RPC-ellipsoid vs USGS-10m.

Scores each product against a reference (default: hand-aligned GOLD) on matched
512px crops, then reports the comparison table the project uses:

    product        n   SSIM(med)  NCC(med)  gNCC(med)  win%(vs GEC)

    python run_metrics.py --n-crops 100 --reference gold --out metrics_out/

All products are geocoded; each is warped onto the REFERENCE's native grid so the
same crop window is pixel-comparable. Scenes are joined by their <scene-ID> folder
name across the product directories.

--reference gold : accuracy vs ground truth (RPC-ellip / USGS should BEAT GEC).
--reference gec  : deviation of each ortho from raw GEC (GEC drops out as a column).
"""
import argparse
import collections
import csv
import glob
import json
import os

import numpy as np

import io_geo
import crops as cr
import metrics as me
from preprocessing import lee_filter  # noqa: F401  (kept for parity w/ harness)

# Defaults derived from the paths in the project (all overridable on the CLI).
ROOT = "/home/kashley/satlock/mosaic_datasets"
DEFAULTS = {
    "gec":       f"{ROOT}/eo_sar_umbra_subset_HH_unique_v2/SAR",
    "rpc_ellip": f"{ROOT}/eo_sar_umbra_subset_HH_unique_v2_rpc_ellip/SAR_RPC_ellip",
    "usgs":      f"{ROOT}/eo_sar_umbra_subset_HH_unique_v2_USGS10m/SAR_RPC",
    "gold":      f"{ROOT}/eo_sar_umbra_subset_HH_unique_v2_aligned_92_pa/SAR",
}


def find_scene_tif(product_dir, scene):
    for pat in (f"{scene}/*_GEC.tif", f"{scene}/*.tif"):
        hits = sorted(glob.glob(os.path.join(product_dir, pat)))
        if hits:
            return hits[0]
    return None


def score_crops_on_scene(products, ref_gray, crop_list, size, lee_size):
    """PURE (arrays only, no IO) — score each product vs ref on each crop window.

    products : dict name -> product gray on the reference grid
    ref_gray : reference gray on its own grid
    returns  : list of row dicts (one per crop per product)
    """
    rows = []
    for (r0, c0) in crop_list:
        sl = (slice(r0, r0+size), slice(c0, c0+size))
        gold_crop = ref_gray[sl]
        for name, arr in products.items():
            s = me.score_pair(arr[sl], gold_crop, lee_size)
            rows.append({"crop_r": r0, "crop_c": c0, "product": name,
                         "ssim": s["ssim"], "ncc": s["ncc"], "gncc": s["gncc"]})
    return rows


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--gec-dir", default=DEFAULTS["gec"])
    ap.add_argument("--rpc-ellip-dir", default=DEFAULTS["rpc_ellip"])
    ap.add_argument("--usgs-dir", default=DEFAULTS["usgs"])
    ap.add_argument("--gold-dir", default=DEFAULTS["gold"])
    ap.add_argument("--reference", default="gold", choices=["gold", "gec"],
                    help="what crops are scored against")
    ap.add_argument("--n-crops", type=int, default=100)
    ap.add_argument("--per-scene", type=int, default=None,
                    help="max crops per scene (default: spread n-crops over scenes)")
    ap.add_argument("--crop", type=int, default=512)
    ap.add_argument("--lee-size", type=int, default=5)
    ap.add_argument("--scenes", nargs="*", help="explicit scene-IDs (default: gold dir)")
    ap.add_argument("--out", default="metrics_out")
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)

    product_dirs = {"GEC": args.gec_dir, "RPC-ellip": args.rpc_ellip_dir,
                    "USGS-10m": args.usgs_dir}
    ref_dir = args.gold_dir if args.reference == "gold" else args.gec_dir
    ref_name = "GOLD" if args.reference == "gold" else "GEC"
    # when GEC is the reference it isn't also a scored column
    score_products = {k: v for k, v in product_dirs.items()
                      if not (args.reference == "gec" and k == "GEC")}

    # scene list = intersection of what exists across ref + all scored products
    if args.scenes:
        scenes = args.scenes
    else:
        scenes = sorted(os.path.basename(p.rstrip("/"))
                        for p in glob.glob(os.path.join(ref_dir, "*")) if os.path.isdir(p))
    print(f"[cfg] reference={ref_name}  products={list(score_products)}  "
          f"scenes available={len(scenes)}  target crops={args.n_crops}")

    per_scene = args.per_scene or max(1, -(-args.n_crops // max(len(scenes), 1)))
    all_rows, used_scenes, total_crops = [], 0, 0

    for scene in scenes:
        if total_crops >= args.n_crops:
            break
        ref_tif = find_scene_tif(ref_dir, scene)
        prod_tifs = {k: find_scene_tif(d, scene) for k, d in score_products.items()}
        if ref_tif is None or any(v is None for v in prod_tifs.values()):
            continue  # scene missing in some product; skip for a fair comparison
        try:
            ref_gray, transform, crs, shape = io_geo.open_grid(ref_tif)
            if ref_gray.ndim == 3:
                ref_gray = ref_gray.mean(2)
            H, W = shape
            products = {k: io_geo.warp_to_grid(p, transform, crs, W, H)
                        for k, p in prod_tifs.items()}
        except Exception as e:
            print(f"  [skip] {scene}: {e}")
            continue

        valid = [ref_gray > 0] + [a > 0 for a in products.values()]
        want = min(per_scene, args.n_crops - total_crops)
        crop_list = cr.choose_crops(ref_gray, valid, want, size=args.crop, lee_size=args.lee_size)
        if not crop_list:
            continue

        rows = score_crops_on_scene(products, ref_gray, crop_list, args.crop, args.lee_size)
        for r in rows:
            r["scene"] = scene
        all_rows.extend(rows)
        used_scenes += 1
        total_crops += len(crop_list)
        print(f"  {scene}: {len(crop_list)} crops  (running total {total_crops})")

    if not all_rows:
        print("[FAIL] no crops scored — check paths / scene overlap / validity masks.")
        return

    _write_and_summarize(args, all_rows, score_products, ref_name, used_scenes, total_crops)


def _write_and_summarize(args, rows, score_products, ref_name, used_scenes, total_crops):
    # per-crop CSV
    csv_path = os.path.join(args.out, "per_crop.csv")
    with open(csv_path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["scene", "crop_r", "crop_c", "product",
                                          "ssim", "ncc", "gncc"])
        w.writeheader()
        w.writerows(rows)

    # aggregate per product
    by = collections.defaultdict(lambda: collections.defaultdict(list))
    for r in rows:
        for m in ("ssim", "ncc", "gncc"):
            if not np.isnan(r[m]):
                by[r["product"]][m].append(r[m])

    # win-rate vs GEC (only when GEC is a scored column)
    gec_by_crop = {}
    if "GEC" in score_products:
        for r in rows:
            if r["product"] == "GEC":
                gec_by_crop[(r["scene"], r["crop_r"], r["crop_c"])] = r
    winpct = {}
    for name in score_products:
        if name == "GEC" or not gec_by_crop:
            continue
        wins = tot = 0
        for r in rows:
            if r["product"] != name:
                continue
            g = gec_by_crop.get((r["scene"], r["crop_r"], r["crop_c"]))
            if g and not np.isnan(r["ssim"]) and not np.isnan(g["ssim"]):
                tot += 1
                wins += (r["ssim"] > g["ssim"]) and (r["ncc"] > g["ncc"])
        winpct[name] = 100.0 * wins / tot if tot else float("nan")

    summary = {"reference": ref_name, "scenes_used": used_scenes,
               "total_crops": total_crops, "crop": args.crop, "products": {}}
    print(f"\n=== Metrics vs {ref_name}  ({total_crops} crops, {used_scenes} scenes) ===")
    print(f"{'product':<12}{'n':>5}{'SSIM med':>10}{'NCC med':>10}{'gNCC med':>10}{'win% vs GEC':>14}")
    print("-" * 71)
    for name in score_products:
        d = by[name]
        n = len(d["ssim"])
        med = {m: float(np.median(d[m])) if d[m] else float("nan") for m in ("ssim", "ncc", "gncc")}
        mean = {m: float(np.mean(d[m])) if d[m] else float("nan") for m in ("ssim", "ncc", "gncc")}
        wp = winpct.get(name, float("nan"))
        summary["products"][name] = {"n": n, "median": med, "mean": mean, "win_pct_vs_gec": wp}
        wp_s = f"{wp:>13.1f}%" if not np.isnan(wp) else f"{'-':>14}"
        print(f"{name:<12}{n:>5}{med['ssim']:>10.3f}{med['ncc']:>10.3f}{med['gncc']:>10.3f}{wp_s}")

    with open(os.path.join(args.out, "summary.json"), "w") as f:
        json.dump(summary, f, indent=2)
    print(f"\n[out] {csv_path}\n[out] {os.path.join(args.out, 'summary.json')}")


if __name__ == "__main__":
    main()
