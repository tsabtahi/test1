#!/usr/bin/env python3
"""GEC block-registration baseline — end to end.

    python run_baseline.py --gec SCENE/*_GEC.tif --ref GOLD/*_GEC.tif \
        --reference gold --matcher roma --warp global_affine --out out/

Pipeline:
    1. co-locate GEC + reference on one common 4326 grid (WarpedVRT)
    2. preprocess (log -> Lee -> [Sobel] -> stretch)
    3. tile into overlapping blocks; region-select by post-Lee texture
    4. match each kept block; RANSAC affine + trustworthiness gates (per block)
    5. consensus filter (drop blocks that disagree with the scene)
    6. pool clean correspondences -> ONE global affine (baseline) or TPS residual
    7. resample GEC; write georeferenced GeoTIFF
    8. score vs gold (SSIM/NCC) and dump a per-block fallback-reason report

The fallback-reason histogram in report.json is the key diagnostic: it tells you
whether the approach is working before you even read the SSIM.
"""
import argparse
import collections
import json
import os

import numpy as np

from config import Config
import io_geo
import preprocessing as pp
from region_select import tile, select_regions
from matchers import build_matcher
import block_register as br
import warp as wp
import metrics as me


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--gec", required=True, help="raw GEC GeoTIFF (the input to fix)")
    ap.add_argument("--ref", required=True, help="reference: gold SAR or WV EO GeoTIFF")
    ap.add_argument("--gold", help="hand-aligned gold for scoring (defaults to --ref if it IS gold)")
    ap.add_argument("--reference", default="gold", choices=["gold", "wv"])
    ap.add_argument("--matcher", default="roma", choices=["roma", "xoftr"])
    ap.add_argument("--warp", default="global_affine", choices=["global_affine", "tps"])
    ap.add_argument("--common-gsd", type=float, default=0.5)
    ap.add_argument("--conf-thresh", type=float, default=0.20)
    ap.add_argument("--no-region-filter", action="store_true")
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--out", default="out")
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    cfg = Config(device=args.device, matcher=args.matcher, reference=args.reference,
                 conf_thresh=args.conf_thresh, common_gsd=args.common_gsd)
    cfg.warp.model = args.warp
    if args.no_region_filter:
        cfg.region.use_region_filter = False
    is_sar_ref = (args.reference == "gold")

    # 1. co-locate
    print("[grid] co-locating GEC + reference on a common 4326 grid")
    gec, ref, transform, crs = io_geo.read_on_common_grid(args.gec, args.ref, cfg.common_gsd)
    print(f"       grid {gec.shape}")

    # 2. preprocess
    gec_rgb = pp.preprocess_sar(gec, cfg.preproc)
    ref_rgb = pp.preprocess_reference(ref, is_sar_ref, cfg.preproc)
    gec_gray = gec_rgb[..., 0]

    # 3. tile + region select
    blocks = tile(gec.shape, cfg.grid)
    blocks = select_regions(gec_gray, blocks, cfg.region, cfg.preproc.lee_size)
    kept = [b for b in blocks if b.keep]
    print(f"[grid] {len(blocks)} blocks, {len(kept)} kept after region filter")

    # 4. per-block match + gates
    matcher = build_matcher(cfg)
    results = []
    for i, b in enumerate(kept):
        r = br.register_block(b, gec_rgb, ref_rgb, matcher, cfg.conf_thresh, cfg.gate)
        results.append(r)
        if (i + 1) % 10 == 0:
            print(f"       matched {i+1}/{len(kept)} blocks")

    # 5. consensus filter
    results = br.consensus_filter(results, cfg.gate)

    # 6. pool -> warp
    src, dst, conf = br.pool(results)
    print(f"[pool] {len(src)} clean correspondences from "
          f"{sum(1 for r in results if r.model!='drop')} contributing blocks")
    if len(src) < 6:
        print("[FAIL] too few pooled correspondences to fit a transform. "
              "Inspect report.json fallback reasons.")
        _report(args.out, results, None, None)
        return

    warped, winfo = wp.apply_warp(gec, src, dst, gec.shape, cfg.warp)
    if warped is None:
        print(f"[FAIL] warp failed: {winfo}")
        _report(args.out, results, winfo, None)
        return

    # 7. write georeferenced output
    out_tif = os.path.join(args.out, "gec_registered.tif")
    try:
        io_geo.write_geotiff(out_tif, warped.astype(np.float32), transform, crs)
        print(f"[out]  wrote {out_tif}")
    except Exception as e:
        print(f"[out]  GeoTIFF write skipped ({e}); saving npy instead")
        np.save(os.path.join(args.out, "gec_registered.npy"), warped)

    # 8. score vs gold
    gold = ref if is_sar_ref else None
    if args.gold:
        gold, _, _, _ = io_geo.read_on_common_grid(args.gec, args.gold, cfg.common_gsd)
    cmp = me.compare(gec, warped, gold, cfg.preproc.lee_size) if gold is not None else None
    if cmp:
        print(f"[score] SSIM {cmp['raw']['ssim']:.3f} -> {cmp['warped']['ssim']:.3f} "
              f"(d {cmp['d_ssim']:+.3f}) | NCC {cmp['raw']['ncc']:.3f} -> "
              f"{cmp['warped']['ncc']:.3f} (d {cmp['d_ncc']:+.3f}) | "
              f"{'IMPROVED' if cmp['improved'] else 'no improvement'}")

    _report(args.out, results, winfo, cmp)
    print(f"[done] report in {args.out}/report.json")


def _report(out_dir, results, winfo, cmp):
    reasons = collections.Counter(r.reason for r in results)
    models = collections.Counter(r.model for r in results)
    report = {
        "n_blocks": len(results),
        "block_models": dict(models),
        "fallback_reasons": dict(reasons),
        "warp": winfo,
        "score": cmp,
        "blocks": [dict(r0=r.r0, c0=r.c0, model=r.model, reason=r.reason,
                        n_inliers=r.n_inliers, disp=[float(r.disp[0]), float(r.disp[1])])
                   for r in results],
    }
    with open(os.path.join(out_dir, "report.json"), "w") as f:
        json.dump(report, f, indent=2)


if __name__ == "__main__":
    main()
