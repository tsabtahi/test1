#!/usr/bin/env python3
"""
SAR REGISTRATION METRICS  —  gold vs GEC vs RPC-ellipsoid  (per-crop windowed reproject)
========================================================================================
Compares two SAR registration baselines against a hand-aligned gold reference:

  gold  = hand-aligned SAR  (ground truth)
  GEC   = raw product       (baseline 0)
  RPC   = RPC ellipsoidal ortho (baseline 1)   <-- now the ellipsoid product

Metrics: SSIM and NCC, computed gold<->GEC and gold<->RPC.

Method: NO full-scene reprojection. For each random crop window, each source is
read + reprojected to a common 0.3m grid ON THE FLY (windowed gdal.Warp into
memory), Lee-despeckled (5x5), then scored. Fast, parallel, no scratch space.

Also produces visualization panels: 10 random crops per scene showing
WV (RGB) · gold · GEC · RPC, at 768px, in both raw and despeckled versions.

Scene matching: folder name (scene-ID) is identical across all directories.

Directories (override via env or args):
  GOLD : .../eo_sar_umbra_subset_HH_unique_v2_aligned_92_pa/SAR/<scene>/*_GEC.tif
  GEC  : .../eo_sar_umbra_subset_HH_unique_v2/SAR/<scene>/*_GEC.tif
  RPC  : .../eo_sar_umbra_subset_HH_unique_v2_rpc_ellip/SAR_RPC_ellip/<scene>/*.tif
  WV   : .../eo_sar_umbra_subset_HH_unique_v2/wv_dailytake_output/<scene>/mosaic/*.tif

Usage:
  python3 sar_metrics.py
  python3 sar_metrics.py --workers 8 --metric-crops 30 --vis-crops 10
  python3 sar_metrics.py --out /path/to/results
"""

import os, sys, math, time, argparse, csv, random
import multiprocessing as mp
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
from osgeo import gdal
gdal.UseExceptions()

from scipy.ndimage import uniform_filter
from skimage.metrics import structural_similarity as ssim

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ── DEFAULT PATHS ────────────────────────────────────────────────────────────
BASE = "/home/kashley/satlock/mosaic_datasets"
DEF_GOLD = f"{BASE}/eo_sar_umbra_subset_HH_unique_v2_aligned_92_pa/SAR"
DEF_GEC  = f"{BASE}/eo_sar_umbra_subset_HH_unique_v2/SAR"
DEF_RPC  = f"{BASE}/eo_sar_umbra_subset_HH_unique_v2_rpc_ellip/SAR_RPC_ellip"
DEF_WV   = f"{BASE}/eo_sar_umbra_subset_HH_unique_v2/wv_dailytake_output"
DEF_OUT  = f"{BASE}/eo_sar_umbra_subset_HH_unique_v2_rpc_ellip_metrics"

# ── PARAMETERS ───────────────────────────────────────────────────────────────
TARGET_RES   = 0.000002695     # ~0.3 m in degrees (EPSG:4326)
METRIC_PX    = 512             # metric crop size
VIS_PX       = 768             # visualization crop size
LEE_SIZE     = 5               # Lee filter window
N_METRIC     = 30             # metric crops per scene
N_VIS        = 10              # visualization crops per scene
MIN_VAR      = 30.0            # min variance (despeckled) to accept a crop
MIN_EDGE     = 0.02            # min edge-density to accept a crop
MAX_NODATA   = 0.20            # max nodata fraction to accept a crop
SEED         = 42


# ============================================================================
# LEE FILTER
# ============================================================================

def lee_filter(img: np.ndarray, size: int = 5) -> np.ndarray:
    """Standard adaptive Lee speckle filter."""
    img = img.astype(np.float32)
    mean   = uniform_filter(img, size)
    sqmean = uniform_filter(img**2, size)
    var    = sqmean - mean**2
    overall_var = np.var(img)
    weights = var / (var + overall_var + 1e-8)
    return mean + weights * (img - mean)


# ============================================================================
# WINDOWED REPROJECT  (gdal.Warp into memory, no scratch file)
# ============================================================================

def warp_window(src_path: str,
                lon0: float, lat0: float, lon1: float, lat1: float,
                out_px: int, rgb: bool = False) -> Optional[np.ndarray]:
    """
    Reproject just the [lon0,lat0,lon1,lat1] window of src to a 0.3m grid,
    output exactly out_px x out_px. Returns float32 HxW (or HxWx3 if rgb).
    Done fully in-memory via GDAL /vsimem. None if window is empty.
    """
    # target extent (snap so all sources share the SAME grid for this crop)
    te = [lon0, lat0, lon1, lat1]
    try:
        opts = gdal.WarpOptions(
            format="MEM",
            outputBounds=te,
            width=out_px, height=out_px,
            dstSRS="EPSG:4326",
            resampleAlg="bilinear",
            srcNodata=0, dstNodata=0,
        )
        ds = gdal.Warp("", src_path, options=opts)
        if ds is None:
            return None
        if rgb:
            n = min(3, ds.RasterCount)
            arr = np.dstack([ds.GetRasterBand(b+1).ReadAsArray()
                             for b in range(n)]).astype(np.float32)
        else:
            arr = ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
        ds = None
        return arr
    except Exception:
        return None


# ============================================================================
# CROP QUALITY
# ============================================================================

def edge_density(img: np.ndarray) -> float:
    gx = np.abs(np.diff(img, axis=1, prepend=img[:, :1]))
    gy = np.abs(np.diff(img, axis=0, prepend=img[:1, :]))
    g  = gx + gy
    thr = np.percentile(g, 90)
    return float(np.mean(g > thr)) if thr > 0 else 0.0


def crop_is_good(gold: np.ndarray) -> bool:
    """Reject structureless / mostly-nodata crops (judged on gold)."""
    nod = np.mean(gold <= 0)
    if nod > MAX_NODATA:
        return False
    valid = gold[gold > 0]
    if valid.size < gold.size * 0.5:
        return False
    if np.var(valid) < MIN_VAR:
        return False
    if edge_density(gold) < MIN_EDGE:
        return False
    return True


# ============================================================================
# METRICS
# ============================================================================

def ncc(a: np.ndarray, b: np.ndarray, mask: np.ndarray) -> float:
    """Normalized cross-correlation over valid pixels."""
    av = a[mask]; bv = b[mask]
    if av.size < 50:
        return float("nan")
    av = av - av.mean(); bv = bv - bv.mean()
    denom = np.sqrt((av**2).sum() * (bv**2).sum())
    return float((av * bv).sum() / denom) if denom > 0 else float("nan")


def compute_pair(gold: np.ndarray, other: np.ndarray) -> Tuple[float, float]:
    """SSIM + NCC between gold and other (both despeckled), over shared valid mask."""
    mask = (gold > 0) & (other > 0)
    if mask.sum() < gold.size * 0.4:
        return float("nan"), float("nan")
    # SSIM needs full arrays; zero-out invalid so they don't dominate
    g = np.where(mask, gold, 0.0)
    o = np.where(mask, other, 0.0)
    rng = max(g.max(), o.max()) - min(g.min(), o.min())
    if rng <= 0:
        return float("nan"), float("nan")
    s = ssim(g, o, data_range=rng)
    n = ncc(gold, other, mask)
    return float(s), float(n)


# ============================================================================
# FILE DISCOVERY
# ============================================================================

def find_one(folder: Path, patterns: List[str]) -> Optional[Path]:
    if not folder.exists():
        return None
    for pat in patterns:
        hits = sorted(folder.glob(pat))
        hits = [h for h in hits if "dem" not in h.name.lower()]
        if hits:
            return hits[0]
    return None


def match_scenes(gold_dir, gec_dir, rpc_dir, wv_dir) -> List[dict]:
    """Match by scene-ID folder name. Returns list of dicts with available paths."""
    out = []
    for scene_folder in sorted(Path(gold_dir).iterdir()):
        if not scene_folder.is_dir():
            continue
        sid  = scene_folder.name
        gold = find_one(scene_folder,                 ["*_GEC.tif", "*.tif"])
        gec  = find_one(Path(gec_dir) / sid,          ["*_GEC.tif", "*.tif"])
        # RPC-ellipsoid filenames vary; try ellip-specific patterns first, then
        # fall back to the older rpc names and finally any .tif (DEMs excluded above).
        rpc  = find_one(Path(rpc_dir) / sid,          ["*_GEC_ellip.tif", "*_ellip.tif",
                                                       "*_GEC_rpc.tif", "*_rpc.tif", "*.tif"])
        wv   = find_one(Path(wv_dir) / sid / "mosaic",["*.tif"])
        out.append({"sid": sid, "gold": gold, "gec": gec, "rpc": rpc, "wv": wv})
    return out


# ============================================================================
# GEO HELPERS
# ============================================================================

def raster_bounds(path: str) -> Tuple[float,float,float,float]:
    ds = gdal.Open(path)
    gt = ds.GetGeoTransform()
    W, H = ds.RasterXSize, ds.RasterYSize
    xs = [gt[0], gt[0] + gt[1]*W + gt[2]*H]
    ys = [gt[3], gt[3] + gt[4]*W + gt[5]*H]
    ds = None
    return min(xs), min(ys), max(xs), max(ys)


def common_bounds(paths: List[str]) -> Optional[Tuple]:
    bs = [raster_bounds(p) for p in paths if p]
    if not bs:
        return None
    return (max(b[0] for b in bs), max(b[1] for b in bs),
            min(b[2] for b in bs), min(b[3] for b in bs))


# ============================================================================
# PER-SCENE PROCESSING
# ============================================================================

def process_scene(args_tuple) -> dict:
    rec, params, out_dir = args_tuple
    sid  = rec["sid"]
    gold, gec, rpc, wv = rec["gold"], rec["gec"], rec["rpc"], rec["wv"]

    result = {"sid": sid, "crops": [], "vis": 0,
              "status": "OK", "n_valid": 0}

    if not (gold and gec and rpc):
        miss = [k for k in ("gold","gec","rpc") if not rec[k]]
        result["status"] = f"SKIP:missing_{'+'.join(miss)}"
        return result

    gold_s, gec_s, rpc_s = str(gold), str(gec), str(rpc)

    # Common geographic window across the 3 SAR products
    cb = common_bounds([gold_s, gec_s, rpc_s])
    if cb is None or cb[0] >= cb[2] or cb[1] >= cb[3]:
        result["status"] = "SKIP:no_overlap"
        return result
    left, bottom, right, top = cb

    # crop span in degrees at target res
    span_m = params["metric_px"] * TARGET_RES
    span_v = params["vis_px"]    * TARGET_RES

    rng = random.Random(params["seed"] + hash(sid) % 100000)

    print(f"  [start] {sid[:38]:<38} pid={os.getpid()}", flush=True)

    # ── METRIC CROPS ──────────────────────────────────────────────────────
    attempts = 0
    while len(result["crops"]) < params["n_metric"] and attempts < params["n_metric"]*15:
        attempts += 1
        # heartbeat so slow / low-yield scenes don't look hung
        if attempts % 100 == 0:
            print(f"    ... {sid[:30]:<30} {len(result['crops'])}/{params['n_metric']} "
                  f"crops  ({attempts} tries)", flush=True)
        if right-left-span_m <= 0 or top-bottom-span_m <= 0:
            break
        lon0 = rng.uniform(left, right - span_m)
        lat0 = rng.uniform(bottom, top - span_m)
        lon1, lat1 = lon0 + span_m, lat0 + span_m

        g = warp_window(gold_s, lon0, lat0, lon1, lat1, params["metric_px"])
        if g is None or not crop_is_good(g):
            continue
        e = warp_window(gec_s, lon0, lat0, lon1, lat1, params["metric_px"])
        r = warp_window(rpc_s, lon0, lat0, lon1, lat1, params["metric_px"])
        if e is None or r is None:
            continue

        # Despeckle all three identically
        gd = lee_filter(g, params["lee"])
        ed = lee_filter(e, params["lee"])
        rd = lee_filter(r, params["lee"])

        ssim_gec, ncc_gec = compute_pair(gd, ed)
        ssim_rpc, ncc_rpc = compute_pair(gd, rd)
        if any(math.isnan(x) for x in (ssim_gec, ssim_rpc, ncc_gec, ncc_rpc)):
            continue

        result["crops"].append({
            "lon": lon0, "lat": lat0,
            "ssim_gec": ssim_gec, "ssim_rpc": ssim_rpc,
            "ncc_gec": ncc_gec,   "ncc_rpc": ncc_rpc,
        })

    result["n_valid"] = len(result["crops"])

    # ── VISUALIZATION CROPS ───────────────────────────────────────────────
    vis_dir = out_dir / "vis" / sid
    vis_dir.mkdir(parents=True, exist_ok=True)
    made = 0
    attempts = 0
    while made < params["n_vis"] and attempts < params["n_vis"]*15:
        attempts += 1
        if right-left-span_v <= 0 or top-bottom-span_v <= 0:
            break
        lon0 = rng.uniform(left, right - span_v)
        lat0 = rng.uniform(bottom, top - span_v)
        lon1, lat1 = lon0 + span_v, lat0 + span_v

        g = warp_window(gold_s, lon0, lat0, lon1, lat1, params["vis_px"])
        if g is None or not crop_is_good(g):
            continue
        e = warp_window(gec_s, lon0, lat0, lon1, lat1, params["vis_px"])
        r = warp_window(rpc_s, lon0, lat0, lon1, lat1, params["vis_px"])
        w = warp_window(wv,  lon0, lat0, lon1, lat1, params["vis_px"], rgb=True) if wv else None
        if e is None or r is None:
            continue

        made += 1
        _render_vis(sid, made, w, g, e, r, params["lee"], vis_dir)

    result["vis"] = made
    return result


def _stretch(a):
    a = np.log1p(np.clip(a, 0, None))
    v = a[a > 0]
    if not v.size:
        return np.zeros_like(a)
    lo, hi = np.percentile(v, (2, 98))
    if hi <= lo: hi = lo + 1e-6
    return np.clip((a-lo)/(hi-lo), 0, 1)


def _stretch_rgb(a):
    out = np.zeros_like(a, dtype=np.float32)
    for b in range(a.shape[2]):
        band = a[:, :, b]; v = band[band > 0]
        if v.size:
            lo, hi = np.percentile(v, (2, 98))
            out[:, :, b] = np.clip((band-lo)/max(hi-lo,1e-6), 0, 1)
    return out


def _render_vis(sid, idx, wv, gold, gec, rpc, lee, out_dir):
    """2 rows (raw / despeckled) x 4 cols (WV gold GEC RPC)."""
    fig, axes = plt.subplots(2, 4, figsize=(14, 7.2))
    titles = ["WorldView (EO)", "Gold (aligned)", "GEC original", "RPC (ellipsoid)"]

    # Row 0: raw
    for col, (img, t) in enumerate(zip([wv, gold, gec, rpc], titles)):
        ax = axes[0, col]
        if img is None:
            ax.set_facecolor("#111")
            ax.text(.5,.5,"no data",color="#888",ha="center",va="center",
                    transform=ax.transAxes)
        elif col == 0:
            ax.imshow(_stretch_rgb(img), interpolation="nearest")
        else:
            ax.imshow(_stretch(img), cmap="gray", vmin=0, vmax=1,
                      interpolation="nearest")
        ax.set_title(t, fontsize=9,
                     color="darkgreen" if col==0 else
                           ("crimson" if col==1 else "#111"))
        ax.set_xticks([]); ax.set_yticks([])
        if col == 0: ax.set_ylabel("raw", fontsize=10)

    # Row 1: despeckled (WV not despeckled — optical)
    for col, img in enumerate([wv, gold, gec, rpc]):
        ax = axes[1, col]
        if img is None:
            ax.set_facecolor("#111")
        elif col == 0:
            ax.imshow(_stretch_rgb(img), interpolation="nearest")
        else:
            ax.imshow(_stretch(lee_filter(img, lee)), cmap="gray",
                      vmin=0, vmax=1, interpolation="nearest")
        ax.set_xticks([]); ax.set_yticks([])
        if col == 0: ax.set_ylabel("despeckled", fontsize=10)

    fig.suptitle(f"{sid}   crop {idx}", fontsize=11)
    fig.tight_layout(pad=0.4)
    fig.savefig(out_dir / f"crop_{idx:02d}.png", dpi=110,
                bbox_inches="tight", facecolor="white")
    plt.close(fig)


# ============================================================================
# MAIN
# ============================================================================

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gold", default=DEF_GOLD)
    ap.add_argument("--gec",  default=DEF_GEC)
    ap.add_argument("--rpc",  default=DEF_RPC)
    ap.add_argument("--wv",   default=DEF_WV)
    ap.add_argument("--out",  default=DEF_OUT)
    ap.add_argument("--workers",      type=int, default=max(mp.cpu_count()//2, 1))
    ap.add_argument("--metric-crops", type=int, default=N_METRIC)
    ap.add_argument("--vis-crops",    type=int, default=N_VIS)
    ap.add_argument("--lee",          type=int, default=LEE_SIZE)
    ap.add_argument("--seed",         type=int, default=SEED)
    args = ap.parse_args()

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    print("="*66)
    print("  SAR REGISTRATION METRICS — gold vs GEC vs RPC-ellipsoid")
    print("="*66)
    print(f"  gold : {args.gold}")
    print(f"  gec  : {args.gec}")
    print(f"  rpc  : {args.rpc}")
    print(f"  wv   : {args.wv}")
    print(f"  out  : {out_dir}")
    print(f"  workers={args.workers}  metric_crops={args.metric_crops}  "
          f"vis_crops={args.vis_crops}  lee={args.lee}x{args.lee}")

    scenes = match_scenes(args.gold, args.gec, args.rpc, args.wv)
    matched = [s for s in scenes if s["gold"] and s["gec"] and s["rpc"]]
    print(f"\n  {len(scenes)} gold scenes, {len(matched)} with GEC+RPC present")
    missing = [s["sid"] for s in scenes if not (s["gec"] and s["rpc"])]
    if missing:
        print(f"  Missing GEC/RPC ({len(missing)}): "
              f"{', '.join(missing[:5])}{' ...' if len(missing)>5 else ''}")

    params = {"metric_px": METRIC_PX, "vis_px": VIS_PX,
              "n_metric": args.metric_crops, "n_vis": args.vis_crops,
              "lee": args.lee, "seed": args.seed}

    t0 = time.perf_counter()
    work = [(rec, params, out_dir) for rec in scenes]

    print(f"\n  launching {len(work)} scenes across {args.workers} workers ...\n", flush=True)

    results = []
    if args.workers > 1:
        with mp.Pool(args.workers) as pool:
            for i, r in enumerate(pool.imap_unordered(process_scene, work), 1):
                results.append(r)
                print(f"  [done {i}/{len(work)}] {r['sid']:<42} "
                      f"{r['status']}  crops={r['n_valid']}  vis={r['vis']}", flush=True)
    else:
        for i, w in enumerate(work, 1):
            r = process_scene(w)
            results.append(r)
            print(f"  [done {i}/{len(work)}] {r['sid']:<42} "
                  f"{r['status']}  crops={r['n_valid']}  vis={r['vis']}", flush=True)

    # ── WRITE PER-CROP CSV ────────────────────────────────────────────────
    crop_csv = out_dir / "crops.csv"
    with open(crop_csv, "w", newline="") as f:
        wcsv = csv.writer(f)
        wcsv.writerow(["scene","lon","lat",
                       "ssim_gec","ssim_rpc","ncc_gec","ncc_rpc"])
        for r in results:
            for c in r["crops"]:
                wcsv.writerow([r["sid"], f"{c['lon']:.6f}", f"{c['lat']:.6f}",
                               f"{c['ssim_gec']:.4f}", f"{c['ssim_rpc']:.4f}",
                               f"{c['ncc_gec']:.4f}", f"{c['ncc_rpc']:.4f}"])

    # ── PER-SCENE + OVERALL SUMMARY ───────────────────────────────────────
    scene_csv = out_dir / "scene_summary.csv"
    all_sg, all_sr, all_ng, all_nr = [], [], [], []
    with open(scene_csv, "w", newline="") as f:
        wcsv = csv.writer(f)
        wcsv.writerow(["scene","n_crops",
                       "ssim_gec_med","ssim_rpc_med","ssim_delta",
                       "ncc_gec_med","ncc_rpc_med","ncc_delta"])
        for r in results:
            if not r["crops"]:
                continue
            sg = np.median([c["ssim_gec"] for c in r["crops"]])
            sr = np.median([c["ssim_rpc"] for c in r["crops"]])
            ng = np.median([c["ncc_gec"]  for c in r["crops"]])
            nr = np.median([c["ncc_rpc"]  for c in r["crops"]])
            all_sg.append(sg); all_sr.append(sr); all_ng.append(ng); all_nr.append(nr)
            wcsv.writerow([r["sid"], r["n_valid"],
                           f"{sg:.4f}", f"{sr:.4f}", f"{sr-sg:+.4f}",
                           f"{ng:.4f}", f"{nr:.4f}", f"{nr-ng:+.4f}"])

    dt = time.perf_counter() - t0
    print("\n" + "="*66)
    print("  OVERALL  (median across scenes)")
    print("="*66)
    if all_sg:
        print(f"  SSIM   GEC: {np.median(all_sg):.4f}   "
              f"RPC: {np.median(all_sr):.4f}   "
              f"delta: {np.median(all_sr)-np.median(all_sg):+.4f}")
        print(f"  NCC    GEC: {np.median(all_ng):.4f}   "
              f"RPC: {np.median(all_nr):.4f}   "
              f"delta: {np.median(all_nr)-np.median(all_ng):+.4f}")
        better_ssim = sum(1 for a,b in zip(all_sg,all_sr) if b>a)
        better_ncc  = sum(1 for a,b in zip(all_ng,all_nr) if b>a)
        print(f"  RPC > GEC on SSIM in {better_ssim}/{len(all_sg)} scenes")
        print(f"  RPC > GEC on NCC  in {better_ncc}/{len(all_ng)} scenes")
    else:
        print("  No valid crops produced.")
    print("="*66)
    print(f"  Per-crop CSV   : {crop_csv}")
    print(f"  Per-scene CSV  : {scene_csv}")
    print(f"  Vis panels     : {out_dir/'vis'}/<scene>/crop_NN.png")
    print(f"  Done in {dt/60:.1f} min")


if __name__ == "__main__":
    main()
