# CPHD ship detector: training (2026-10-12)

Two trainers on the same crops, labels, sampler and geo evaluation:
- `train_raw.py`: **raw phase history in, no image formation** (current direction, see below).
- `train_detector.py`: imager baseline (differentiable backprojection, then RetinaNet). Kept as a reference.

## Raw phase-history model (`train_raw.py`)
```
CPHD crop 1024 x 1024 complex
 -> 4 channels: real, imag (crop RMS = 1), ground wavenumbers kE, kN per sample
 -> ViT encoder: 32 x 32 patches = 1024 tokens (384-d, 12 layers), + look-direction embedding
 -> decoder: one fixed query per 4 m ground cell (128 x 128 = 512 m), cross-attention to the tokens
 -> conv head per cell: heat, centre offset, log width / height
 -> heat peaks -> boxes in crop metres -> lat/lon
```
Losses (no matching, all differentiable): penalty-reduced focal heat loss (Gaussian targets, cut ships weighted 0),
L1 offset, 0.1 x L1 log size, 1 x GIoU at ship-centre cells. Skew: focal loss + 50% positive crops per batch.
Augmentation: crop centre moved up to 64 m by an exact phase ramp on the data.
```
torchrun --nproc_per_node=4 train_raw.py train --crops /crops --ann-root /ann --out /runs/raw1 --amp
python train_raw.py predict --ckpt /runs/raw1/best.pt --crops /crops --out /runs/raw1/pred.geojson
python train_raw.py selftest
```
Verified (CPU, synthetic): moving the reference point by a phase ramp keeps the ground in place (correlation 0.993);
targets decode back to the boxes exactly; gradients reach the patch embedding; training, checkpoints, predict, GeoJSON work.
Open: in a 300-step CPU overfit run the box terms fell but the heat loss barely moved (AP30 0.01 vs 0.10 for the
imager model on a similar budget). Localising from k-space is the hard part; see the longer run notes.


`train_detector.py` trains a ship detector directly on the CPHD crops from `build_crops.py`.
`Dockerfile` builds one GPU image (`cphd-gpu`) holding both scripts.

## Model
1. **Imager** (torch, differentiable): backprojects each 1024 x 1024 crop onto a lat/lon grid (default 512 px at 1 m),
   with a learnable taper over pulses and samples. Output: 2 sub-apertures (first / second half of the pulses) and their sum.
2. **Features**: 3 channels, full-aperture dB, sub-aperture 1 dB, sub-aperture 2 dB (relative to the crop median).
   Sub-apertures show movers and ambiguities differently from the full aperture.
3. **Detector**: torchvision RetinaNet, ResNet-50 FPN (ImageNet weights), focal loss, GIoU box loss.
   Anchors 16-406 px with aspect ratios 0.2-5 for long ships.
4. **Geo out**: pixel boxes map exactly to lat/lon through the grid. Overlapping crops are merged per scene by NMS in metres.

## Labels and loss
- Boxes come from each scene's `annotations.json` (lat/lon), placed on the training grid after a random shift of up to
  64 m. Pixels are square in metres, so the box loss is a loss in metres between predicted and annotated geo boxes.
- Boxes with < 30% visible are ignored: anchors matched to them count as neither ship nor background.
- Skew: focal loss, plus a sampler drawing 50% positive crops per batch (`--pos-frac`). Negatives stay in training.
- Validation: held-out scenes (20% by default, `--val-scenes` to choose). Reports AP at IoU 0.3 and 0.5, precision,
  recall, false alarms per km2, centre error in metres, share of empty crops with a detection.

## Run
```
docker build -t cphd-gpu .
# training, 4 GPUs (see the Dockerfile header for the full docker run line)
torchrun --nproc_per_node=4 train_detector.py train --crops /crops --ann-root /ann --out /runs/r1
# first check the pipeline can memorise the data
python train_detector.py train --crops /crops --ann-root /ann --out /runs/overfit --overfit --epochs 20
# detections as GeoJSON (with metrics if --ann-root is given)
python train_detector.py predict --ckpt /runs/r1/best.pt --crops /crops --ann-root /ann --out /runs/r1/pred.geojson
python train_detector.py selftest
```
Run folder: `config.json`, `metrics.jsonl` (losses and eval), `last.pt`, `best.pt` (best AP30), `val_detections.geojson`.

Useful options: `--batch` (crops per GPU, default 4), `--chunk-elems` (lower if GPU memory runs out), `--amp`,
`--fixed-taper` (faster: no gradient through the imager), `--image-px` / `--pixel-m`, `--backbone resnet18`.

## Crop builder on several GPUs
`build_crops.py ... --gpus 0,1,2,3` starts one process per GPU (CuPy), shares the scenes out by CPHD size, and writes
one `manifest.jsonl` at the end; logs in `<out>/_logs/`. `--procs N` does the same on CPU.

## Verified (CPU, synthetic scenes with 60 m line-shaped ships)
- Torch imager vs the numpy backprojection: correlation 1.0000.
- Training runs, gradients reach the imager taper; 2-process DDP run completes and writes checkpoints.
- Overfit check, 150 steps from random weights at 128 px / 4 m: AP30 0 -> 0.10, top detections on the annotated ships.
- Evaluation, checkpoints, `predict` and GeoJSON output work.
- GPU resampler in the crop builder matches the CPU one (0.99999); two-process sharded crop run gives one manifest.

## Not verified
- No GPU here: CUDA, CuPy, the Docker image, real training speed (CPU: 0.65 crops/s at 128 px).
- Real Umbra crops and labels; whether ImageNet weights help on SAR dB images.
