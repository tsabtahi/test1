#!/usr/bin/env python3
"""Ship detector that reads the CPHD phase history directly (no image formation), geo boxes out.

    CPHD crop, 1024 pulses x 1024 frequency samples, complex
      -> 4 channels: real, imag (scaled by the crop RMS), and the ground wavenumbers kE, kN of every sample
         (where each sample sits in k-space on the ground; this ties the array to ground geometry for any scene)
      -> ViT encoder: 32 x 32 patches = 1024 tokens (each patch is a short sub-aperture x sub-band), plus a token-wide
         embedding of the look direction
      -> decoder with one fixed query per ground cell (default 128 x 128 cells of 4 m = the 512 m crop); each query
         carries its cell's east/north position and cross-attends to the tokens
      -> small conv head on the cell grid: heat (ship centre here), offset (centre inside the cell), log size (m)
      -> peaks of the heat map -> boxes in crop-local metres -> lat/lon (exact, from the crop centre)

Losses (CenterNet style, no matching step; every term is differentiable):
    heat   penalty-reduced focal loss against a Gaussian around each ship centre; cells of cut ships get zero weight
    offset L1 at ship-centre cells (cells)
    size   L1 on log width / log height (m) at ship-centre cells, weight 0.1
    giou   generalised IoU of the decoded box at ship-centre cells, weight 1 (set --giou-weight 0 to drop)

Augmentation: the crop centre is moved by up to --shift-m metres by an exact phase ramp on the data (re-referencing),
so labels and data stay consistent. Skew: focal loss plus the same balanced sampler as train_detector.py.

    python train_raw.py train --crops /crops --ann-root /ann --out runs/raw1
    torchrun --nproc_per_node=4 train_raw.py train ...
    python train_raw.py predict --ckpt runs/raw1/best.pt --crops /crops --out preds.geojson
    python train_raw.py selftest
"""
import argparse, json, math, os, random, sys, time
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.distributed as dist

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import train_detector as td                                           # data reading, sampler, metrics, GeoJSON

C = 299792458.0


# ------------------------------------------------------------------ targets
def gaussian_radius(h, w, min_overlap=0.7):
    """CenterNet radius (cells) so a box shifted by it still overlaps the truth by min_overlap."""
    a1, b1, c1 = 1, h + w, w * h * (1 - min_overlap) / (1 + min_overlap)
    r1 = (b1 + math.sqrt(b1 ** 2 - 4 * a1 * c1)) / 2
    a2, b2, c2 = 4, 2 * (h + w), (1 - min_overlap) * w * h
    r2 = (b2 + math.sqrt(b2 ** 2 - 4 * a2 * c2)) / 2
    a3, b3, c3 = 4 * min_overlap, -2 * min_overlap * (h + w), (min_overlap - 1) * w * h
    r3 = (b3 + math.sqrt(b3 ** 2 - 4 * a3 * c3)) / 2
    return max(0.0, min(r1, r2, r3))


def build_targets(boxes, ignore, cells, cell_m, max_objs):
    """boxes (K,4) crop-local metres [e0, n0, e1, n1] (already clipped). Row 0 is the north edge."""
    H = cells * cell_m / 2
    heat = np.zeros((cells, cells), np.float32)
    ign = np.zeros((cells, cells), np.float32)
    idx = np.zeros(max_objs, np.int64); off = np.zeros((max_objs, 2), np.float32)
    size = np.zeros((max_objs, 2), np.float32); box = np.zeros((max_objs, 4), np.float32)
    mask = np.zeros(max_objs, np.float32)
    ys, xs = np.mgrid[0:cells, 0:cells]
    k = 0
    for b, ig in zip(boxes, ignore):
        e0, n0, e1, n1 = b
        c0, c1 = int(np.floor((e0 + H) / cell_m)), int(np.ceil((e1 + H) / cell_m))
        r0, r1 = int(np.floor((H - n1) / cell_m)), int(np.ceil((H - n0) / cell_m))
        if ig:
            ign[max(r0, 0):min(r1, cells), max(c0, 0):min(c1, cells)] = 1
            continue
        u, v = (0.5 * (e0 + e1) + H) / cell_m, (H - 0.5 * (n0 + n1)) / cell_m
        iu, iv = min(int(u), cells - 1), min(int(v), cells - 1)
        w_c, h_c = (e1 - e0) / cell_m, (n1 - n0) / cell_m
        sig = (2 * max(0, int(gaussian_radius(h_c, w_c))) + 1) / 6
        heat = np.maximum(heat, np.exp(-((xs - iu) ** 2 + (ys - iv) ** 2) / (2 * sig * sig)).astype(np.float32))
        heat[iv, iu] = 1.0
        if k < max_objs:
            idx[k] = iv * cells + iu
            off[k] = (u - iu, v - iv)
            size[k] = (math.log(max(e1 - e0, 0.5)), math.log(max(n1 - n0, 0.5)))
            box[k] = b
            mask[k] = 1
            k += 1
    ign[heat > 0] = 0                                                  # never silence a real ship's cells
    return dict(heat=heat, ign=ign, idx=idx, off=off, size=size, box=box, mask=mask)


# ------------------------------------------------------------------ data
class RawSet(torch.utils.data.Dataset):
    def __init__(self, root, entries, anns, cfg, train):
        self.root, self.entries, self.anns, self.cfg, self.train = root, entries, anns, cfg, train
        self.meta = []
        for e in entries:
            with open(os.path.join(root, e["json"])) as f:
                self.meta.append(json.load(f))
        self.positive = np.array([m["label"] == "positive" for m in self.meta])

    def __len__(self):
        return len(self.entries)

    def scene_anns(self, i):
        m = self.meta[i]
        if m["scene"] in self.anns:
            return self.anns[m["scene"]], True
        return [dict(lon_min=b["bbox_geo"][0], lat_min=b["bbox_geo"][1], lon_max=b["bbox_geo"][2], lat_max=b["bbox_geo"][3],
                     iscrowd=0) for b in m["boxes"]], False

    def get(self, i, shift=None):
        m, cfg = self.meta[i], self.cfg
        d = td.read_crop(os.path.join(self.root, self.entries[i]["cphd"]))
        anns, full = self.scene_anns(i)
        lat, lon = m["centre_lat"], m["centre_lon"]
        E, N, U = (td_enu(lat, lon))
        X, tx, rc = d["X"], d["tx"].astype(np.float64), d["rc"].astype(np.float64)
        f = d["f0"][:, None] + np.arange(X.shape[1])[None, :] * d["scss"]
        if shift is None:
            s = cfg["shift_m"] if (self.train and full) else 0.0
            shift = (random.uniform(-s, s), random.uniform(-s, s)) if s > 0 else (0.0, 0.0)
        dx, dy = shift
        if dx or dy:                                                   # move the reference point: exact phase ramp
            D = dx * E + dy * N
            def dr(t):
                return (D @ D - 2 * t @ D) / (np.linalg.norm(t - D, axis=1) + np.linalg.norm(t, axis=1))
            dtau = (dr(tx) + dr(rc)) / C
            X = (X * np.exp((-d["sgn"] * 2j * np.pi) * (f * dtau[:, None]))).astype(np.complex64)
            tx, rc = tx - D, rc - D
            ml, mo = td.m_per_deg(lat)
            lat, lon = lat + dy / ml, lon + dx / mo
        if d["sgn"] > 0:                                               # one sign convention for the network
            X = np.conj(X)
        X = X / max(float(np.sqrt(np.mean(np.abs(X) ** 2))), 1e-12)
        u = 0.5 * (tx + rc)
        u /= np.linalg.norm(u, axis=1, keepdims=True)
        ml, mo = td.m_per_deg(lat)
        Hm = cfg["cells"] * cfg["cell_m"] / 2
        bx, ig = [], []
        for a in anns:
            e0, e1 = (a["lon_min"] - lon) * mo, (a["lon_max"] - lon) * mo
            n0, n1 = (a["lat_min"] - lat) * ml, (a["lat_max"] - lat) * ml
            ce0, ce1, cn0, cn1 = max(e0, -Hm), min(e1, Hm), max(n0, -Hm), min(n1, Hm)
            if ce1 - ce0 < 1 or cn1 - cn0 < 1:
                continue
            vis = (ce1 - ce0) * (cn1 - cn0) / max((e1 - e0) * (n1 - n0), 1e-9)
            bx.append([ce0, cn0, ce1, cn1])
            ig.append(bool(vis < cfg["min_visible"] or a.get("iscrowd", 0)))
        bx = np.array(bx, np.float32).reshape(-1, 4)
        ig = np.array(ig, bool)
        t = build_targets(bx, ig, cfg["cells"], cfg["cell_m"], cfg["max_objs"])
        return dict(X=torch.from_numpy(np.ascontiguousarray(X)), u=torch.from_numpy(u.astype(np.float32)),
                    f0=torch.from_numpy(d["f0"]), scss=torch.tensor(d["scss"], dtype=torch.float64),
                    E=torch.from_numpy(E.astype(np.float32)), N=torch.from_numpy(N.astype(np.float32)),
                    **{k: torch.from_numpy(v) for k, v in t.items()},
                    gt=bx, gt_ignore=ig, lat=lat, lon=lon, crop_id=m["crop_id"], scene=m["scene"],
                    tx=torch.from_numpy(tx.astype(np.float32)), rc=torch.from_numpy(rc.astype(np.float32)))

    def __getitem__(self, i):
        return self.get(i)


def td_enu(lat, lon):
    la, lo = math.radians(lat), math.radians(lon)
    return (np.array([-math.sin(lo), math.cos(lo), 0.0]),
            np.array([-math.sin(la) * math.cos(lo), -math.sin(la) * math.sin(lo), math.cos(la)]),
            np.array([math.cos(la) * math.cos(lo), math.cos(la) * math.sin(lo), math.sin(la)]))


TENSORS = ("X", "u", "f0", "scss", "E", "N", "heat", "ign", "idx", "off", "size", "box", "mask")


def collate(items):
    out = {k: torch.stack([it[k] for it in items]) for k in TENSORS}
    for k in ("gt", "gt_ignore", "lat", "lon", "crop_id", "scene"):
        out[k] = [it[k] for it in items]
    return out


# ------------------------------------------------------------------ model
class CrossBlock(nn.Module):
    def __init__(self, d_mem, d, heads):
        super().__init__()
        self.h = heads
        self.ln_q, self.ln_m = nn.LayerNorm(d), nn.LayerNorm(d_mem)
        self.q, self.kv, self.o = nn.Linear(d, d), nn.Linear(d_mem, 2 * d), nn.Linear(d, d)
        self.ln2 = nn.LayerNorm(d)
        self.mlp = nn.Sequential(nn.Linear(d, 4 * d), nn.GELU(), nn.Linear(4 * d, d))

    def forward(self, q, mem):
        B, Q, D = q.shape
        k, v = self.kv(self.ln_m(mem)).chunk(2, -1)
        sh = lambda x: x.reshape(B, x.shape[1], self.h, D // self.h).transpose(1, 2)
        a = F.scaled_dot_product_attention(sh(self.q(self.ln_q(q))), sh(k), sh(v))
        q = q + self.o(a.transpose(1, 2).reshape(B, Q, D))
        return q + self.mlp(self.ln2(q))


class RawShipNet(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        D, dq, ps, cells = cfg["dim"], cfg["dec_dim"], cfg["patch"], cfg["cells"]
        T = (cfg["pulses"] // ps) * (cfg["samples"] // ps)
        self.patch = nn.Conv2d(4, D, ps, ps)
        self.pos = nn.Parameter(torch.zeros(1, T, D))
        nn.init.trunc_normal_(self.pos, std=0.02)
        self.geo = nn.Sequential(nn.Linear(3, D), nn.GELU(), nn.Linear(D, D))
        layer = nn.TransformerEncoderLayer(D, cfg["heads"], 4 * D, dropout=0.0, activation="gelu", batch_first=True,
                                           norm_first=True)
        self.enc = nn.TransformerEncoder(layer, cfg["depth"], enable_nested_tensor=False)
        self.enc_norm = nn.LayerNorm(D)
        H = cells * cfg["cell_m"] / 2
        c = (torch.arange(cells) + 0.5) * cfg["cell_m"]
        n, e = torch.meshgrid(H - c, c - H, indexing="ij")             # row 0 = north edge
        fr = 2.0 ** torch.arange(8) * math.pi / (2 * H)
        pe = torch.cat([torch.sin(e.reshape(-1, 1) * fr), torch.cos(e.reshape(-1, 1) * fr),
                        torch.sin(n.reshape(-1, 1) * fr), torch.cos(n.reshape(-1, 1) * fr)], 1)
        self.register_buffer("cell_pe", pe, persistent=False)          # (cells^2, 32)
        self.qmlp = nn.Sequential(nn.Linear(pe.shape[1], dq), nn.GELU(), nn.Linear(dq, dq))
        self.qgeo = nn.Linear(D, dq)
        self.dec = nn.ModuleList(CrossBlock(D, dq, cfg["dec_heads"]) for _ in range(cfg["dec_layers"]))
        conv = lambda: nn.Sequential(nn.Conv2d(dq, dq, 3, padding=1), nn.GroupNorm(8, dq), nn.ReLU(inplace=True))
        self.trunk = nn.Sequential(conv(), conv())
        self.heat = nn.Conv2d(dq, 1, 1)
        self.off = nn.Conv2d(dq, 2, 1)
        self.size = nn.Conv2d(dq, 2, 1)
        nn.init.constant_(self.heat.bias, -2.19)
        nn.init.constant_(self.size.bias, math.log(40.0))

    def channels(self, b):
        """real, imag and the ground wavenumbers kE, kN of every sample (scaled to [-1, 1] per crop)."""
        X = b["X"]
        S = X.shape[-1]
        f = b["f0"][:, :, None] + torch.arange(S, device=X.device, dtype=torch.float64)[None, None, :] * b["scss"][:, None, None]
        u = b["u"].double()
        out = [X.real, X.imag]
        for ax in (b["E"], b["N"]):
            k = (2 / C) * f * (u * ax.double()[:, None, :]).sum(-1)[:, :, None]
            k = k - k.mean(dim=(1, 2), keepdim=True)
            out.append((k / k.abs().amax(dim=(1, 2), keepdim=True).clamp(min=1e-12)).float())
        return torch.stack(out, 1)

    def forward(self, b):
        x = self.channels(b)
        B = x.shape[0]
        g = self.geo(b["u"].mean(1))                                   # look direction, includes grazing angle
        ctx = torch.autocast("cuda", dtype=torch.bfloat16) if (self.cfg["amp"] and x.is_cuda) else _null()
        with ctx:
            t = self.patch(x).flatten(2).transpose(1, 2) + self.pos + g[:, None, :]
            mem = self.enc_norm(self.enc(t))
            q = self.qmlp(self.cell_pe)[None].expand(B, -1, -1) + self.qgeo(g)[:, None, :]
            for blk in self.dec:
                q = blk(q, mem)
            cells = self.cfg["cells"]
            y = self.trunk(q.transpose(1, 2).reshape(B, -1, cells, cells))
            return dict(heat=self.heat(y).float(), off=self.off(y).float(), size=self.size(y).float())


class _null:
    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


# ------------------------------------------------------------------ losses
def gather(t, idx):
    """t (B, C, H, W), idx (B, K) flat cell index -> (B, K, C)."""
    B, Cc = t.shape[:2]
    return t.flatten(2).gather(2, idx[:, None, :].expand(B, Cc, idx.shape[1])).transpose(1, 2)


def decode_at(off, size, idx, cells, cell_m):
    H = cells * cell_m / 2
    iu, iv = (idx % cells).float(), (idx // cells).float()
    ce = (iu + off[..., 0]) * cell_m - H
    cn = H - (iv + off[..., 1]) * cell_m
    w, h = torch.exp(size[..., 0]), torch.exp(size[..., 1])
    return torch.stack([ce - w / 2, cn - h / 2, ce + w / 2, cn + h / 2], -1)


def compute_loss(out, b, cfg):
    from torchvision.ops import generalized_box_iou_loss
    p = torch.sigmoid(out["heat"][:, 0]).clamp(1e-4, 1 - 1e-4)
    t, ign = b["heat"], b["ign"]
    pos = (t >= 1.0).float()
    n_pos = pos.sum().clamp(min=1.0)
    l_pos = -(torch.log(p) * (1 - p) ** 2 * pos).sum()
    l_neg = -(torch.log(1 - p) * p ** 2 * (1 - t) ** 4 * (1 - pos) * (1 - ign)).sum()
    heat = (l_pos + l_neg) / n_pos
    m = b["mask"][..., None]
    k = m.sum().clamp(min=1.0)
    off_p, size_p = gather(out["off"], b["idx"]), gather(out["size"], b["idx"])
    off = (torch.abs(off_p - b["off"]) * m).sum() / k
    size = (torch.abs(size_p - b["size"]) * m).sum() / k
    losses = dict(heat=heat, offset=off, size=0.1 * size)
    if cfg["giou_weight"] > 0:
        bp = decode_at(off_p, size_p, b["idx"], cfg["cells"], cfg["cell_m"])
        sel = b["mask"] > 0
        g = generalized_box_iou_loss(bp[sel], b["box"][sel], reduction="sum") / k if sel.any() else heat * 0
        losses["giou"] = cfg["giou_weight"] * g
    return losses


@torch.no_grad()
def decode(out, cfg, k=100, thr=0.05):
    """Peaks of the heat map -> boxes in crop-local metres [e0, n0, e1, n1] and scores, per crop."""
    heat = torch.sigmoid(out["heat"][:, 0])
    peak = heat == F.max_pool2d(heat[:, None], 3, 1, 1)[:, 0]
    sc, idx = (heat * peak).flatten(1).topk(min(k, heat[0].numel()), dim=1)
    boxes = decode_at(gather(out["off"], idx), gather(out["size"], idx), idx, cfg["cells"], cfg["cell_m"])
    res = []
    for s, bx in zip(sc, boxes):
        keep = s >= thr
        res.append((s[keep].cpu().numpy(), bx[keep].cpu().numpy()))
    return res


# ------------------------------------------------------------------ evaluation (same metrics as train_detector.py)
def to_records(dets, b, cfg):
    """Crop-local metres -> boxes on a 1 m lat/lon grid centred on the crop, so train_detector's metrics and GeoJSON apply."""
    Hm = cfg["cells"] * cfg["cell_m"] / 2
    n = int(round(2 * Hm))
    tr = lambda x: np.stack([x[:, 0] + Hm, Hm - x[:, 3], x[:, 2] + Hm, Hm - x[:, 1]], 1) if len(x) else np.zeros((0, 4))
    recs = []
    for (s, bx), gt, ig, lat, lon, cid, scene in zip(dets, b["gt"], b["gt_ignore"], b["lat"], b["lon"], b["crop_id"], b["scene"]):
        recs.append(dict(scores=s, boxes=tr(bx), gt=tr(gt), ignore=ig, grid=td.make_grid(lat, lon, n, 1.0),
                         crop_id=cid, scene=scene))
    return recs


def summarise(records, cfg, score_thr=0.5):
    tp = fp = n_gt = 0
    errs, neg_hit, n_neg = [], 0, 0
    for r in records:
        s, t, n, e = td.match(r, 0.3, score_thr)
        tp += int(t.sum()); fp += int(len(t) - t.sum()); n_gt += n; errs += e
        if n == 0 and not r["ignore"].any():
            n_neg += 1
            neg_hit += int((r["scores"] >= score_thr).any())
    area = len(records) * (cfg["cells"] * cfg["cell_m"] / 1000) ** 2
    return dict(crops=len(records), gt=n_gt, ap30=td.average_precision(records, 0.3), ap50=td.average_precision(records, 0.5),
                precision=tp / max(tp + fp, 1), recall=tp / max(n_gt, 1), false_alarms_per_km2=fp / max(area, 1e-9),
                centre_error_m=float(np.mean(errs)) if errs else float("nan"),
                negative_crops_with_detection=neg_hit / max(n_neg, 1), score_thr=score_thr)


def to_device(b, device):
    out = dict(b)
    for k in TENSORS:
        out[k] = b[k].to(device, non_blocking=True)
    return out


@torch.no_grad()
def evaluate(model, loader, device, cfg, score_thr=0.5):
    core = model.module if hasattr(model, "module") else model
    core.eval()
    records = []
    for b in loader:
        b = to_device(b, device)
        records += to_records(decode(core(b), cfg), b, cfg)
    core.train()
    return summarise(records, cfg, score_thr), records


# ------------------------------------------------------------------ training
def cfg_of(a):
    return dict(cells=a.cells, cell_m=a.cell_m, shift_m=a.shift_m, min_visible=a.min_visible, max_objs=a.max_objs,
                pulses=a.pulses, samples=a.samples, patch=a.patch, dim=a.dim, depth=a.depth, heads=a.heads,
                dec_dim=a.dec_dim, dec_heads=a.dec_heads, dec_layers=a.dec_layers, giou_weight=a.giou_weight, amp=a.amp)


def train(a):
    rank, world, device = td.setup_ddp()
    main = rank == 0
    say = (lambda *x: print(*x, flush=True)) if main else (lambda *x: None)
    torch.manual_seed(a.seed + rank); random.seed(a.seed + rank); np.random.seed(a.seed + rank)
    cfg = cfg_of(a)
    entries = td.read_manifest(a.crops)
    anns = td.load_scene_annotations(a.ann_root)
    tr_e, va_e, val_scenes = td.split_scenes(entries, a.val_scenes, a.val_frac, a.seed)
    if a.overfit:
        tr_e = va_e = entries
        val_scenes = ["(training crops)"]
    tr, va = RawSet(a.crops, tr_e, anns, cfg, True), RawSet(a.crops, va_e, anns, cfg, False)
    say(f"crops: {len(tr)} train ({int(tr.positive.sum())} positive), {len(va)} val ({int(va.positive.sum())} positive); "
        f"val scenes {val_scenes or 'none (crop split)'}; {world} process(es) on {device}")
    os.makedirs(a.out, exist_ok=True)
    if main:
        with open(os.path.join(a.out, "config.json"), "w") as f:
            json.dump(dict(cfg, args=vars(a), val_scenes=val_scenes), f, indent=1, default=str)
    sampler = td.BalancedSampler(tr.positive, a.pos_frac, a.samples_per_epoch or len(tr), a.seed, rank, world)
    dl = torch.utils.data.DataLoader(tr, batch_size=a.batch, sampler=sampler, num_workers=a.workers, collate_fn=collate,
                                     pin_memory=device.type == "cuda", persistent_workers=a.workers > 0, drop_last=True)
    vdl = torch.utils.data.DataLoader(va, batch_size=a.batch, shuffle=False, num_workers=a.workers, collate_fn=collate)
    model = RawShipNet(cfg).to(device)
    say(f"model: {sum(p.numel() for p in model.parameters()) / 1e6:.1f} M parameters")
    if a.resume:
        model.load_state_dict(torch.load(a.resume, map_location="cpu", weights_only=False)["model"])
    if world > 1:
        model = nn.parallel.DistributedDataParallel(model, device_ids=[device.index] if device.type == "cuda" else None)
    core = model.module if world > 1 else model
    opt = torch.optim.AdamW(model.parameters(), lr=a.lr, weight_decay=0.05)
    steps = a.max_iters or a.epochs * len(dl)
    sched = torch.optim.lr_scheduler.LambdaLR(opt, lambda s: min(1.0, (s + 1) / a.warmup) *
                                              0.5 * (1 + math.cos(math.pi * min(s, steps) / max(steps, 1))))
    best, step, hist = -1e9, 0, []
    log_f = open(os.path.join(a.out, "metrics.jsonl"), "a") if main else None
    for epoch in range(a.epochs):
        sampler.set_epoch(epoch)
        t0, seen = time.time(), 0
        for b in dl:
            b = to_device(b, device)
            losses = compute_loss(model(b), b, cfg)
            loss = sum(losses.values())
            opt.zero_grad(set_to_none=True)
            loss.backward()
            gn = float(nn.utils.clip_grad_norm_(model.parameters(), 5.0))
            opt.step(); sched.step()
            step += 1; seen += len(b["X"]) * world
            hist.append(loss.item())
            if main and (step % a.log_every == 0 or step == 1):
                rec = dict(step=step, epoch=epoch, loss=loss.item(), **{k: v.item() for k, v in losses.items()},
                           lr=sched.get_last_lr()[0], grad_norm=gn, crops_per_s=seen / (time.time() - t0))
                say(f"  step {step}: loss {rec['loss']:.4f} (" + ", ".join(f"{k} {rec[k]:.4f}" for k in losses) +
                    f"), {rec['crops_per_s']:.2f} crops/s")
                log_f.write(json.dumps(rec) + "\n"); log_f.flush()
            if a.max_iters and step >= a.max_iters:
                break
        if world > 1:
            dist.barrier()
        last = epoch == a.epochs - 1 or (a.max_iters and step >= a.max_iters)
        if main and ((epoch + 1) % a.eval_every == 0 or last):
            m, records = evaluate(model, vdl, device, cfg)
            m.update(epoch=epoch, step=step)
            say(f"epoch {epoch}: AP30 {m['ap30']:.3f}, AP50 {m['ap50']:.3f}, precision {m['precision']:.3f}, recall {m['recall']:.3f}, "
                f"{m['false_alarms_per_km2']:.2f} false alarms per km2, centre error {m['centre_error_m']:.1f} m")
            log_f.write(json.dumps(dict(eval=m)) + "\n"); log_f.flush()
            state = dict(model=core.state_dict(), cfg=cfg, epoch=epoch, step=step, metrics=m)
            torch.save(state, os.path.join(a.out, "last.pt"))
            score = m["ap30"] if m["ap30"] == m["ap30"] else -m["false_alarms_per_km2"]
            if score > best:
                best = score
                torch.save(state, os.path.join(a.out, "best.pt"))
                td.detections_geojson(records, os.path.join(a.out, "val_detections.geojson"))
        if world > 1:
            dist.barrier()
        if a.max_iters and step >= a.max_iters:
            break
    if world > 1:
        dist.destroy_process_group()
    return hist


@torch.no_grad()
def predict(a):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    st = torch.load(a.ckpt, map_location="cpu", weights_only=False)
    cfg = st["cfg"]
    model = RawShipNet(cfg).to(device)
    model.load_state_dict(st["model"])
    entries = td.read_manifest(a.crops)
    if a.scenes:
        entries = [e for e in entries if any(s in e["scene"] for s in a.scenes)]
    ds = RawSet(a.crops, entries, td.load_scene_annotations(a.ann_root), cfg, train=False)
    dl = torch.utils.data.DataLoader(ds, batch_size=a.batch, num_workers=a.workers, collate_fn=collate)
    m, records = evaluate(model, dl, device, cfg, a.score_thr)
    n = td.detections_geojson(records, a.out, a.score_thr)
    print(f"{len(ds)} crops, {n} detections after merging overlaps -> {a.out}")
    if ds.anns:
        print(json.dumps(m, indent=1))
    return m


# ------------------------------------------------------------------ self-test
def selftest(work, reuse=False):
    crops, ann_root, man, bc = td.make_synthetic_dataset(work, reuse=reuse)
    print(f"synthetic crops: {len(man)} ({sum(m['label'] == 'positive' for m in man)} positive)")
    ok = True
    p = parser()
    small = ["--cells", "64", "--cell-m", "8", "--dim", "192", "--depth", "4", "--heads", "4", "--dec-dim", "96",
             "--dec-heads", "4", "--dec-layers", "2"]
    a = p.parse_args(["train", "--crops", crops, "--ann-root", ann_root, "--out", os.path.join(work, "raw"), *small])
    cfg = cfg_of(a)
    anns = td.load_scene_annotations(ann_root)
    ds = RawSet(crops, man, anns, cfg, train=True)

    # 1. moving the reference point by a phase ramp keeps the scene where it is on the ground
    i = next(k for k, m in enumerate(man) if m["kind"] == "ship_centred")
    d0, d1 = ds.get(i, shift=(0.0, 0.0)), ds.get(i, shift=(40.0, -25.0))
    m0 = ds.meta[i]
    g = td.make_grid(m0["centre_lat"], m0["centre_lon"], 64, 1.0)
    imgs = []
    for d in (d0, d1):
        Dv = td.llh_to_ecef(d["lat"], d["lon"], m0["h_ref"])
        pix = td.grid_pixels_ecef(g, m0["h_ref"], Dv)
        im = td.Imager(d["X"].shape[0], d["X"].shape[1], n_sub=1, oversample=4, learn_taper=False)
        re_, im_ = im(d["X"][None], d["tx"][None], d["rc"][None], d["f0"][None], d["scss"][None], torch.tensor([-1]),
                      torch.from_numpy(pix)[None])
        imgs.append((re_[0, 0] + 1j * im_[0, 0]).numpy())
    a0, a1 = np.abs(imgs[0]).reshape(64, 64), np.abs(imgs[1]).reshape(64, 64)
    corr = float(np.corrcoef(a0.ravel(), a1.ravel())[0, 1])
    yy, xx = np.mgrid[0:64, 0:64]
    cen = lambda a: np.array([(a * yy).sum(), (a * xx).sum()]) / a.sum()
    moved = float(np.hypot(*(cen(a0 ** 2) - cen(a1 ** 2))))
    good = corr > 0.98 and moved < 0.5
    ok &= good
    print(f"reference point moved by (40, -25) m with a phase ramp: image of the same ground correlates {corr:.4f}, "
          f"bright centroid moved {moved:.2f} m | {'ok' if good else 'FAIL'}")

    # 2. targets: each visible ship gives one centre cell with heat 1, and decoding the target returns the box
    b = collate([d1])
    k = int(b["mask"].sum())
    dec = decode_at(b["off"], b["size"], b["idx"], cfg["cells"], cfg["cell_m"])[b["mask"] > 0]
    err = float((dec - b["box"][b["mask"] > 0]).abs().max()) if k else 0.0
    good = int((b["heat"] >= 1).sum()) == k == int((~d1["gt_ignore"]).sum()) and err < 0.6
    ok &= good
    print(f"targets: {k} ship centre(s), heat peaks {int((b['heat'] >= 1).sum())}, box from target values within "
          f"{err:.3f} m | {'ok' if good else 'FAIL'}")

    # 3. forward, losses and gradients
    model = RawShipNet(cfg)
    losses = compute_loss(model(b), b, cfg)
    sum(losses.values()).backward()
    gp = float(model.patch.weight.grad.abs().mean())
    good = all(torch.isfinite(v) for v in losses.values()) and gp > 0
    ok &= good
    print(f"losses {', '.join(f'{k} {v.item():.3f}' for k, v in losses.items())}; gradient reaches the patch embedding "
          f"({gp:.2e}) | {'ok' if good else 'FAIL'}")

    # 4. can it memorise the training crops? (CPU, small model)
    out = os.path.join(work, "raw")
    a = p.parse_args(["train", "--crops", crops, "--ann-root", ann_root, "--out", out, *small, "--overfit", "--batch", "4",
                      "--epochs", "1", "--max-iters", "300", "--samples-per-epoch", "1200", "--lr", "5e-4", "--warmup", "30",
                      "--workers", "2", "--log-every", "50", "--pos-frac", "0.8", "--shift-m", "16"])
    hist = train(a)
    with open(os.path.join(out, "metrics.jsonl")) as f:
        ev = [json.loads(l)["eval"] for l in f if '"eval"' in l]
    first, last = float(np.mean(hist[:20])), float(np.mean(hist[-20:]))
    good = last < first and bool(ev)
    ok &= good
    print(f"overfit run: mean loss {first:.3f} (first 20 steps) -> {last:.3f} (last 20); AP30 on the training crops "
          f"{ev[-1]['ap30']:.3f}, recall {ev[-1]['recall']:.2f} at score 0.5 | {'ok' if good else 'FAIL'}")
    pa = p.parse_args(["predict", "--ckpt", os.path.join(out, "best.pt"), "--crops", crops, "--ann-root", ann_root,
                       "--out", os.path.join(out, "pred.geojson"), "--score-thr", "0.3", "--workers", "2"])
    predict(pa)
    good = os.path.exists(os.path.join(out, "pred.geojson"))
    ok &= good
    print(f"predict wrote GeoJSON | {'ok' if good else 'FAIL'}")
    print("SELF-TEST", "PASSED" if ok else "FAILED")
    return ok


def parser():
    ap = argparse.ArgumentParser(description="CPHD ship detector on raw phase history")
    sub = ap.add_subparsers(dest="cmd", required=True)
    t = sub.add_parser("train")
    t.add_argument("--crops", required=True)
    t.add_argument("--ann-root", default="/data3/sandbox/jhu/satlock/annotation_tool/test_aligned")
    t.add_argument("--out", required=True)
    t.add_argument("--val-scenes", nargs="*")
    t.add_argument("--val-frac", type=float, default=0.2)
    t.add_argument("--overfit", action="store_true", help="train and validate on the same crops (sanity check)")
    t.add_argument("--epochs", type=int, default=50)
    t.add_argument("--max-iters", type=int, default=0)
    t.add_argument("--samples-per-epoch", type=int, default=0)
    t.add_argument("--batch", type=int, default=8, help="crops per GPU")
    t.add_argument("--lr", type=float, default=3e-4)
    t.add_argument("--warmup", type=int, default=500)
    t.add_argument("--pos-frac", type=float, default=0.5)
    t.add_argument("--workers", type=int, default=6)
    t.add_argument("--log-every", type=int, default=20)
    t.add_argument("--eval-every", type=int, default=1)
    t.add_argument("--resume", default=None)
    t.add_argument("--seed", type=int, default=0)
    t.add_argument("--cells", type=int, default=128, help="output grid cells per side (128 x 4 m = 512 m crop)")
    t.add_argument("--cell-m", type=float, default=4.0)
    t.add_argument("--shift-m", type=float, default=64.0, help="random move of the crop centre, metres (phase ramp)")
    t.add_argument("--min-visible", type=float, default=0.3)
    t.add_argument("--max-objs", type=int, default=64)
    t.add_argument("--pulses", type=int, default=1024)
    t.add_argument("--samples", type=int, default=1024)
    t.add_argument("--patch", type=int, default=32)
    t.add_argument("--dim", type=int, default=384, help="encoder width (ViT-S)")
    t.add_argument("--depth", type=int, default=12)
    t.add_argument("--heads", type=int, default=6)
    t.add_argument("--dec-dim", type=int, default=128)
    t.add_argument("--dec-heads", type=int, default=4)
    t.add_argument("--dec-layers", type=int, default=2)
    t.add_argument("--giou-weight", type=float, default=1.0)
    t.add_argument("--amp", action="store_true", help="bfloat16 autocast on GPU")
    p = sub.add_parser("predict")
    p.add_argument("--ckpt", required=True)
    p.add_argument("--crops", required=True)
    p.add_argument("--ann-root", default=None)
    p.add_argument("--out", required=True)
    p.add_argument("--scenes", nargs="*")
    p.add_argument("--score-thr", type=float, default=0.3)
    p.add_argument("--batch", type=int, default=8)
    p.add_argument("--workers", type=int, default=4)
    s = sub.add_parser("selftest")
    s.add_argument("--dir", default="./cphd_raw_selftest")
    s.add_argument("--reuse", action="store_true", help="reuse synthetic crops already in --dir")
    return ap


def main():
    a = parser().parse_args()
    if a.cmd == "train":
        train(a)
    elif a.cmd == "predict":
        predict(a)
    else:
        sys.exit(0 if selftest(a.dir, a.reuse) else 1)


if __name__ == "__main__":
    main()
